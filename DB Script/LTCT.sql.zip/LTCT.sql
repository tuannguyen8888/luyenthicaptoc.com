-- phpMyAdmin SQL Dump
-- version 4.9.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 15, 2020 at 12:32 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `LTCT`
--

-- --------------------------------------------------------

--
-- Table structure for table `cauhoi`
--

CREATE TABLE `cauhoi` (
  `id_cauhoi` int(11) NOT NULL,
  `noidung` text COLLATE utf8_unicode_ci NOT NULL,
  `hinhanh` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `a` text COLLATE utf8_unicode_ci,
  `b` text COLLATE utf8_unicode_ci,
  `c` text COLLATE utf8_unicode_ci,
  `d` text COLLATE utf8_unicode_ci,
  `correct_answer` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_loaich` int(11) DEFAULT NULL,
  `id_mucdo` int(11) DEFAULT NULL,
  `id_mh` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cauhoi`
--

INSERT INTO `cauhoi` (`id_cauhoi`, `noidung`, `hinhanh`, `a`, `b`, `c`, `d`, `correct_answer`, `id_loaich`, `id_mucdo`, `id_mh`, `created_at`, `updated_at`) VALUES
(1, 'How do you feel?', 'cuoi.jpg', 'I am good', 'bad', 'dont know', 'happy', 'A', 3, 1, 3, NULL, '2020-08-22 17:57:35'),
(2, 'A .......... knit community is the one in which relationships are very close.', NULL, 'close', 'closely', 'tightly', 'ugly', 'B', 2, 1, 3, NULL, '2020-08-22 17:57:35'),
(3, 'Mr. Brown is bored with doing the ................ chores.', NULL, 'household', 'domestic', 'housework', 'table', 'C', 1, 1, 3, NULL, '2020-08-22 17:57:35'),
(4, 'There has been a shift of ................. from manufacturing to service industries.', NULL, 'change', 'alteration', 'emphasis', 'movement', 'A', 1, 3, 3, NULL, '2020-08-22 17:57:35'),
(5, 'There was a wealth of .................... evidence.', NULL, 'supportive', 'support', 'supported', 'supporting', 'A', 1, 3, 3, NULL, '2020-08-22 17:57:35'),
(11, '<p>What are you doing?</p>', NULL, '<p>False</p>', '<p>True</p>', NULL, NULL, 'B', 4, 3, 3, '2019-04-12 10:58:21', '2020-08-22 17:57:35'),
(40, 'He ...................... on business yesterday', '', 'went', 'goes', 'go        ', 'going', 'A', 1, 1, 3, '2019-04-19 05:23:28', '2020-08-22 17:57:35'),
(41, '<p>Tom likes dancing, but Mike......................</p>', '', '<p>doesn&#39;t</p>', '<p>did&nbsp;</p>', '<p>do</p>', '<p>does not</p>', 'A', 2, 2, 3, '2019-04-19 05:51:47', '2020-08-22 17:57:35'),
(42, ' Listen! Somebody......................for help.', '', 'are screaming', 'scream', 'is screaming', 'has screamed', 'C', 1, 3, 3, '2019-04-19 05:23:28', '2020-08-22 17:57:35'),
(43, ' Waiter! There......................forks on this table.', '', 'are not some ', 'isn’t any', 'are not any', 'are some', 'C', 1, 2, 3, '2019-04-19 05:23:28', '2020-08-22 17:57:35'),
(44, 'I have a test tomorrow, so I......................sit up late tonight to study.', '', 'will have to', 'can have to', 'have', 'have to', 'D', 1, 2, 3, '2019-04-19 05:23:28', '2020-08-22 17:57:35'),
(45, 'An island on which......................is called a deserted island.', NULL, 'no people', 'no peoples live', 'no people live', 'people are living', 'C', 1, 2, 3, '2019-04-10 00:39:21', '2020-08-22 17:57:35'),
(46, 'We wondered who......................to pay for the broken window.', NULL, 'is going ', 'was going', 'have', 'would', 'B', 2, 1, 3, '2019-04-10 00:39:21', '2020-08-22 17:57:35'),
(47, 'Linda......................tie her shoes when she was only 3 years old', NULL, 'knew to', 'knew how to', 'could to', 'may', 'B', 3, 3, 3, '2019-04-10 00:39:21', '2020-08-22 17:57:35'),
(48, '<p>I ..... to do homework.</p>', '', '<p>want</p>', '<p>do</p>', '<p>know</p>', '<p>All are correct</p>', 'A', 1, 1, 3, '2019-04-17 03:19:10', '2020-08-22 17:57:35'),
(51, '<p>What is this season?</p>', 'TOOE_tusach.jpg', '<p>Spring</p>', '<p>Summer</p>', '<p>autumn</p>', '<p>Winter</p>', 'B', 1, 1, 3, '2019-04-19 05:21:27', '2020-08-22 17:57:35'),
(52, 'He ...................... on business yesterday', 'a.jpg', 'went', 'goes', 'go        ', 'going', 'A', 1, 1, 3, '2019-04-19 06:39:52', '2020-08-22 17:57:35'),
(53, 'Tom doesn\'t like dancing, but Mike......................', 'a.jpg', 'does', 'did ', 'do', 'doesn\'t', 'A', 1, 2, 3, '2019-04-19 06:39:52', '2020-08-22 17:57:35'),
(54, ' Listen! Somebody......................for help.', 'a.jpg', 'are screaming', 'scream', 'is screaming', 'has screamed', NULL, 1, 3, 3, '2019-04-19 06:39:52', '2019-04-19 06:39:52'),
(55, ' Waiter! There......................forks on this table.', 'a.jpg', 'are not some ', 'isn’t any', 'are not any', 'are some', NULL, 1, 1, 3, '2019-04-19 06:39:52', '2019-04-19 06:39:52'),
(56, 'I have a test tomorrow, so I......................sit up late tonight to study.', 'a.jpg', 'will have to', 'can have to', 'have', 'have to', NULL, 1, 2, 3, '2019-04-19 06:39:52', '2019-04-19 06:39:52'),
(57, 'An island on which......................is called a deserted island.', NULL, 'no people', 'no peoples live', 'no people live', 'people are living', NULL, 1, 1, 1, '2019-04-19 06:39:52', '2019-04-19 06:39:52'),
(58, 'We wondered who......................to pay for the broken window.', NULL, 'is going ', 'was going', 'have', 'would', NULL, 2, 1, 1, '2019-04-19 06:39:52', '2019-04-19 06:39:52'),
(59, 'Linda......................tie her shoes when she was only 3 years old', NULL, 'knew to', 'knew how to', 'could to', 'may', NULL, 3, 1, 1, '2019-04-19 06:39:52', '2019-04-19 06:39:52');

-- --------------------------------------------------------

--
-- Table structure for table `cms_apicustom`
--

CREATE TABLE `cms_apicustom` (
  `id` int(10) UNSIGNED NOT NULL,
  `permalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tabel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kolom` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderby` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_query_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sql_where` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `method_type` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` longtext COLLATE utf8mb4_unicode_ci,
  `responses` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_apikey`
--

CREATE TABLE `cms_apikey` (
  `id` int(10) UNSIGNED NOT NULL,
  `screetkey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hit` int(11) DEFAULT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_dashboard`
--

CREATE TABLE `cms_dashboard` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_email_queues`
--

CREATE TABLE `cms_email_queues` (
  `id` int(10) UNSIGNED NOT NULL,
  `send_at` datetime DEFAULT NULL,
  `email_recipient` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_cc_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_content` text COLLATE utf8mb4_unicode_ci,
  `email_attachments` text COLLATE utf8mb4_unicode_ci,
  `is_sent` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_email_templates`
--

CREATE TABLE `cms_email_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_email_templates`
--

INSERT INTO `cms_email_templates` (`id`, `name`, `slug`, `subject`, `content`, `description`, `from_name`, `from_email`, `cc_email`, `created_at`, `updated_at`) VALUES
(2, 'Email cấp lại mật khẩu', 'forgot_password_backend', '[luyenthicaptoc.com] Cấp lại mật khẩu', '<p>Chào bạn,</p><p>Mật khẩu mới được cấp cho bạn là :&nbsp;<b>[password]</b></p><p>Chúc bạn làm việc hiệu quả.</p><p>Trân trọng.</p>', '[password]', 'luyenthicaptoc.com', 'system@luyenthicaptoc.com', NULL, '2019-09-06 11:09:46', '2020-08-18 10:42:40');

-- --------------------------------------------------------

--
-- Table structure for table `cms_logs`
--

CREATE TABLE `cms_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `ipaddress` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `useragent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `id_cms_users` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_logs`
--

INSERT INTO `cms_logs` (`id`, `ipaddress`, `useragent`, `url`, `description`, `details`, `id_cms_users`, `created_at`, `updated_at`) VALUES
(3475, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-17 16:52:20', NULL),
(3476, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 09:05:48', NULL),
(3477, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 09:10:28', NULL),
(3478, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 10:05:17', NULL),
(3479, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 10:11:42', NULL),
(3480, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 10:12:30', NULL),
(3481, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 10:13:00', NULL),
(3482, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 10:17:32', NULL),
(3483, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 10:32:08', NULL),
(3484, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-18 10:39:13', NULL),
(3485, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 10:39:18', NULL),
(3486, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/email_templates/edit-save/2', 'Sửa dữ liệu Email cấp lại mật khẩu trong Mẫu Email', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>subject</td><td>[iFund] Cấp lại mật khẩu</td><td>[luyenthicaptoc.com] Cấp lại mật khẩu</td></tr><tr><td>content</td><td><p>Chào bạn,</p><p>Mật khẩu mới được cấp cho bạn là :&nbsp;<b>[password]</b></p><p>Chúc bạn làm việc hiệu quả.</p><p>Trân trọng.</p><p>iFund System</p></td><td><p>Chào bạn,</p><p>Mật khẩu mới được cấp cho bạn là :&nbsp;<b>[password]</b></p><p>Chúc bạn làm việc hiệu quả.</p><p>Trân trọng.</p></td></tr><tr><td>from_name</td><td>iFund System</td><td>luyenthicaptoc.com</td></tr><tr><td>from_email</td><td>system@crudbooster.com</td><td>system@luyenthicaptoc.com</td></tr><tr><td>cc_email</td><td></td><td></td></tr></tbody></table>', 1, '2020-08-18 10:42:40', NULL),
(3487, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 14:13:09', NULL),
(3488, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-18 14:26:39', NULL),
(3489, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 14:39:53', NULL),
(3490, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/40', 'Sửa dữ liệu Dashboard trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>0</td><td></td></tr><tr><td>is_dashboard</td><td>0</td><td>1</td></tr><tr><td>sorting</td><td>6</td><td></td></tr></tbody></table>', 1, '2020-08-18 15:03:22', NULL),
(3491, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/delete/35', 'Xóa dữ liệu Dashboard trong Menu Management', '', 1, '2020-08-18 15:10:41', NULL),
(3492, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 15:16:44', NULL),
(3493, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 15:21:23', NULL),
(3494, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/36', 'Sửa dữ liệu Giáo viên trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2020-08-18 16:30:00', NULL),
(3495, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/37', 'Sửa dữ liệu Học viên trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>3</td><td></td></tr></tbody></table>', 1, '2020-08-18 16:30:16', NULL),
(3496, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/38', 'Sửa dữ liệu Trường trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2020-08-18 16:30:32', NULL),
(3497, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/39', 'Sửa dữ liệu Môn học trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>5</td><td></td></tr></tbody></table>', 1, '2020-08-18 16:30:47', NULL),
(3498, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/41', 'Sửa dữ liệu Kỳ thi trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>6</td><td></td></tr></tbody></table>', 1, '2020-08-18 16:30:56', NULL),
(3499, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 16:38:15', NULL),
(3500, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-18 16:38:31', NULL),
(3501, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 16:44:34', NULL),
(3502, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-18 16:44:41', NULL),
(3503, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 16:45:53', NULL),
(3504, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Quản lý users trong Menu Management', '', 1, '2020-08-18 16:49:23', NULL),
(3505, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/42', 'Sửa dữ liệu Quản lý users trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>7</td><td></td></tr></tbody></table>', 1, '2020-08-18 16:49:40', NULL),
(3506, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/42', 'Sửa dữ liệu Quản lý users trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>7</td><td></td></tr></tbody></table>', 1, '2020-08-18 16:49:55', NULL),
(3507, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/42', 'Sửa dữ liệu Quản lý users trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>AdminCmsUsersController@GetIndex</td><td>AdminCmsUsersController@getIndex</td></tr><tr><td>sorting</td><td>7</td><td></td></tr></tbody></table>', 1, '2020-08-18 16:51:49', NULL),
(3508, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 18:01:51', NULL),
(3509, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-18 18:14:27', NULL),
(3510, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/school/add-save', 'Tạo mới dữ liệu Trung tâm tin học ABC trong Trường', '', 1, '2020-08-18 18:15:39', NULL),
(3511, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/school/edit-save/1', 'Sửa dữ liệu Trung tâm tin học ABC trong Trường', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>updated_by</td><td></td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2020-08-18 18:15:44', NULL),
(3512, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/school/edit-save/1', 'Sửa dữ liệu Trung tâm tin học ABC trong Trường', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>address</td><td>abc</td><td>abcaa</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2020-08-18 18:15:50', NULL),
(3513, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/question_type/add-save', 'Tạo mới dữ liệu 5 trong Loại câu hỏi', '', 1, '2020-08-18 18:17:17', NULL),
(3514, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/question_type/delete/5', 'Xóa dữ liệu 5 trong Loại câu hỏi', '', 1, '2020-08-18 18:17:31', NULL),
(3515, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-22 05:56:33', NULL),
(3516, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Ngân hàng câu hỏi trong Menu Management', '', 1, '2020-08-22 06:31:40', NULL),
(3517, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/44', 'Sửa dữ liệu Mức độ câu hỏi trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>name</td><td>Mứcc độ câu hỏi</td><td>Mức độ câu hỏi</td></tr><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>46</td><td></td></tr></tbody></table>', 1, '2020-08-22 06:32:30', NULL),
(3518, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/46', 'Sửa dữ liệu Ngân hàng câu hỏi trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>7</td><td></td></tr></tbody></table>', 1, '2020-08-22 06:32:41', NULL),
(3519, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/44', 'Sửa dữ liệu Mức độ câu hỏi trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>46</td><td></td></tr></tbody></table>', 1, '2020-08-22 06:32:56', NULL),
(3520, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/45', 'Sửa dữ liệu Câu hỏi trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>46</td><td></td></tr><tr><td>sorting</td><td>3</td><td></td></tr></tbody></table>', 1, '2020-08-22 06:33:05', NULL),
(3521, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/43', 'Sửa dữ liệu Loại câu hỏi trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>46</td><td></td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2020-08-22 06:33:26', NULL),
(3522, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/menu_management/edit-save/45', 'Sửa dữ liệu Câu hỏi trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>icon</td><td>fa fa-question</td><td>fa fa-question-circle</td></tr><tr><td>parent_id</td><td>46</td><td></td></tr><tr><td>sorting</td><td>3</td><td></td></tr></tbody></table>', 1, '2020-08-22 06:43:28', NULL),
(3523, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-22 14:23:03', NULL),
(3524, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-23 03:58:47', NULL),
(3525, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 16:57:43', NULL),
(3526, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 16:59:56', NULL),
(3527, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:05:45', NULL),
(3528, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 17:10:42', NULL),
(3529, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:11:05', NULL),
(3530, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:11:53', NULL),
(3531, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:11:54', NULL),
(3532, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 17:12:22', NULL),
(3533, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:12:42', NULL),
(3534, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 17:13:04', NULL),
(3535, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:13:25', NULL),
(3536, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 17:14:08', NULL),
(3537, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:15:31', NULL),
(3538, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 17:19:50', NULL),
(3539, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:20:15', NULL),
(3540, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 17:20:58', NULL),
(3541, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:21:38', NULL),
(3542, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 17:23:49', NULL),
(3543, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:23:59', NULL),
(3544, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 17:29:28', NULL),
(3545, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:38:39', NULL),
(3546, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 17:55:58', NULL),
(3547, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 17:56:46', NULL),
(3548, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/dangxuat', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-08-23 18:08:44', NULL),
(3549, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-08-23 18:10:30', NULL),
(3550, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-26 16:03:16', NULL),
(3551, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/settings/add-save', 'Tạo mới dữ liệu address trong Settings', '', 1, '2020-08-26 16:05:16', NULL),
(3552, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/settings/add-save', 'Tạo mới dữ liệu email trong Settings', '', 1, '2020-08-26 16:05:49', NULL),
(3553, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/settings/add-save', 'Tạo mới dữ liệu phone trong Settings', '', 1, '2020-08-26 16:06:17', NULL),
(3554, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/settings/add-save', 'Tạo mới dữ liệu address trong Settings', '', 1, '2020-08-26 16:19:10', NULL),
(3555, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/settings/add-save', 'Tạo mới dữ liệu email trong Settings', '', 1, '2020-08-26 16:19:23', NULL),
(3556, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/settings/add-save', 'Tạo mới dữ liệu phone trong Settings', '', 1, '2020-08-26 16:19:49', NULL),
(3557, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/settings/add-save', 'Tạo mới dữ liệu hotline trong Settings', '', 1, '2020-08-26 16:20:16', NULL),
(3558, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-08-26 17:41:52', NULL),
(3559, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-04 03:30:36', NULL),
(3560, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-08 10:25:35', NULL),
(3561, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-08 10:27:25', NULL),
(3562, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-08 10:37:17', NULL),
(3563, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-08 10:39:20', NULL),
(3564, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-08 10:50:44', NULL),
(3565, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-09 03:48:20', NULL),
(3566, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-09 03:53:42', NULL),
(3567, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-09 04:36:12', NULL),
(3568, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-09 04:43:46', NULL),
(3569, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/dangxuat', 'tuannguyen8888@gmail.com đăng xuất', '', 1, '2020-09-09 04:51:12', NULL),
(3570, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 1, '2020-09-09 04:51:21', NULL),
(3571, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'http://ltct.com:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP 127.0.0.1', '', 1, '2020-09-14 13:29:32', NULL),
(3572, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', 'http://ltct.com:8888/admin/users/add-save', 'Tạo mới dữ liệu Võ Tuấn Khôi trong Quản lý users', '', 1, '2020-09-14 13:31:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_menus`
--

CREATE TABLE `cms_menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'url',
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_dashboard` tinyint(1) NOT NULL DEFAULT '0',
  `id_cms_privileges` int(11) DEFAULT NULL,
  `sorting` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_menus`
--

INSERT INTO `cms_menus` (`id`, `name`, `type`, `path`, `color`, `icon`, `parent_id`, `is_active`, `is_dashboard`, `id_cms_privileges`, `sorting`, `created_at`, `updated_at`) VALUES
(36, 'Giáo viên', 'Route', 'AdminTeacherControllerGetIndex', 'normal', 'fa fa-user-md', 0, 1, 0, 1, 2, '2020-08-18 09:19:05', '2020-08-18 16:30:00'),
(37, 'Học viên', 'Route', 'AdminStudentControllerGetIndex', 'normal', 'fa fa-users', 0, 1, 0, 1, 3, '2020-08-18 09:34:37', '2020-08-18 16:30:16'),
(38, 'Trường', 'Route', 'AdminSchoolControllerGetIndex', 'normal', 'fa fa-building-o', 0, 1, 0, 1, 4, '2020-08-18 09:49:04', '2020-08-18 16:30:32'),
(39, 'Môn học', 'Route', 'AdminSubjectControllerGetIndex', 'normal', 'fa fa-leanpub', 0, 1, 0, 1, 5, '2020-08-18 09:58:30', '2020-08-18 16:30:47'),
(40, 'Dashboard', 'Route', 'AdminDashboardControllerGetIndex', 'normal', 'fa fa-dashboard', 0, 1, 1, 1, 1, '2020-08-18 15:02:13', '2020-08-18 15:03:22'),
(41, 'Kỳ thi', 'Route', 'AdminExamControllerGetIndex', 'normal', 'fa fa-crosshairs', 0, 1, 0, 1, 6, '2020-08-18 16:00:43', '2020-08-18 16:30:56'),
(42, 'Quản lý users', 'Controller & Method', 'AdminCmsUsersController@getIndex', 'normal', 'fa fa-users', 0, 1, 0, 1, 9, '2020-08-18 16:49:23', '2020-08-18 16:51:49'),
(43, 'Loại câu hỏi', 'Route', 'AdminQuestionTypeControllerGetIndex', 'normal', 'fa fa-question', 46, 1, 0, 1, 2, '2020-08-18 17:35:28', '2020-08-22 06:33:26'),
(44, 'Mức độ câu hỏi', 'Route', 'AdminQuestionLevelControllerGetIndex', 'normal', 'fa fa-level-up', 46, 1, 0, 1, 1, '2020-08-22 05:59:56', '2020-08-22 06:32:56'),
(45, 'Câu hỏi', 'Route', 'AdminQuestionControllerGetIndex', 'normal', 'fa fa-question-circle', 46, 1, 0, 1, 3, '2020-08-22 06:20:25', '2020-08-22 06:43:28'),
(46, 'Ngân hàng câu hỏi', 'URL', '#', 'normal', 'fa fa-question-circle', 0, 1, 0, 1, 7, '2020-08-22 06:31:40', '2020-08-22 06:32:41'),
(47, 'Đề thi', 'Route', 'AdminExamQuestionControllerGetIndex', NULL, 'fa fa-file-text-o', 0, 1, 0, 1, 8, '2020-08-23 06:51:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_menus_privileges`
--

CREATE TABLE `cms_menus_privileges` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_cms_menus` int(11) DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_menus_privileges`
--

INSERT INTO `cms_menus_privileges` (`id`, `id_cms_menus`, `id_cms_privileges`) VALUES
(1, 1, 1),
(2, 2, 1),
(5, 5, 1),
(10, 10, 1),
(46, 30, 1),
(47, 31, 1),
(57, 34, 1),
(317, 12, 2),
(319, 12, 3),
(321, 12, 4),
(323, 12, 11),
(325, 12, 9),
(327, 12, 10),
(329, 12, 6),
(331, 12, 1),
(333, 24, 2),
(335, 24, 3),
(337, 24, 11),
(339, 24, 1),
(340, 3, 3),
(342, 3, 11),
(344, 3, 1),
(345, 4, 4),
(347, 4, 11),
(349, 4, 1),
(351, 14, 11),
(353, 14, 9),
(355, 14, 10),
(357, 14, 6),
(359, 14, 1),
(361, 27, 11),
(363, 27, 9),
(365, 27, 10),
(367, 27, 1),
(368, 28, 11),
(370, 28, 10),
(372, 28, 1),
(373, 22, 2),
(375, 22, 3),
(377, 22, 4),
(379, 22, 11),
(381, 22, 9),
(383, 22, 10),
(385, 22, 6),
(387, 22, 5),
(389, 22, 1),
(391, 33, 2),
(393, 33, 3),
(395, 33, 4),
(397, 33, 11),
(399, 33, 9),
(401, 33, 10),
(403, 33, 6),
(405, 33, 1),
(406, 7, 2),
(408, 7, 3),
(410, 7, 4),
(412, 7, 11),
(414, 7, 9),
(416, 7, 10),
(418, 7, 6),
(420, 7, 5),
(422, 7, 1),
(423, 13, 2),
(425, 13, 3),
(427, 13, 4),
(429, 13, 11),
(431, 13, 9),
(433, 13, 10),
(435, 13, 6),
(437, 13, 5),
(439, 13, 1),
(482, 15, 2),
(484, 15, 3),
(486, 15, 4),
(488, 15, 11),
(490, 15, 9),
(492, 15, 10),
(494, 15, 6),
(496, 15, 5),
(498, 15, 1),
(500, 32, 2),
(502, 32, 3),
(504, 32, 4),
(506, 32, 11),
(508, 32, 9),
(510, 32, 10),
(512, 32, 6),
(514, 32, 5),
(516, 32, 1),
(517, 16, 11),
(519, 16, 1),
(521, 29, 2),
(523, 29, 3),
(525, 29, 4),
(527, 29, 11),
(529, 29, 9),
(531, 29, 10),
(533, 29, 6),
(535, 29, 5),
(537, 29, 1),
(539, 23, 2),
(541, 23, 3),
(543, 23, 4),
(545, 23, 11),
(547, 23, 9),
(549, 23, 10),
(551, 23, 6),
(553, 23, 5),
(555, 23, 1),
(556, 17, 2),
(558, 17, 3),
(560, 17, 4),
(562, 17, 11),
(564, 17, 9),
(566, 17, 10),
(568, 17, 6),
(570, 17, 5),
(572, 17, 1),
(573, 26, 2),
(575, 26, 3),
(577, 26, 4),
(579, 26, 11),
(581, 26, 9),
(583, 26, 10),
(585, 26, 6),
(587, 26, 5),
(589, 26, 1),
(591, 25, 2),
(593, 25, 3),
(595, 25, 4),
(597, 25, 11),
(599, 25, 9),
(601, 25, 10),
(603, 25, 6),
(605, 25, 5),
(607, 25, 1),
(608, 8, 2),
(610, 8, 3),
(612, 8, 4),
(614, 8, 11),
(616, 8, 9),
(618, 8, 10),
(620, 8, 6),
(622, 8, 5),
(624, 8, 1),
(626, 6, 2),
(628, 6, 3),
(630, 6, 4),
(632, 6, 11),
(634, 6, 9),
(636, 6, 10),
(638, 6, 6),
(640, 6, 5),
(642, 6, 1),
(644, 18, 2),
(646, 18, 3),
(648, 18, 4),
(650, 18, 11),
(652, 18, 9),
(654, 18, 10),
(656, 18, 6),
(658, 18, 5),
(660, 18, 1),
(661, 11, 2),
(663, 11, 3),
(665, 11, 4),
(667, 11, 11),
(669, 11, 9),
(671, 11, 10),
(673, 11, 6),
(675, 11, 5),
(677, 11, 1),
(678, 19, 2),
(680, 19, 3),
(682, 19, 4),
(684, 19, 11),
(686, 19, 9),
(688, 19, 10),
(690, 19, 6),
(692, 19, 5),
(694, 19, 1),
(695, 20, 2),
(697, 20, 3),
(699, 20, 4),
(701, 20, 11),
(703, 20, 9),
(705, 20, 10),
(707, 20, 6),
(709, 20, 5),
(711, 20, 1),
(712, 21, 2),
(714, 21, 3),
(716, 21, 4),
(718, 21, 11),
(720, 21, 9),
(722, 21, 10),
(724, 21, 6),
(726, 21, 5),
(728, 21, 1),
(730, 9, 2),
(732, 9, 3),
(734, 9, 4),
(736, 9, 11),
(738, 9, 9),
(740, 9, 10),
(742, 9, 6),
(744, 9, 5),
(746, 9, 1),
(779, 35, 2),
(780, 35, 3),
(781, 35, 4),
(782, 35, 9),
(783, 35, 10),
(784, 35, 6),
(785, 35, 5),
(786, 35, 1),
(792, 40, 2),
(793, 40, 3),
(794, 40, 4),
(795, 40, 1),
(797, 36, 2),
(798, 36, 1),
(799, 37, 2),
(800, 37, 1),
(801, 38, 2),
(802, 38, 1),
(803, 39, 2),
(804, 39, 1),
(805, 41, 2),
(806, 41, 1),
(811, 42, 2),
(812, 42, 1),
(816, NULL, 2),
(817, NULL, 1),
(819, 46, 2),
(820, 46, 1),
(821, 44, 2),
(822, 44, 1),
(825, 43, 2),
(826, 43, 1),
(827, 45, 2),
(828, 45, 1),
(829, 47, 1),
(830, 48, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms_moduls`
--

CREATE TABLE `cms_moduls` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_protected` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_moduls`
--

INSERT INTO `cms_moduls` (`id`, `name`, `icon`, `path`, `table_name`, `controller`, `is_protected`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Thông báo', 'fa fa-cog', 'notifications', 'cms_notifications', 'NotificationsController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(2, 'Vai trò users', 'fa fa-cog', 'privileges', 'cms_privileges', 'PrivilegesController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(3, 'Quyền của vai trò', 'fa fa-cog', 'privileges_roles', 'cms_privileges_roles', 'PrivilegesRolesController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(4, 'Quản lý users', 'fa fa-users', 'users', 'cms_users', 'AdminCmsUsersController', 0, 1, '2019-09-06 10:58:55', NULL, NULL),
(5, 'Settings', 'fa fa-cog', 'settings', 'cms_settings', 'SettingsController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(6, 'Module Generator', 'fa fa-database', 'module_generator', 'cms_moduls', 'ModulsController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(7, 'Menu Management', 'fa fa-bars', 'menu_management', 'cms_menus', 'MenusController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(8, 'Mẫu Email', 'fa fa-envelope-o', 'email_templates', 'cms_email_templates', 'EmailTemplatesController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(9, 'Xây dựng thống kê', 'fa fa-dashboard', 'statistic_builder', 'cms_statistics', 'StatisticBuilderController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(10, 'API Generator', 'fa fa-cloud-download', 'api_generator', '', 'ApiCustomController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(11, 'Log User Access', 'fa fa-flag-o', 'logs', 'cms_logs', 'LogsController', 1, 1, '2019-09-06 10:58:55', NULL, NULL),
(12, 'Quản lý khách hàng', 'fa fa-group', 'if_customer', 'if_customer', 'AdminIfCustomerController', 0, 0, '2019-09-08 10:28:52', NULL, '2019-09-11 21:13:34'),
(13, 'Gói ứng vốn', 'fa fa-cubes', 'if_capital_advance_package', 'if_capital_advance_package', 'AdminIfCapitalAdvancePackageController', 0, 0, '2019-09-08 10:42:03', NULL, '2019-09-11 21:17:40'),
(14, 'Thẩm định điện thoại', 'fa fa-phone', 'phone_expertise', 'ifn_expertise', 'AdminPhoneExpertiseController', 0, 0, '2019-09-11 20:58:55', NULL, '2020-08-17 16:35:55'),
(15, 'Thẩm định thực địa', 'fa fa-map-marker', 'field_expertise', 'ifn_expertise', 'AdminFieldExpertiseController', 0, 0, '2019-09-11 21:01:13', NULL, '2020-08-17 16:35:58'),
(16, 'Các loại phí khác', 'fa fa-link', 'ifn_other_fee', 'ifn_other_fee', 'AdminIfnOtherFeeController', 0, 0, '2019-09-11 21:05:11', NULL, '2019-09-11 21:06:18'),
(17, 'Các loại phí', 'fa fa-link', 'other_fee', 'ifn_other_fee', 'AdminOtherFeeController', 0, 0, '2019-09-11 21:07:55', NULL, '2020-08-17 16:34:31'),
(18, 'Quản lý khách hàng', 'fa fa-group', 'customer', 'ifn_customer', 'AdminCustomerController', 0, 0, '2019-09-11 21:14:06', NULL, '2020-08-17 16:35:42'),
(19, 'Gói thanh toán hộ', 'fa fa-cubes', 'capital_advance_package', 'ifn_capital_advance_package', 'AdminCapitalAdvancePackageController', 0, 0, '2019-09-11 21:18:03', NULL, '2020-08-17 16:34:51'),
(20, 'Lý do', 'fa fa-sticky-note', 'reason', 'ifn_reason', 'AdminReasonController', 0, 0, '2019-09-11 21:26:32', NULL, '2020-08-17 16:35:06'),
(21, 'Tiếp nhận hồ sơ', 'fa fa-credit-card', 'process_working_capital_document', 'ifn_working_capital_document', 'AdminProcessWorkingCapitalDocumentController', 0, 0, '2019-09-11 21:35:58', NULL, '2020-08-17 16:36:01'),
(22, 'Phê duyệt kiểm soát', 'fa fa-check-square-o', 'working_capital_document_approve', 'ifn_working_capital_document_approve', 'AdminWorkingCapitalDocumentApproveController', 0, 0, '2019-09-11 23:56:09', NULL, '2020-08-17 16:35:27'),
(23, 'Quản lý phiên bản', 'fa fa-sitemap', 'version', 'ifn_version', 'AdminVersionController', 0, 0, '2019-09-12 00:42:11', NULL, '2020-08-17 16:35:45'),
(24, 'Cấu hình thông tin', 'fa fa-cog', 'table_key', 'ifn_table_key', 'AdminTableKeyController', 0, 0, '2019-09-12 00:50:20', NULL, '2020-08-17 16:34:34'),
(25, 'Tỉnh thành', 'fa fa-th-list', 'province', 'ifn_province', 'AdminProvinceController', 0, 0, '2019-09-12 01:41:32', NULL, '2020-08-17 16:36:05'),
(26, 'Quận huyện', 'fa fa-list', 'district', 'ifn_district', 'AdminDistrictController', 0, 0, '2019-09-12 01:43:27', NULL, '2020-08-17 16:35:35'),
(27, 'Phường, xã, thị trấn', 'fa fa-list-ul', 'ward', 'ifn_ward', 'AdminWardController', 0, 0, '2019-09-12 01:52:25', NULL, '2020-08-17 16:35:30'),
(28, 'Loại hình kinh doanh', 'fa fa-bookmark-o', 'business_category', 'ifn_business_category', 'AdminBusinessCategoryController', 0, 0, '2019-09-15 19:38:20', NULL, '2020-08-17 16:35:02'),
(29, 'Vai trò Users', 'fa fa-cog', 'privileges_roles', 'cms_privileges_roles', 'PrivilegesRolesController', 1, 1, '2019-09-15 21:15:12', NULL, NULL),
(30, 'Quản lý users', 'fa fa-users', 'users', 'cms_users', 'AdminCmsUsersController', 0, 1, '2019-09-15 21:15:12', NULL, '2019-11-13 17:00:00'),
(31, 'Cấu hình', 'fa fa-cog', 'settings', 'cms_settings', 'SettingsController', 1, 1, '2019-09-15 21:15:12', NULL, NULL),
(32, 'Quản lý Module', 'fa fa-database', 'module_generator', 'cms_moduls', 'ModulsController', 1, 1, '2019-09-15 21:15:12', NULL, NULL),
(33, 'Quản lý Menu', 'fa fa-bars', 'menu_management', 'cms_menus', 'MenusController', 1, 1, '2019-09-15 21:15:12', NULL, NULL),
(34, 'Mẫu Email', 'fa fa-envelope-o', 'email_templates', 'cms_email_templates', 'EmailTemplatesController', 1, 1, '2019-09-15 21:15:12', NULL, NULL),
(35, 'Xây dựng các Thống kê', 'fa fa-dashboard', 'statistic_builder', 'cms_statistics', 'StatisticBuilderController', 1, 1, '2019-09-15 21:15:12', NULL, NULL),
(36, 'Quản lý API', 'fa fa-cloud-download', 'api_generator', '', 'ApiCustomController', 1, 1, '2019-09-15 21:15:12', NULL, NULL),
(37, 'Nhật ký truy cập', 'fa fa-flag-o', 'logs', 'cms_logs', 'LogsController', 1, 1, '2019-09-15 21:15:12', NULL, NULL),
(38, 'Danh sách hồ sơ cấp HMTTH', 'fa fa-check-square-o', 'working_capital_document', 'ifn_working_capital_document', 'AdminWorkingCapitalDocumentController', 0, 0, '2019-09-17 04:11:02', NULL, '2020-08-17 16:34:44'),
(39, 'Nhóm thông tin', 'fa fa-object-group', 'group_key', 'ifn_group_key', 'AdminGroupKeyController', 0, 0, '2019-09-24 00:20:36', NULL, '2020-08-17 16:35:18'),
(40, 'Kiểm tra lịch sử tín dụng', 'fa fa-question', 'check_credit_history', 'ifn_working_capital_document', 'AdminCheckCreditHistoryController', 0, 0, '2019-09-24 01:49:18', NULL, '2020-08-17 16:34:47'),
(41, 'Cấu hình xếp hạng', 'fa fa-list-ol', 'scoring_rank', 'ifn_scoring_rank', 'AdminScoringRankController', 0, 0, '2019-09-24 02:38:28', NULL, '2020-08-17 16:34:37'),
(42, 'Bộ quy tắc chấm điểm', 'fa fa-puzzle-piece', 'formula_scoring', 'ifn_formula_scoring', 'AdminFormulaScoringController', 0, 0, '2019-09-24 02:59:25', NULL, '2020-08-17 16:34:29'),
(43, 'Phê duyệt cấp 1', 'fa fa-check-circle-o', 'working_capital_document_approve_1', 'ifn_working_capital_document', 'AdminWorkingCapitalDocumentApprove1Controller', 0, 0, '2019-09-25 21:35:25', NULL, '2020-08-17 16:35:21'),
(44, 'Phê duyệt cấp 2', 'fa fa-check', 'working_capital_document_approve_2', 'ifn_working_capital_document', 'AdminWorkingCapitalDocumentApprove2Controller', 0, 0, '2019-09-25 21:37:01', NULL, '2020-08-17 16:35:24'),
(45, 'Notifications', 'fa fa-cog', 'notifications', 'cms_notifications', 'NotificationsController', 1, 1, '2019-09-26 21:41:40', NULL, NULL),
(46, 'Privileges', 'fa fa-cog', 'privileges', 'cms_privileges', 'PrivilegesController', 1, 1, '2019-09-26 21:41:40', NULL, NULL),
(47, 'Nguồn dữ liệu tín dụng', 'fa fa-scribd', 'check_credit_source', 'ifn_check_credit_source', 'AdminCheckCreditSourceController', 0, 0, '2019-09-27 00:27:34', NULL, '2020-08-17 16:35:16'),
(49, 'Upload', 'fa fa-upload', 'upload', '', 'AdminUploadController', 0, 0, '2019-09-30 23:24:35', NULL, NULL),
(50, 'Quản lý sản phẩm', 'fa fa-product-hunt', 'ifn_finance_product', 'ifn_finance_product', 'AdminIfnFinanceProductController', 0, 0, '2019-10-14 19:43:11', NULL, '2020-08-17 16:35:47'),
(51, 'Quản lý sử dụng HMTTH', 'fa fa-dollar', 'transaction_management', 'ifn_working_capital_document', 'AdminTransactionManagementController', 0, 0, '2019-10-22 21:07:37', NULL, '2020-08-17 16:35:50'),
(52, 'fsafsafsafasfsaassffafa', 'fa fa-heart', 'cms_users', 'cms_users', 'AdminCmsUsers1Controller', 0, 0, '2019-10-22 21:56:01', NULL, '2019-10-22 21:58:48'),
(53, 'Báo cáo tổng hợp score card', 'fa fa-table', 'report_score_card', 'ifn_customer_info', 'AdminReportScoreCardController', 0, 0, '2019-10-31 07:10:19', NULL, '2020-08-17 16:34:26'),
(54, 'Báo cáo nợ đến hạn', 'fa fa-table', 'report_transaction_debt_due', 'ifn_transaction_detail', 'AdminReportTransactionDebtDueController', 0, 0, '2019-10-31 07:14:06', NULL, '2020-08-17 16:34:18'),
(55, 'Báo cáo nợ quá hạn', 'fa fa-table', 'report_transaction_overdue', 'ifn_transaction', 'AdminReportTransactionOverdueController', 0, 0, '2019-10-31 07:18:48', NULL, '2020-08-17 16:34:21'),
(56, 'Danh mục chung', 'fa fa-list-alt', 'master_data', 'ifn_master_data', 'AdminMasterDataController', 0, 0, '2019-11-04 08:28:42', NULL, '2020-08-17 16:34:41'),
(57, 'Quản lý giao dịch', 'fa fa-exchange', 'transaction_list', 'ifn_transaction', 'AdminTransactionListController', 0, 0, '2020-01-06 02:52:16', NULL, '2020-08-17 16:35:38'),
(58, 'Báo cáo tổng hợp kế toán', 'fa fa-table', 'general_accounting_report', 'ifn_transaction', 'AdminGeneralAccountingReportController', 0, 0, '2020-01-06 03:04:30', NULL, '2020-08-17 16:34:23'),
(59, 'Lệnh gọi thu nợ', 'fa fa-ioxhost', 'cash_assigns', 'ifn_cash_assigns', 'AdminCashAssignsController', 0, 0, '2020-02-26 08:12:59', NULL, '2020-08-17 16:34:57'),
(60, 'Ngày nghỉ', 'fa fa-calendar-times-o', 'holiday', 'ifn_holidays', 'AdminHolidayController', 0, 0, '2020-03-19 03:20:32', NULL, '2020-08-17 16:35:12'),
(61, 'Giáo viên', 'fa fa-user-md', 'teacher', 'giaovien', 'AdminTeacherController', 0, 0, '2020-08-18 09:19:05', NULL, NULL),
(62, 'Học viên', 'fa fa-users', 'student', 'hocsinh', 'AdminStudentController', 0, 0, '2020-08-18 09:34:37', NULL, NULL),
(63, 'Trường', 'fa fa-building-o', 'school', 'school', 'AdminSchoolController', 0, 0, '2020-08-18 09:49:04', NULL, NULL),
(64, 'Môn học', 'fa fa-leanpub', 'subject', 'monthi', 'AdminSubjectController', 0, 0, '2020-08-18 09:58:30', NULL, NULL),
(65, 'Dashboard', 'fa fa-dashboard', 'dashboard', 'cms_users', 'AdminDashboardController', 0, 0, '2020-08-18 15:02:13', NULL, NULL),
(66, 'Kỳ thi', 'fa fa-crosshairs', 'exam', 'kythi', 'AdminExamController', 0, 0, '2020-08-18 16:00:43', NULL, NULL),
(67, 'Loại câu hỏi', 'fa fa-question', 'question_type', 'loaicauhoi', 'AdminQuestionTypeController', 0, 0, '2020-08-18 17:35:28', NULL, NULL),
(68, 'Mức độ câu hỏi', 'fa fa-level-up', 'question_level', 'mucdo', 'AdminQuestionLevelController', 0, 0, '2020-08-22 05:59:56', NULL, NULL),
(69, 'Câu hỏi', 'fa fa-question-circle', 'question', 'cauhoi', 'AdminQuestionController', 0, 0, '2020-08-22 06:20:25', NULL, NULL),
(70, 'Đề thi', 'fa fa-file-text-o', 'exam_question', 'dethi', 'AdminExamQuestionController', 0, 0, '2020-08-23 06:51:49', NULL, NULL),
(72, 'Frontend Menu Management', 'fa fa-list-ol', 'frontend_menu_management', 'frontend_menus', 'AdminFrontendMenuManagementController', 0, 0, '2020-09-08 10:31:11', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_notifications`
--

CREATE TABLE `cms_notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_cms_users` int(11) DEFAULT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_notifications`
--

INSERT INTO `cms_notifications` (`id`, `id_cms_users`, `content`, `url`, `is_read`, `created_at`, `updated_at`) VALUES
(28, 53, 'Hồ sơ IP8D1D72023EF3 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP8D1D72023EF3', 1, '2019-11-13 03:01:55', '2019-11-13 03:01:55'),
(30, 54, 'Hồ sơ IPD5BAD54770D5 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IPD5BAD54770D5', 1, '2019-11-13 03:04:06', '2019-11-13 03:04:06'),
(31, 55, 'Hồ sơ IP786F7A2BDDFF đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP786F7A2BDDFF', 1, '2019-11-13 04:13:13', '2019-11-13 04:13:13'),
(33, 55, 'Hồ sơ IP786F7A2BDDFF đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IP786F7A2BDDFF', 1, '2019-11-13 04:58:07', '2019-11-13 04:58:07'),
(34, 58, 'Hồ sơ IP786F7A2BDDFF đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/IP786F7A2BDDFF', 1, '2019-11-13 04:58:49', '2019-11-13 04:58:49'),
(35, 54, 'Hồ sơ IP5E3B140D169D đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP5E3B140D169D', 1, '2019-11-13 06:23:24', '2019-11-13 06:23:24'),
(37, 59, 'Hồ sơ IP786F7A2BDDFF đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/IP786F7A2BDDFF', 1, '2019-11-13 06:34:30', '2019-11-13 06:34:30'),
(39, 55, 'Hồ sơ IP5E3B140D169D đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IP5E3B140D169D', 1, '2019-11-13 06:36:41', '2019-11-13 06:36:41'),
(41, 53, 'Hồ sơ IP0BE1C49C059B đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP0BE1C49C059B', 1, '2019-11-13 06:38:31', '2019-11-13 06:38:31'),
(42, 52, 'Hồ sơ IP5B9A8A30FABC đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP5B9A8A30FABC', 1, '2019-11-13 06:47:32', '2019-11-13 06:47:32'),
(43, 52, 'Hồ sơ IP592A862AAB9C đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP592A862AAB9C', 1, '2019-11-13 06:51:02', '2019-11-13 06:51:02'),
(45, 54, 'Hồ sơ IPDC2B21A6BED9 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IPDC2B21A6BED9', 1, '2019-11-13 06:55:50', '2019-11-13 06:55:50'),
(47, 53, 'Hồ sơ IP450881BF5388 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP450881BF5388', 1, '2019-11-13 06:57:43', '2019-11-13 06:57:43'),
(48, 54, 'Hồ sơ IP5B9A8A30FABC đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IP5B9A8A30FABC', 1, '2019-11-13 07:28:01', '2019-11-13 07:28:01'),
(49, 55, 'Hồ sơ IP450881BF5388 đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IP450881BF5388', 1, '2019-11-13 07:31:22', '2019-11-13 07:31:22'),
(50, 58, 'Hồ sơ IP450881BF5388 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/IP450881BF5388', 1, '2019-11-13 07:34:07', '2019-11-13 07:34:07'),
(51, 55, 'Hồ sơ IP0BE1C49C059B đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IP0BE1C49C059B', 1, '2019-11-13 07:49:01', '2019-11-13 07:49:01'),
(52, 52, 'Hồ sơ IP65AB28AF046E đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP65AB28AF046E', 1, '2019-11-13 08:46:20', '2019-11-13 08:46:20'),
(53, 53, 'Hồ sơ IP08D1D4F744BF đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP08D1D4F744BF', 1, '2019-11-13 08:59:21', '2019-11-13 08:59:21'),
(54, 52, 'Hồ sơ IPCB3150473B7D đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IPCB3150473B7D', 1, '2019-11-13 09:00:35', '2019-11-13 09:00:35'),
(56, 58, 'Hồ sơ IP0BE1C49C059B đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/IP0BE1C49C059B', 1, '2019-11-14 01:54:28', '2019-11-14 01:54:28'),
(57, 54, 'Hồ sơ IPDC2B21A6BED9 đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IPDC2B21A6BED9', 1, '2019-11-14 02:02:54', '2019-11-14 02:02:54'),
(59, 53, 'Hồ sơ IP26161047CF1C đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP26161047CF1C', 1, '2019-11-14 02:12:50', '2019-11-14 02:12:50'),
(61, 54, 'Hồ sơ IP26161047CF1C đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP26161047CF1C', 1, '2019-11-14 02:52:25', '2019-11-14 02:52:25'),
(63, 55, 'Hồ sơ IPCB3150473B7D đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IPCB3150473B7D', 1, '2019-11-14 03:52:53', '2019-11-14 03:52:53'),
(65, 58, 'Hồ sơ IPCB3150473B7D đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/IPCB3150473B7D', 1, '2019-11-14 03:55:31', '2019-11-14 03:55:31'),
(67, 52, 'Hồ sơ IP9047AD0CF579 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP9047AD0CF579', 1, '2019-11-14 04:10:32', '2019-11-14 04:10:32'),
(69, 53, 'Hồ sơ IP16244206425C đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP16244206425C', 1, '2019-11-14 07:04:21', '2019-11-14 07:04:21'),
(71, 54, 'Hồ sơ IP653C8DCC4D14 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP653C8DCC4D14', 1, '2019-11-14 07:05:21', '2019-11-14 07:05:21'),
(72, 52, 'Hồ sơ IP985BE60A49C8 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP985BE60A49C8', 1, '2019-11-14 07:05:47', '2019-11-14 07:05:47'),
(73, 55, 'Hồ sơ IP1B94A6A7E7F1 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP1B94A6A7E7F1', 1, '2019-11-14 07:06:17', '2019-11-14 07:06:17'),
(74, 53, 'Hồ sơ IP4F438CA074FF đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP4F438CA074FF', 1, '2019-11-14 07:06:53', '2019-11-14 07:06:53'),
(76, 53, 'Hồ sơ IP9DE5D7326368 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP9DE5D7326368', 1, '2019-11-14 07:07:54', '2019-11-14 07:07:54'),
(77, 52, 'Hồ sơ IP1C189675101D đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP1C189675101D', 1, '2019-11-14 07:08:57', '2019-11-14 07:08:57'),
(78, 54, 'Hồ sơ IP58ADA0D8D4FC đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP58ADA0D8D4FC', 1, '2019-11-14 07:11:01', '2019-11-14 07:11:01'),
(79, 55, 'Hồ sơ IP0FB8EBB4D615 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP0FB8EBB4D615', 1, '2019-11-14 07:11:44', '2019-11-14 07:11:44'),
(80, 54, 'Hồ sơ IP6A132B97C35A đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP6A132B97C35A', 1, '2019-11-14 07:16:52', '2019-11-14 07:16:52'),
(82, 53, 'Hồ sơ IP5165ABF823C5 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP5165ABF823C5', 1, '2019-11-14 07:20:23', '2019-11-14 07:20:23'),
(83, 55, 'Hồ sơ IP9047AD0CF579 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP9047AD0CF579', 1, '2019-11-14 07:22:53', '2019-11-14 07:22:53'),
(84, 54, 'Hồ sơ IP653C8DCC4D14 đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IP653C8DCC4D14', 1, '2019-11-14 07:28:23', '2019-11-14 07:28:23'),
(86, 1, 'Hồ sơ IP5B9A8A30FABC đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/IP5B9A8A30FABC', 1, '2019-11-14 07:28:52', '2019-11-14 07:28:52'),
(87, 1, 'Hồ sơ IP5B9A8A30FABC đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/IP5B9A8A30FABC', 1, '2019-11-14 07:29:19', '2019-11-14 07:29:19'),
(88, 1, 'Hồ sơ IP5B9A8A30FABC đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/IP5B9A8A30FABC', 1, '2019-11-14 07:29:37', '2019-11-14 07:29:37'),
(90, 1, 'Hồ sơ IP5B9A8A30FABC đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/IP5B9A8A30FABC', 1, '2019-11-14 07:29:57', '2019-11-14 07:29:57'),
(92, 58, 'Hồ sơ IP653C8DCC4D14 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/IP653C8DCC4D14', 1, '2019-11-14 07:32:28', '2019-11-14 07:32:28'),
(94, 57, 'Hồ sơ IP653C8DCC4D14 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/IP653C8DCC4D14', 1, '2019-11-14 07:34:46', '2019-11-14 07:34:46'),
(95, 54, 'Hồ sơ IP5165ABF823C5 đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IP5165ABF823C5', 1, '2019-11-14 07:48:08', '2019-11-14 07:48:08'),
(96, 52, 'Hồ sơ IPE627EEA27E70 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IPE627EEA27E70', 1, '2019-11-14 08:30:24', '2019-11-14 08:30:24'),
(98, 104, 'Hồ sơ IP592A862AAB9C đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP592A862AAB9C', 1, '2019-11-14 08:47:57', '2019-11-14 08:47:57'),
(99, 52, 'Hồ sơ IP592A862AAB9C đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IP592A862AAB9C', 1, '2019-11-14 08:52:45', '2019-11-14 08:52:45'),
(101, 55, 'Hồ sơ IPA166A4F961BA đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/IPA166A4F961BA', 1, '2019-11-14 08:56:17', '2019-11-14 08:56:17'),
(103, 54, 'Hồ sơ IPA166A4F961BA đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IPA166A4F961BA', 1, '2019-11-14 08:56:50', '2019-11-14 08:56:50'),
(105, 55, 'Hồ sơ IPE627EEA27E70 đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/IPE627EEA27E70', 1, '2019-11-14 09:09:12', '2019-11-14 09:09:12'),
(107, 56, 'Hồ sơ IPE627EEA27E70 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/38', 1, '2019-11-14 09:45:57', '2019-11-14 09:45:57'),
(108, 58, 'Hồ sơ IPE627EEA27E70 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/38', 1, '2019-11-14 10:01:53', '2019-11-14 10:01:53'),
(110, 53, 'Hồ sơ EF201911000040 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/40', 1, '2019-11-14 10:03:11', '2019-11-14 10:03:11'),
(112, 53, 'Hồ sơ EF201911000042 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/42', 1, '2019-11-14 10:03:45', '2019-11-14 10:03:45'),
(113, 52, 'Hồ sơ EF201911000043 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/43', 1, '2019-11-14 10:04:27', '2019-11-14 10:04:27'),
(115, 53, 'Hồ sơ EF201911000045 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/45', 1, '2019-11-14 10:04:56', '2019-11-14 10:04:56'),
(117, 55, 'Hồ sơ EF201911000047 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/47', 1, '2019-11-14 10:05:28', '2019-11-14 10:05:28'),
(118, 52, 'Hồ sơ EF201911000048 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/48', 1, '2019-11-14 10:06:01', '2019-11-14 10:06:01'),
(119, 54, 'Hồ sơ EF201911000049 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/49', 1, '2019-11-14 10:06:28', '2019-11-14 10:06:28'),
(120, 53, 'Hồ sơ EF201911000050 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/50', 1, '2019-11-14 10:07:18', '2019-11-14 10:07:18'),
(122, 52, 'Hồ sơ EF201911000052 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/52', 1, '2019-11-14 10:07:50', '2019-11-14 10:07:50'),
(123, 55, 'Hồ sơ EF201911000053 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/53', 1, '2019-11-14 10:08:19', '2019-11-14 10:08:19'),
(124, 54, 'Hồ sơ EF201911000054 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/54', 1, '2019-11-14 10:08:48', '2019-11-14 10:08:48'),
(125, 57, 'Hồ sơ IP5E3B140D169D đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/7', 1, '2019-11-14 10:11:14', '2019-11-14 10:11:14'),
(127, 55, 'Hồ sơ EF201911000055 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/55', 1, '2019-11-14 10:18:17', '2019-11-14 10:18:17'),
(129, 52, 'Hồ sơ EF201911000057 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/57', 1, '2019-11-14 10:19:02', '2019-11-14 10:19:02'),
(130, 53, 'Hồ sơ EF201911000058 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/58', 1, '2019-11-14 10:19:33', '2019-11-14 10:19:33'),
(131, 52, 'Hồ sơ EF201911000059 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/59', 1, '2019-11-14 10:20:06', '2019-11-14 10:20:06'),
(132, 53, 'Hồ sơ EF201911000060 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/60', 1, '2019-11-14 10:20:32', '2019-11-14 10:20:32'),
(134, 56, 'Hồ sơ IPA166A4F961BA đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/39', 1, '2019-11-14 10:23:53', '2019-11-14 10:23:53'),
(135, 58, 'Hồ sơ IPA166A4F961BA đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/39', 1, '2019-11-14 10:27:44', '2019-11-14 10:27:44'),
(137, 59, 'Hồ sơ IPA166A4F961BA đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/39', 1, '2019-11-14 10:28:21', '2019-11-14 10:28:21'),
(138, 54, 'Hồ sơ EF201911000059 đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/59', 1, '2019-11-14 10:39:12', '2019-11-14 10:39:12'),
(139, 56, 'Hồ sơ EF201911000059 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/59', 1, '2019-11-14 10:40:13', '2019-11-14 10:40:13'),
(141, 58, 'Hồ sơ EF201911000059 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/59', 1, '2019-11-14 10:41:38', '2019-11-14 10:41:38'),
(142, 55, 'Hồ sơ IP592A862AAB9C đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/11', 1, '2019-11-14 10:42:55', '2019-11-14 10:42:55'),
(143, 54, 'Hồ sơ EF201911000050 đang chờ bạn Thẩm ĐỊnh Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/50', 1, '2019-11-14 10:56:23', '2019-11-14 10:56:23'),
(144, 57, 'Hồ sơ EF201911000050 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/50', 1, '2019-11-14 10:57:43', '2019-11-14 10:57:43'),
(146, 55, 'Hồ sơ EF201911000052 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/52', 1, '2019-11-14 12:16:12', '2019-11-14 12:16:12'),
(147, 1, 'Hồ sơ EF201911000052 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/52', 1, '2019-11-14 12:17:29', '2019-11-14 12:17:29'),
(149, 55, 'Hồ sơ EF201911000055 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/55', 1, '2019-11-15 03:27:11', '2019-11-15 03:27:11'),
(150, 1, 'Hồ sơ EF201911000054 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/54', 1, '2019-11-15 03:27:57', '2019-11-15 03:27:57'),
(152, 1, 'Hồ sơ EF201911000054 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/54', 1, '2019-11-15 03:28:42', '2019-11-15 03:28:42'),
(154, 1, 'Hồ sơ EF201911000054 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/54', 1, '2019-11-15 03:29:17', '2019-11-15 03:29:17'),
(156, 57, 'Hồ sơ EF201911000055 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/55', 1, '2019-11-15 03:30:36', '2019-11-15 03:30:36'),
(158, 58, 'Hồ sơ EF201911000055 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/55', 1, '2019-11-15 03:32:18', '2019-11-15 03:32:18'),
(159, 1, 'Hồ sơ EF201911000054 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/54', 1, '2019-11-15 03:33:24', '2019-11-15 03:33:24'),
(160, 59, 'Hồ sơ EF201911000055 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/55', 1, '2019-11-15 03:49:11', '2019-11-15 03:49:11'),
(162, 53, 'Hồ sơ EF201911000062 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/62', 1, '2019-11-15 04:23:11', '2019-11-15 04:23:11'),
(163, 1, 'Hồ sơ EF201911000062 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/62', 1, '2019-11-15 04:24:31', '2019-11-15 04:24:31'),
(164, 1, 'Hồ sơ EF201911000062 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/62', 1, '2019-11-15 04:26:21', '2019-11-15 04:26:21'),
(165, 55, 'Hồ sơ EF201911000047 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/47', 1, '2019-11-15 04:40:18', '2019-11-15 04:40:18'),
(167, 58, 'Hồ sơ EF201911000047 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/47', 1, '2019-11-15 04:42:12', '2019-11-15 04:42:12'),
(169, 52, 'Hồ sơ EF201911000063 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/63', 1, '2019-11-15 04:44:18', '2019-11-15 04:44:18'),
(171, 1, 'Hồ sơ EF201911000063 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/63', 1, '2019-11-15 04:44:34', '2019-11-15 04:44:34'),
(173, 52, 'Hồ sơ IP9047AD0CF579 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/21', 1, '2019-11-15 04:49:22', '2019-11-15 04:49:22'),
(175, 53, 'Hồ sơ IP9047AD0CF579 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/21', 1, '2019-11-15 04:54:09', '2019-11-15 04:54:09'),
(176, 54, 'Hồ sơ IP9047AD0CF579 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/21', 1, '2019-11-15 04:55:21', '2019-11-15 04:55:21'),
(178, 54, 'Hồ sơ EF201911000064 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/64', 1, '2019-11-15 06:43:51', '2019-11-15 06:43:51'),
(180, 59, 'Hồ sơ EF201911000064 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/64', 1, '2019-11-15 06:44:44', '2019-11-15 06:44:44'),
(181, 52, 'Hồ sơ EF201911000064 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/64', 1, '2019-11-15 06:45:04', '2019-11-15 06:45:04'),
(182, 52, 'Hồ sơ EF201911000064 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/64', 1, '2019-11-15 06:45:43', '2019-11-15 06:45:43'),
(184, 57, 'Hồ sơ EF201911000064 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/64', 1, '2019-11-15 06:45:59', '2019-11-15 06:45:59'),
(186, 55, 'Hồ sơ EF201911000064 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/64', 1, '2019-11-15 06:46:20', '2019-11-15 06:46:20'),
(187, 104, 'Hồ sơ EF201911000064 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/64', 1, '2019-11-15 06:51:29', '2019-11-15 06:51:29'),
(188, 53, 'Hồ sơ EF201911000066 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/66', 1, '2019-11-15 07:53:34', '2019-11-15 07:53:34'),
(190, 54, 'Hồ sơ EF201911000068 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/68', 1, '2019-11-15 08:11:14', '2019-11-15 08:11:14'),
(192, 54, 'Hồ sơ EF201911000068 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/68', 1, '2019-11-15 08:20:43', '2019-11-15 08:20:43'),
(194, 56, 'Hồ sơ EF201911000068 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/68', 1, '2019-11-15 08:34:14', '2019-11-15 08:34:14'),
(195, 58, 'Hồ sơ EF201911000068 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/68', 1, '2019-11-15 08:54:24', '2019-11-15 08:54:24'),
(197, 59, 'Hồ sơ EF201911000068 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/68', 1, '2019-11-15 09:09:59', '2019-11-15 09:09:59'),
(199, 60, 'Hồ sơ EF201911000068 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/68', 1, '2019-11-15 09:12:29', '2019-11-15 09:12:29'),
(201, 1, 'Hồ sơ EF201911000050 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/50', 1, '2019-11-15 12:02:10', '2019-11-15 12:02:10'),
(202, 1, 'Hồ sơ EF201911000054 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/54', 1, '2019-11-15 12:17:39', '2019-11-15 12:17:39'),
(203, 53, 'Hồ sơ EF201911000069 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/69', 1, '2019-11-15 12:22:09', '2019-11-15 12:22:09'),
(205, 1, 'Hồ sơ EF201911000069 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/69', 1, '2019-11-15 12:23:27', '2019-11-15 12:23:27'),
(206, 1, 'Hồ sơ EF201911000069 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/69', 1, '2019-11-15 12:28:31', '2019-11-15 12:28:31'),
(207, 1, 'Hồ sơ EF201911000069 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/69', 1, '2019-11-15 12:29:28', '2019-11-15 12:29:28'),
(209, 1, 'Hồ sơ EF201911000069 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/69', 1, '2019-11-15 12:30:11', '2019-11-15 12:30:11'),
(210, 1, 'Hồ sơ EF201911000069 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/69', 1, '2019-11-15 12:30:50', '2019-11-15 12:30:50'),
(211, 1, 'Hồ sơ EF201911000069 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/69', 1, '2019-11-15 12:31:25', '2019-11-15 12:31:25'),
(212, 52, 'Hồ sơ EF201911000070 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/70', 1, '2019-11-18 01:55:44', '2019-11-18 01:55:44'),
(213, 55, 'Hồ sơ EF201911000070 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/70', 1, '2019-11-18 01:58:41', '2019-11-18 01:58:41'),
(215, 58, 'Hồ sơ EF201911000070 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/70', 1, '2019-11-18 02:15:02', '2019-11-18 02:15:02'),
(216, 56, 'Hồ sơ EF201911000070 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/70', 1, '2019-11-18 02:16:10', '2019-11-18 02:16:10'),
(217, 53, 'Hồ sơ EF201911000071 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/71', 1, '2019-11-18 03:02:13', '2019-11-18 03:02:13'),
(218, 54, 'Hồ sơ EF201911326369 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/72', 1, '2019-11-18 03:48:38', '2019-11-18 03:48:38'),
(220, 1, 'Hồ sơ EF201911326369 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/72', 1, '2019-11-18 03:51:59', '2019-11-18 03:51:59'),
(222, 1, 'Hồ sơ EF201911326369 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/72', 1, '2019-11-18 03:52:13', '2019-11-18 03:52:13'),
(223, 52, 'Hồ sơ EF201911326370 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/73', 1, '2019-11-18 06:41:40', '2019-11-18 06:41:40'),
(224, 52, 'Hồ sơ EF201911326370 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/74', 1, '2019-11-18 06:41:40', '2019-11-18 06:41:40'),
(226, 53, 'Hồ sơ EF201911326371 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/76', 1, '2019-11-18 08:23:02', '2019-11-18 08:23:02'),
(228, 59, 'Hồ sơ EF201911000047 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/47', 1, '2019-11-18 10:38:47', '2019-11-18 10:38:47'),
(230, 54, 'Hồ sơ IP58ADA0D8D4FC đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/32', 1, '2019-11-18 10:47:42', '2019-11-18 10:47:42'),
(232, 58, 'Hồ sơ IP58ADA0D8D4FC đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/32', 1, '2019-11-18 10:49:21', '2019-11-18 10:49:21'),
(234, 55, 'Hồ sơ EF201911326372 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/78', 1, '2019-11-19 03:58:00', '2019-11-29 06:26:48'),
(236, 55, 'Hồ sơ EF201911326373 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/80', 1, '2019-11-19 04:04:37', '2019-11-19 04:04:37'),
(238, 53, 'Hồ sơ EF201911326374 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/82', 1, '2019-11-19 04:15:04', '2019-11-19 04:15:04'),
(239, 53, 'Hồ sơ EF201911326374 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/81', 1, '2019-11-19 04:15:04', '2019-11-19 04:15:04'),
(241, 55, 'Hồ sơ EF201911326375 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/83', 1, '2019-11-19 06:15:52', '2019-11-19 06:15:52'),
(242, 58, 'Hồ sơ IP5165ABF823C5 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/36', 1, '2019-11-19 06:26:11', '2019-11-19 06:26:11'),
(244, 52, 'Hồ sơ EF201911326376 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/84', 1, '2019-11-19 06:28:55', '2019-11-19 06:28:55'),
(245, 54, 'Hồ sơ EF201911326376 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/84', 1, '2019-11-19 06:33:17', '2019-11-19 06:33:17'),
(247, 54, 'Hồ sơ EF201911326377 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/85', 1, '2019-11-19 07:00:41', '2019-11-19 07:00:41'),
(249, 54, 'Hồ sơ EF201911326377 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/85', 1, '2019-11-19 07:03:13', '2019-11-19 07:03:13'),
(250, 57, 'Hồ sơ EF201911326377 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/85', 1, '2019-11-19 07:04:00', '2019-11-19 07:04:00'),
(251, 58, 'Hồ sơ EF201911326377 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/85', 1, '2019-11-19 07:05:09', '2019-11-19 07:05:09'),
(252, 59, 'Hồ sơ EF201911326377 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/85', 1, '2019-11-19 07:06:11', '2019-11-19 07:06:11'),
(254, 60, 'Hồ sơ EF201911326377 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/85', 1, '2019-11-19 07:07:09', '2019-11-19 07:07:09'),
(256, 53, 'Hồ sơ EF201911326378 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/86', 1, '2019-11-19 07:24:45', '2019-11-19 07:24:45'),
(257, 52, 'Hồ sơ EF201911326379 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/87', 1, '2019-11-19 07:28:57', '2019-11-19 07:28:57'),
(258, 55, 'Hồ sơ EF201911326378 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/86', 1, '2019-11-19 07:32:11', '2019-11-19 07:32:11'),
(259, 53, 'Hồ sơ EF201911326380 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/89', 1, '2019-11-19 07:32:30', '2019-11-19 07:32:30'),
(260, 1, 'Hồ sơ EF201911326380 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/89', 1, '2019-11-19 07:33:32', '2019-11-19 07:33:32'),
(261, 1, 'Hồ sơ EF201911326380 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/89', 1, '2019-11-19 07:33:50', '2019-11-19 07:33:50'),
(263, 52, 'Hồ sơ EF201911326641 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/611', 1, '2019-11-19 10:03:49', '2019-11-28 09:45:33'),
(265, 55, 'Hồ sơ EF201911326642 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/613', 1, '2019-11-19 10:10:14', '2019-11-19 10:10:14'),
(266, 55, 'Hồ sơ EF201911326643 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/614', 1, '2019-11-19 10:11:22', '2019-11-19 10:11:22'),
(268, 53, 'Hồ sơ EF201911326644 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/616', 1, '2019-11-19 10:12:12', '2019-11-19 10:12:12'),
(270, 52, 'Hồ sơ EF201911326645 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/618', 1, '2019-11-19 10:48:38', '2019-11-19 10:48:38'),
(272, 54, 'Hồ sơ EF201911326646 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/620', 1, '2019-11-20 02:49:31', '2019-11-20 02:49:31'),
(274, 52, 'Hồ sơ EF201911326647 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/622', 1, '2019-11-20 03:19:38', '2019-11-20 03:19:38'),
(275, 58, 'Hồ sơ EF201911326376 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/84', 1, '2019-11-20 04:14:41', '2019-11-20 04:14:41'),
(277, 56, 'Hồ sơ EF201911326376 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/84', 1, '2019-11-20 04:18:29', '2019-11-20 04:18:29'),
(278, 55, 'Hồ sơ EF201911326648 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/624', 1, '2019-11-20 06:45:14', '2019-11-20 06:45:14'),
(279, 54, 'Hồ sơ EF201911326649 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/625', 1, '2019-11-20 07:02:35', '2019-11-20 07:02:35'),
(280, 55, 'Hồ sơ EF201911326648 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/624', 1, '2019-11-20 07:06:52', '2019-11-20 07:06:52'),
(282, 54, 'Hồ sơ EF201911326649 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/625', 1, '2019-11-20 07:06:53', '2019-11-20 07:06:53'),
(284, 58, 'Hồ sơ EF201911326648 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/624', 1, '2019-11-20 07:07:23', '2019-11-20 07:07:23'),
(286, 59, 'Hồ sơ EF201911326648 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/624', 1, '2019-11-20 07:10:30', '2019-11-20 07:10:30'),
(288, 58, 'Hồ sơ EF201911326649 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/625', 1, '2019-11-20 07:19:26', '2019-11-20 07:19:26'),
(290, 59, 'Hồ sơ EF201911326649 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/625', 1, '2019-11-20 07:20:21', '2019-11-20 07:20:21'),
(291, 53, 'Hồ sơ EF201911326650 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/627', 1, '2019-11-20 07:22:51', '2019-11-20 07:22:51'),
(293, 55, 'Hồ sơ EF201911326650 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/627', 1, '2019-11-20 07:29:46', '2019-11-20 07:29:46'),
(294, 56, 'Hồ sơ EF201911326650 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/627', 1, '2019-11-20 07:32:02', '2019-11-20 07:32:02'),
(296, 58, 'Hồ sơ EF201911326650 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/627', 1, '2019-11-20 07:33:41', '2019-11-20 07:33:41'),
(298, 59, 'Hồ sơ EF201911326650 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/627', 1, '2019-11-20 07:37:15', '2019-11-20 07:37:15'),
(299, 60, 'Hồ sơ EF201911326650 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/627', 1, '2019-11-20 07:51:15', '2019-11-20 07:51:15'),
(300, 53, 'Hồ sơ EF201911326651 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/628', 1, '2019-11-20 07:54:03', '2019-11-20 07:54:03'),
(301, 54, 'Hồ sơ EF201911326651 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/628', 1, '2019-11-20 07:56:44', '2019-11-20 07:56:44'),
(303, 57, 'Hồ sơ EF201911326651 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/628', 1, '2019-11-20 08:04:55', '2019-11-20 08:04:55'),
(304, 58, 'Hồ sơ EF201911326651 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/628', 1, '2019-11-20 08:06:09', '2019-11-20 08:06:09'),
(306, 59, 'Hồ sơ EF201911326651 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/628', 1, '2019-11-20 08:06:58', '2019-11-20 08:06:58'),
(307, 52, 'Hồ sơ EF201911326652 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/629', 1, '2019-11-21 06:22:33', '2019-11-21 06:22:33'),
(308, 55, 'Hồ sơ EF201911326652 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/629', 1, '2019-11-21 06:27:21', '2019-11-21 06:27:21'),
(309, 53, 'Hồ sơ EF201911326653 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/631', 1, '2019-11-21 06:30:25', '2019-11-21 06:30:25'),
(311, 52, 'Hồ sơ EF201911326654 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/633', 1, '2019-11-21 06:34:20', '2019-11-21 06:34:20'),
(312, 1, 'Hồ sơ EF201911326654 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/633', 1, '2019-11-21 06:34:38', '2019-11-21 06:34:38'),
(313, 1, 'Hồ sơ EF201911326654 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/633', 1, '2019-11-21 06:35:22', '2019-11-21 06:35:22'),
(314, 52, 'Hồ sơ EF201911326655 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/634', 1, '2019-11-21 06:52:51', '2019-11-21 06:52:51'),
(316, 1, 'Hồ sơ EF201911326655 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/634', 1, '2019-11-21 06:54:00', '2019-11-21 06:54:00'),
(317, 1, 'Hồ sơ EF201911326655 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/634', 1, '2019-11-21 06:54:25', '2019-11-21 06:54:25'),
(319, 1, 'Hồ sơ IP65AB28AF046E đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/16', 1, '2019-11-21 07:07:56', '2019-11-21 07:07:56'),
(320, 54, 'Hồ sơ EF201911326656 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/636', 1, '2019-11-21 07:14:29', '2019-11-21 07:14:29'),
(321, 53, 'Hồ sơ EF201911326657 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/637', 1, '2019-11-21 07:16:02', '2019-11-21 07:16:02'),
(322, 55, 'Hồ sơ EF201911326657 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/637', 1, '2019-11-21 07:17:05', '2019-11-21 07:17:05'),
(323, 53, 'Hồ sơ EF201911326658 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/639', 1, '2019-11-21 07:18:11', '2019-11-21 07:18:11'),
(325, 54, 'Hồ sơ EF201911326658 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/639', 1, '2019-11-21 07:19:00', '2019-11-21 07:19:00'),
(326, 52, 'Hồ sơ EF201911326659 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/640', 1, '2019-11-21 07:20:50', '2019-11-21 07:20:50'),
(328, 55, 'Hồ sơ EF201911326659 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/640', 1, '2019-11-21 07:21:58', '2019-11-21 07:21:58'),
(329, 53, 'Hồ sơ EF201911326660 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/641', 1, '2019-11-21 07:46:53', '2019-11-21 07:46:53'),
(331, 1, 'Hồ sơ EF201911326660 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/641', 1, '2019-11-21 07:47:43', '2019-11-21 07:47:43'),
(333, 1, 'Hồ sơ EF201911326660 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/641', 1, '2019-11-21 07:48:07', '2019-11-29 04:39:57'),
(335, 57, 'Hồ sơ EF201911326658 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/639', 1, '2019-11-21 07:55:12', '2019-11-21 07:55:12'),
(337, 54, 'Hồ sơ EF201911326661 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/643', 1, '2019-11-21 07:56:26', '2019-11-21 07:56:26'),
(338, 54, 'Hồ sơ EF201911326661 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/643', 1, '2019-11-21 07:57:19', '2019-11-21 07:57:19'),
(340, 58, 'Hồ sơ EF201911326658 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/639', 1, '2019-11-21 08:09:25', '2019-11-21 08:09:25'),
(342, 52, 'Hồ sơ EF201911326662 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/644', 1, '2019-11-21 08:54:08', '2019-11-21 08:54:08'),
(344, 52, 'Hồ sơ EF201911326663 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/646', 1, '2019-11-21 09:10:46', '2019-11-21 09:10:46'),
(345, 59, 'Hồ sơ IP5165ABF823C5 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/36', 1, '2019-11-21 10:17:42', '2019-11-21 10:17:42'),
(346, 55, 'Hồ sơ EF201911326666 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/652', 1, '2019-11-21 11:07:02', '2019-11-21 11:07:02'),
(347, 53, 'Hồ sơ EF201911326667 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/653', 1, '2019-11-21 11:16:45', '2019-11-21 11:16:45'),
(348, 55, 'Hồ sơ EF201911326668 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/654', 1, '2019-11-22 03:29:36', '2019-11-22 03:29:36'),
(349, 53, 'Hồ sơ EF201911326669 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/655', 1, '2019-11-22 04:26:33', '2019-11-22 04:26:33'),
(350, 54, 'Hồ sơ EF201911326666 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/652', 1, '2019-11-22 04:48:35', '2019-11-22 04:48:35'),
(351, 54, 'Hồ sơ EF201911326372 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/78', 1, '2019-11-22 04:50:25', '2019-11-29 06:26:48'),
(352, 55, 'Hồ sơ IP9047AD0CF579 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/21', 1, '2019-11-22 04:51:27', '2019-11-22 04:51:27'),
(354, 55, 'Hồ sơ IP9047AD0CF579 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/21', 1, '2019-11-22 04:56:26', '2019-11-22 04:56:26'),
(356, 56, 'Hồ sơ IP9047AD0CF579 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/21', 1, '2019-11-22 04:56:53', '2019-11-22 04:56:53'),
(357, 52, 'Hồ sơ EF201911326670 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/657', 1, '2019-11-22 07:04:26', '2019-11-22 07:04:26'),
(358, 52, 'Hồ sơ EF201911326671 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/658', 1, '2019-11-22 07:08:21', '2019-11-22 07:08:21'),
(360, 54, 'Hồ sơ EF201911326670 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/657', 1, '2019-11-22 07:18:33', '2019-11-22 07:18:33'),
(362, 55, 'Hồ sơ EF201911326671 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/658', 1, '2019-11-22 07:21:59', '2019-11-22 07:21:59'),
(364, 56, 'Hồ sơ EF201911326671 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/658', 1, '2019-11-22 07:24:53', '2019-11-22 07:24:53'),
(366, 58, 'Hồ sơ EF201911326671 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/658', 1, '2019-11-22 07:25:59', '2019-11-22 07:25:59'),
(368, 59, 'Hồ sơ EF201911326671 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/658', 1, '2019-11-22 07:26:36', '2019-11-22 07:26:36'),
(369, 60, 'Hồ sơ EF201911326671 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/658', 1, '2019-11-22 07:27:42', '2019-11-22 07:27:42'),
(370, 53, 'Hồ sơ EF201911326672 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/660', 1, '2019-11-22 07:29:29', '2019-11-22 07:29:29'),
(372, 53, 'Hồ sơ EF201911326673 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/662', 1, '2019-11-22 07:37:28', '2019-11-22 07:37:28'),
(373, 52, 'Hồ sơ EF201911326674 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/663', 1, '2019-11-22 07:38:04', '2019-11-22 07:38:04'),
(375, 54, 'Hồ sơ EF201911326675 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/665', 1, '2019-11-22 07:42:27', '2019-11-22 07:42:27'),
(377, 55, 'Hồ sơ EF201911326673 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/662', 1, '2019-11-22 08:49:46', '2019-11-22 08:49:46'),
(379, 53, 'Hồ sơ EF201911326676 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/667', 1, '2019-11-22 08:52:44', '2019-11-22 08:52:44'),
(381, 52, 'Hồ sơ EF201911326677 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/669', 1, '2019-11-22 08:56:19', '2019-11-22 08:56:19'),
(382, 52, 'Hồ sơ EF201911326678 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/670', 1, '2019-11-22 09:07:25', '2019-11-22 09:07:25'),
(383, 54, 'Hồ sơ EF201911326679 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/671', 1, '2019-11-22 09:25:40', '2019-11-22 09:25:40'),
(385, 54, 'Hồ sơ EF201911326678 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/670', 1, '2019-11-22 09:27:03', '2019-11-22 09:27:03'),
(386, 57, 'Hồ sơ EF201911326678 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/670', 1, '2019-11-22 09:32:05', '2019-11-22 09:32:05'),
(388, 54, 'Hồ sơ EF201911326679 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/671', 1, '2019-11-22 10:05:43', '2019-11-22 10:05:43'),
(390, 53, 'Hồ sơ EF201911326680 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/672', 1, '2019-11-22 10:40:10', '2019-11-22 10:40:10'),
(391, 52, 'Hồ sơ EF201911326681 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/673', 1, '2019-11-23 03:00:52', '2019-11-23 03:00:52'),
(392, 55, 'Hồ sơ EF201911326681 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/673', 1, '2019-11-23 03:02:39', '2019-11-23 03:02:39'),
(394, 53, 'Hồ sơ EF201911326682 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/674', 1, '2019-11-23 03:33:36', '2019-11-23 03:33:36'),
(395, 53, 'Hồ sơ EF201911326683 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/675', 1, '2019-11-23 03:49:14', '2019-11-23 03:49:14'),
(396, 55, 'Hồ sơ EF201911000045 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/45', 1, '2019-11-23 03:51:31', '2019-11-23 03:51:31'),
(398, 55, 'Hồ sơ EF201911326683 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/675', 1, '2019-11-23 04:07:39', '2019-11-23 04:07:39'),
(400, 52, 'Hồ sơ EF201911326684 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/676', 1, '2019-11-23 04:13:53', '2019-11-23 04:13:53'),
(401, 54, 'Hồ sơ EF201911326684 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/676', 1, '2019-11-23 04:16:53', '2019-11-23 04:16:53'),
(403, 52, 'Hồ sơ EF201911326685 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/677', 1, '2019-11-23 04:21:52', '2019-11-23 04:21:52'),
(404, 53, 'Hồ sơ EF201911326686 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/678', 1, '2019-11-23 04:40:19', '2019-11-23 04:40:19'),
(406, 54, 'Hồ sơ EF201911326687 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/680', 1, '2019-11-23 04:42:45', '2019-11-23 04:42:45'),
(408, 54, 'Hồ sơ EF201911326687 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/680', 1, '2019-11-23 04:44:46', '2019-11-23 04:44:46'),
(409, 55, 'Hồ sơ EF201911326686 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/678', 1, '2019-11-23 04:45:50', '2019-11-23 04:45:50'),
(411, 56, 'Hồ sơ EF201911326686 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/678', 1, '2019-11-23 04:47:04', '2019-11-23 04:47:04'),
(412, 58, 'Hồ sơ EF201911326686 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/678', 1, '2019-11-23 04:47:57', '2019-11-23 04:47:57'),
(413, 59, 'Hồ sơ EF201911326686 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/678', 1, '2019-11-23 04:48:49', '2019-11-23 04:48:49'),
(415, 60, 'Hồ sơ EF201911326686 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/678', 1, '2019-11-23 04:49:42', '2019-11-23 04:49:42'),
(417, 53, 'Hồ sơ EF201911326688 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/681', 1, '2019-11-23 06:27:44', '2019-11-23 06:27:44'),
(418, 55, 'Hồ sơ EF201911326688 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/681', 1, '2019-11-23 06:30:00', '2019-11-23 06:30:00'),
(420, 52, 'Hồ sơ EF201911326689 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/682', 1, '2019-11-23 07:45:15', '2019-11-23 07:45:15'),
(422, 53, 'Hồ sơ EF201911326690 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/684', 1, '2019-11-23 07:55:56', '2019-11-23 07:55:56'),
(423, 52, 'Hồ sơ EF201911326691 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/685', 1, '2019-11-23 08:00:57', '2019-11-23 08:00:57'),
(425, 54, 'Hồ sơ EF201911326691 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/685', 1, '2019-11-23 08:03:26', '2019-11-23 08:03:26'),
(426, 57, 'Hồ sơ EF201911326691 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/685', 1, '2019-11-23 08:08:34', '2019-11-23 08:08:34'),
(427, 58, 'Hồ sơ EF201911326691 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/685', 1, '2019-11-23 08:16:32', '2019-11-23 08:16:32'),
(429, 53, 'Hồ sơ EF201911326692 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/687', 1, '2019-11-25 03:24:14', '2019-11-25 03:24:14'),
(430, 52, 'Hồ sơ EF201911326693 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/688', 1, '2019-11-25 03:56:45', '2019-11-25 03:56:45'),
(431, 57, 'Hồ sơ EF201911326657 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/637', 1, '2019-11-25 04:14:21', '2019-11-25 04:14:21'),
(432, 58, 'Hồ sơ EF201911326657 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/637', 1, '2019-11-25 04:16:31', '2019-11-25 04:16:31'),
(434, 59, 'Hồ sơ EF201911326657 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/637', 1, '2019-11-25 04:23:50', '2019-11-25 04:23:50'),
(435, 60, 'Hồ sơ EF201911326657 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/637', 1, '2019-11-25 04:24:58', '2019-11-25 04:24:58'),
(436, 55, 'Hồ sơ EF201911326694 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/690', 1, '2019-11-25 04:31:57', '2019-11-25 04:31:57'),
(438, 55, 'Hồ sơ EF201911326694 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/690', 1, '2019-11-25 04:32:45', '2019-11-25 04:32:45'),
(439, 53, 'Hồ sơ EF201911326695 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/691', 1, '2019-11-25 04:35:34', '2019-11-25 04:35:34'),
(441, 54, 'Hồ sơ EF201911326695 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/691', 1, '2019-11-25 04:43:00', '2019-11-25 04:43:00'),
(442, 52, 'Hồ sơ EF201911326696 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/692', 1, '2019-11-25 06:21:40', '2019-11-25 06:21:40'),
(444, 55, 'Hồ sơ EF201911326696 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/692', 1, '2019-11-25 06:22:48', '2019-11-25 06:22:48'),
(445, 52, 'Hồ sơ EF201911326697 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/693', 1, '2019-11-25 06:29:03', '2019-11-25 06:29:03'),
(446, 53, 'Hồ sơ EF201911326698 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/694', 1, '2019-11-25 06:29:28', '2019-11-25 06:29:28'),
(447, 54, 'Hồ sơ EF201911326699 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/695', 1, '2019-11-25 06:29:52', '2019-11-25 06:29:52'),
(448, 55, 'Hồ sơ EF201911326700 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/696', 1, '2019-11-25 06:30:20', '2019-11-25 06:30:20'),
(449, 56, 'Hồ sơ EF201911326696 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/692', 1, '2019-11-25 06:47:38', '2019-11-25 06:47:38'),
(450, 54, 'Hồ sơ EF201911326677 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/669', 1, '2019-11-25 06:51:18', '2019-11-25 06:51:18'),
(451, 56, 'Hồ sơ EF201911326677 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/669', 1, '2019-11-25 07:00:11', '2019-11-25 07:00:11');
INSERT INTO `cms_notifications` (`id`, `id_cms_users`, `content`, `url`, `is_read`, `created_at`, `updated_at`) VALUES
(452, 52, 'Hồ sơ EF201911326701 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/698', 1, '2019-11-25 07:12:16', '2019-11-25 07:12:16'),
(453, 53, 'Hồ sơ EF201911326702 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/699', 1, '2019-11-25 08:52:24', '2019-11-25 08:52:24'),
(454, 52, 'Hồ sơ EF201911326703 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/700', 1, '2019-11-25 09:03:47', '2019-11-25 09:03:47'),
(456, 55, 'Hồ sơ EF201911326703 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/700', 1, '2019-11-25 09:09:40', '2019-11-25 09:09:40'),
(457, 57, 'Hồ sơ EF201911326703 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/700', 1, '2019-11-25 09:11:24', '2019-11-25 09:11:24'),
(459, 58, 'Hồ sơ EF201911326703 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/700', 1, '2019-11-25 09:12:47', '2019-11-25 09:12:47'),
(461, 59, 'Hồ sơ EF201911326703 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/700', 1, '2019-11-25 09:23:38', '2019-11-25 09:23:38'),
(462, 60, 'Hồ sơ EF201911326703 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/700', 1, '2019-11-25 09:25:50', '2019-11-25 09:25:50'),
(464, 54, 'Hồ sơ EF201911326704 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/702', 1, '2019-11-26 04:02:21', '2019-11-26 04:02:21'),
(466, 53, 'Hồ sơ EF201911326705 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/704', 1, '2019-11-26 04:26:18', '2019-11-26 04:26:18'),
(468, 55, 'Hồ sơ EF201911326707 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/706', 1, '2019-11-26 06:21:13', '2019-11-26 06:21:13'),
(470, 52, 'Hồ sơ EF201911326708 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/708', 1, '2019-11-27 03:44:53', '2019-11-27 03:44:53'),
(471, 53, 'Hồ sơ EF201911326709 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/709', 1, '2019-11-27 07:41:33', '2019-11-27 07:41:33'),
(473, 54, 'Hồ sơ EF201911326710 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/711', 1, '2019-11-27 07:43:08', '2019-11-27 07:43:08'),
(475, 52, 'Hồ sơ EF201911326711 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/713', 1, '2019-11-27 07:43:31', '2019-11-27 07:43:31'),
(477, 53, 'Hồ sơ EF201911326713 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/717', 1, '2019-11-27 08:03:55', '2019-11-27 08:03:55'),
(479, 55, 'Hồ sơ EF201911326714 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/719', 1, '2019-11-27 08:03:56', '2019-11-27 08:03:56'),
(481, 54, 'Hồ sơ EF201911326715 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/721', 1, '2019-11-27 08:03:57', '2019-11-29 02:13:28'),
(483, 52, 'Hồ sơ EF201911326716 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/723', 1, '2019-11-27 08:41:35', '2019-11-27 08:41:35'),
(484, 53, 'Hồ sơ EF201911326717 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/724', 1, '2019-11-27 08:55:56', '2019-11-27 08:55:56'),
(485, 54, 'Hồ sơ EF201911326717 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/724', 1, '2019-11-27 08:58:42', '2019-11-27 08:58:42'),
(487, 57, 'Hồ sơ EF201911326717 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/724', 1, '2019-11-27 09:23:17', '2019-11-27 09:23:17'),
(489, 58, 'Hồ sơ EF201911326717 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/724', 1, '2019-11-27 09:35:36', '2019-11-27 09:35:36'),
(490, 55, 'Hồ sơ EF201911326718 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/726', 1, '2019-11-27 09:41:08', '2019-11-27 09:41:08'),
(491, 59, 'Hồ sơ EF201911326717 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/724', 1, '2019-11-27 09:49:26', '2019-11-27 09:49:26'),
(493, 52, 'Hồ sơ E2019110326719 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/727', 1, '2019-11-27 11:18:37', '2019-11-27 11:18:37'),
(495, 54, 'Hồ sơ E2019110326720 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/729', 1, '2019-11-27 11:18:38', '2019-11-27 11:18:38'),
(497, 55, 'Hồ sơ E2019110326721 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/731', 1, '2019-11-27 11:18:39', '2019-11-27 11:18:39'),
(498, 53, 'Hồ sơ E2019110326721 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/731', 1, '2019-11-27 11:49:33', '2019-11-27 11:49:33'),
(500, 55, 'Hồ sơ E2019110326721 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/731', 1, '2019-11-27 11:52:04', '2019-11-27 11:52:04'),
(501, 56, 'Hồ sơ E2019110326721 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/731', 1, '2019-11-27 11:58:50', '2019-11-27 11:58:50'),
(503, 58, 'Hồ sơ E2019110326721 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/731', 1, '2019-11-27 12:00:18', '2019-11-27 12:00:18'),
(504, 59, 'Hồ sơ E2019110326721 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/731', 1, '2019-11-27 12:02:32', '2019-11-27 12:02:32'),
(505, 60, 'Hồ sơ E2019110326721 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/731', 1, '2019-11-27 12:03:54', '2019-11-27 12:03:54'),
(506, 53, 'Hồ sơ E2019110326722 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/732', 1, '2019-11-28 02:08:52', '2019-11-28 02:08:52'),
(508, 54, 'Hồ sơ EF201911326676 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/667', 1, '2019-11-28 02:22:01', '2019-11-28 02:22:01'),
(509, 55, 'Hồ sơ E2019110326722 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/732', 1, '2019-11-28 02:25:06', '2019-11-28 02:25:06'),
(510, 56, 'Hồ sơ E2019110326722 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/732', 1, '2019-11-28 03:19:30', '2019-11-28 03:19:30'),
(511, 58, 'Hồ sơ E2019110326722 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/732', 1, '2019-11-28 03:23:12', '2019-11-28 03:23:12'),
(512, 59, 'Hồ sơ E2019110326722 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/732', 1, '2019-11-28 03:25:10', '2019-11-28 03:25:10'),
(513, 54, 'Hồ sơ EF201911326370 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/73', 1, '2019-11-28 03:30:33', '2019-11-28 03:30:33'),
(514, 52, 'Hồ sơ E2019110326723 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/734', 1, '2019-11-28 03:39:05', '2019-11-28 03:39:05'),
(516, 54, 'Hồ sơ E2019110326723 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/734', 1, '2019-11-28 03:40:51', '2019-11-28 03:40:51'),
(518, 53, 'Hồ sơ E2019110326724 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/736', 1, '2019-11-28 04:02:30', '2019-11-28 04:02:30'),
(520, 55, 'Hồ sơ E2019110326724 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/736', 1, '2019-11-28 04:12:13', '2019-11-28 07:14:23'),
(522, 52, 'Hồ sơ E2019110326725 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/738', 1, '2019-11-28 08:38:19', '2019-11-28 08:41:24'),
(524, 54, 'Hồ sơ E2019110326725 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/738', 1, '2019-11-28 09:12:07', '2019-11-28 09:12:07'),
(526, 52, 'Hồ sơ E2019110326726 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/740', 1, '2019-11-28 09:44:04', '2019-11-28 09:48:48'),
(527, 55, 'Hồ sơ EF201911326641 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/611', 1, '2019-11-28 09:47:24', '2019-11-28 09:47:24'),
(529, 54, 'Hồ sơ E2019110326726 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/740', 1, '2019-11-28 09:50:17', '2019-11-28 09:53:45'),
(531, 57, 'Hồ sơ E2019110326726 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/740', 1, '2019-11-28 10:14:38', '2019-11-28 10:15:24'),
(532, 58, 'Hồ sơ E2019110326726 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/740', 1, '2019-11-28 10:16:07', '2019-11-28 10:17:04'),
(533, 59, 'Hồ sơ E2019110326726 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/740', 1, '2019-11-28 10:17:57', '2019-11-28 10:18:53'),
(534, 53, 'Hồ sơ E2019110326727 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/742', 1, '2019-11-28 11:12:17', '2019-11-28 11:15:13'),
(535, 55, 'Hồ sơ E2019110326727 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/742', 1, '2019-11-28 11:23:45', '2019-11-28 11:23:45'),
(536, 54, 'Hồ sơ E2019110326720 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/729', 1, '2019-11-29 02:18:40', '2019-11-29 02:18:40'),
(538, 52, 'Hồ sơ E2019110326728 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/744', 1, '2019-11-29 03:25:36', '2019-11-29 03:26:39'),
(539, 55, 'Hồ sơ E2019110326728 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/744', 1, '2019-11-29 03:31:28', '2019-11-29 03:40:14'),
(541, 56, 'Hồ sơ E2019110326728 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/744', 1, '2019-11-29 03:43:43', '2019-11-29 03:44:36'),
(543, 58, 'Hồ sơ E2019110326728 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/744', 1, '2019-11-29 03:46:42', '2019-11-29 03:48:50'),
(544, 53, 'Hồ sơ E2019110326729 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/746', 1, '2019-11-29 03:51:53', '2019-11-29 03:51:53'),
(545, 59, 'Hồ sơ E2019110326728 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/744', 1, '2019-11-29 03:53:37', '2019-11-29 03:54:18'),
(547, 53, 'Hồ sơ E2019110326730 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/747', 1, '2019-11-29 03:55:38', '2019-11-29 04:19:49'),
(548, 55, 'Hồ sơ E2019110326730 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/747', 1, '2019-11-29 04:20:23', '2019-11-29 04:21:48'),
(549, 57, 'Hồ sơ E2019110326730 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/747', 1, '2019-11-29 04:22:57', '2019-11-29 04:23:37'),
(551, 58, 'Hồ sơ E2019110326730 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/747', 1, '2019-11-29 04:26:12', '2019-11-29 04:26:43'),
(552, 59, 'Hồ sơ E2019110326730 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/747', 1, '2019-11-29 04:26:59', '2019-11-29 04:27:40'),
(553, 52, 'Hồ sơ E2019110326731 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/749', 1, '2019-11-29 04:31:13', '2019-11-29 04:31:13'),
(555, 53, 'Hồ sơ E2019110326732 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/751', 1, '2019-11-29 04:31:49', '2019-11-29 04:31:49'),
(557, 52, 'Hồ sơ E2019110326733 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/753', 1, '2019-11-29 04:35:07', '2019-11-29 04:35:07'),
(559, 54, 'Hồ sơ E2019110326734 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/755', 1, '2019-11-29 04:35:40', '2019-11-29 04:35:40'),
(561, 52, 'Hồ sơ E2019110326735 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/757', 1, '2019-11-29 04:35:46', '2019-11-29 04:35:46'),
(563, 53, 'Hồ sơ E2019110326736 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/759', 1, '2019-11-29 04:47:44', '2019-11-29 04:47:44'),
(565, 53, 'Hồ sơ E2019110326737 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/761', 1, '2019-11-29 06:16:21', '2019-11-29 06:16:21'),
(566, 52, 'Hồ sơ E2019110326738 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/762', 1, '2019-11-29 06:28:54', '2019-11-29 06:28:54'),
(567, 54, 'Hồ sơ E2019110326739 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/763', 1, '2019-11-29 06:48:50', '2019-11-29 06:52:56'),
(569, 54, 'Hồ sơ E2019110326739 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/763', 1, '2019-11-29 07:06:29', '2019-11-29 07:06:46'),
(570, 57, 'Hồ sơ E2019110326739 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/763', 1, '2019-11-29 07:25:47', '2019-11-29 07:25:47'),
(572, 58, 'Hồ sơ E2019110326739 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/763', 1, '2019-11-29 07:34:35', '2019-11-29 07:35:27'),
(574, 59, 'Hồ sơ E2019110326739 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/763', 1, '2019-11-29 07:39:29', '2019-11-29 07:40:29'),
(576, 55, 'Hồ sơ E2019110326740 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/764', 1, '2019-11-29 08:22:55', '2019-11-29 08:23:54'),
(577, 56, 'Hồ sơ EF201911326684 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/676', 1, '2019-11-29 10:10:08', '2019-11-29 10:10:46'),
(579, 53, 'Hồ sơ E2019120326741 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/765', 1, '2019-12-02 02:48:26', '2019-12-02 02:49:24'),
(581, 55, 'Hồ sơ E2019120326742 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/767', 1, '2019-12-02 06:28:15', '2019-12-02 06:28:15'),
(583, 52, 'Hồ sơ E2019120326743 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/769', 1, '2019-12-02 06:35:51', '2019-12-02 06:35:51'),
(585, 55, 'Hồ sơ E2019120326743 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/769', 1, '2019-12-02 06:37:27', '2019-12-02 07:51:07'),
(586, 53, 'Hồ sơ E2019120326744 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/770', 1, '2019-12-02 10:02:11', '2019-12-02 10:04:50'),
(588, 52, 'Hồ sơ E2019120326745 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/772', 1, '2019-12-02 10:20:17', '2019-12-02 10:21:30'),
(590, 56, 'Hồ sơ E2019120326743 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/769', 1, '2019-12-03 02:22:23', '2019-12-03 02:23:35'),
(592, 58, 'Hồ sơ E2019120326743 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/769', 1, '2019-12-03 02:25:28', '2019-12-03 02:26:15'),
(594, 59, 'Hồ sơ E2019120326743 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/769', 1, '2019-12-03 02:26:44', '2019-12-03 02:27:21'),
(595, 54, 'Hồ sơ E2019120326746 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/773', 1, '2019-12-03 04:01:31', '2019-12-03 04:05:32'),
(597, 54, 'Hồ sơ E2019120326746 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/773', 1, '2019-12-03 04:22:31', '2019-12-03 04:28:50'),
(599, 53, 'Hồ sơ E2019120326747 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/775', 1, '2019-12-03 06:50:07', '2019-12-03 06:52:06'),
(600, 55, 'Hồ sơ E2019120326747 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/775', 1, '2019-12-03 06:52:47', '2019-12-03 06:54:28'),
(601, 57, 'Hồ sơ E2019120326747 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/775', 1, '2019-12-03 07:11:01', '2019-12-03 07:11:01'),
(602, 58, 'Hồ sơ E2019120326747 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/775', 1, '2019-12-03 07:17:35', '2019-12-03 07:18:49'),
(604, 59, 'Hồ sơ E2019120326747 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/775', 1, '2019-12-03 07:20:04', '2019-12-03 07:20:47'),
(605, 60, 'Hồ sơ E2019120326747 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/775', 1, '2019-12-03 07:21:17', '2019-12-03 07:21:45'),
(606, 52, 'Hồ sơ E2019120326748 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/776', 1, '2019-12-03 08:41:27', '2019-12-03 08:42:02'),
(608, 55, 'Hồ sơ E2019120326748 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/776', 1, '2019-12-03 08:42:33', '2019-12-03 08:44:22'),
(610, 54, 'Hồ sơ EF201911326662 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/644', 1, '2019-12-03 09:52:21', '2019-12-03 09:52:21'),
(612, 52, 'Hồ sơ E2019120326749 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/778', 1, '2019-12-03 09:58:54', '2019-12-03 10:00:24'),
(614, 54, 'Hồ sơ E2019120326749 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/778', 1, '2019-12-03 10:00:57', '2019-12-03 10:01:52'),
(616, 58, 'Hồ sơ E2019120326748 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/776', 1, '2019-12-03 10:08:23', '2019-12-03 10:11:47'),
(617, 59, 'Hồ sơ E2019120326748 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/776', 1, '2019-12-03 10:12:00', '2019-12-03 10:12:00'),
(618, 53, 'Hồ sơ E2019120326750 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/780', 1, '2019-12-03 11:33:31', '2019-12-03 11:33:31'),
(620, 55, 'Hồ sơ E2019120326751 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/782', 1, '2019-12-03 11:33:33', '2019-12-03 11:34:30'),
(621, 53, 'Hồ sơ E2019120326752 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/783', 1, '2019-12-04 03:27:03', '2019-12-04 03:28:36'),
(623, 55, 'Hồ sơ E2019120326752 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/783', 1, '2019-12-04 03:29:13', '2019-12-04 03:33:11'),
(624, 57, 'Hồ sơ E2019120326752 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/783', 1, '2019-12-04 04:02:00', '2019-12-04 04:02:37'),
(625, 58, 'Hồ sơ E2019120326752 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/783', 1, '2019-12-04 04:04:58', '2019-12-04 04:06:18'),
(626, 59, 'Hồ sơ E2019120326752 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/783', 1, '2019-12-04 04:15:56', '2020-04-13 02:51:21'),
(627, 52, 'Hồ sơ E2019120326753 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/785', 1, '2019-12-05 07:47:28', '2019-12-05 07:49:06'),
(628, 54, 'Hồ sơ E2019120326753 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/785', 1, '2019-12-05 07:49:16', '2019-12-05 07:49:43'),
(630, 52, 'Hồ sơ E2019120326754 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/786', 1, '2019-12-05 08:17:46', '2019-12-05 08:18:27'),
(632, 54, 'Hồ sơ E2019120326754 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/786', 1, '2019-12-05 08:18:46', '2019-12-05 08:20:55'),
(633, 55, 'Hồ sơ E2019120326742 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/767', 1, '2019-12-06 02:00:20', '2019-12-06 02:00:22'),
(635, 55, 'Hồ sơ E2019120326742 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/767', 0, '2019-12-06 02:02:24', '2019-12-06 02:02:24'),
(637, 58, 'Hồ sơ E2019120326742 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/767', 1, '2019-12-06 02:03:31', '2019-12-06 02:04:25'),
(638, 53, 'Hồ sơ E2019120326755 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/788', 1, '2019-12-06 02:57:52', '2019-12-06 03:00:25'),
(640, 55, 'Hồ sơ E2019120326755 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/788', 1, '2019-12-06 03:02:12', '2019-12-16 02:53:33'),
(641, 53, 'Hồ sơ E2019120326756 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/789', 1, '2019-12-06 04:41:11', '2019-12-06 04:41:26'),
(642, 52, 'Hồ sơ E2019120326757 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/790', 1, '2019-12-09 08:11:40', '2019-12-17 02:01:19'),
(644, 53, 'Hồ sơ E2019120326758 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/792', 1, '2019-12-09 08:25:41', '2019-12-09 08:25:41'),
(646, 54, 'Hồ sơ E2019120326758 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/792', 1, '2019-12-09 08:28:48', '2019-12-09 08:32:22'),
(648, 52, 'Hồ sơ E2019120326760 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/796', 0, '2019-12-11 06:11:36', '2019-12-11 06:11:36'),
(650, 52, 'Hồ sơ E2019120326761 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/798', 0, '2019-12-11 06:11:47', '2019-12-11 06:11:47'),
(652, 53, 'Hồ sơ E2019120326762 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/800', 0, '2019-12-11 06:11:57', '2019-12-11 06:11:57'),
(654, 54, 'Hồ sơ E2019120326763 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/802', 1, '2019-12-11 06:12:08', '2020-03-24 17:54:29'),
(656, 55, 'Hồ sơ E2019120326764 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/804', 0, '2019-12-11 06:12:11', '2019-12-11 06:12:11'),
(658, 55, 'Hồ sơ E2019120326765 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/806', 0, '2019-12-11 06:12:50', '2019-12-11 06:12:50'),
(660, 53, 'Hồ sơ E2019120326766 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/808', 0, '2019-12-11 06:12:54', '2019-12-11 06:12:54'),
(662, 52, 'Hồ sơ E2019120326767 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/810', 0, '2019-12-11 06:12:55', '2019-12-11 06:12:55'),
(664, 54, 'Hồ sơ E2019120326768 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/812', 0, '2019-12-11 06:12:56', '2019-12-11 06:12:56'),
(666, 53, 'Hồ sơ E2019120326769 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/814', 1, '2019-12-11 06:12:58', '2019-12-11 06:12:58'),
(668, 54, 'Hồ sơ E2019120326770 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/816', 0, '2019-12-11 06:13:01', '2019-12-11 06:13:01'),
(670, 52, 'Hồ sơ E2019120326771 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/818', 0, '2019-12-11 06:13:04', '2019-12-11 06:13:04'),
(672, 55, 'Hồ sơ E2019120326772 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/820', 0, '2019-12-11 06:13:04', '2019-12-11 06:13:04'),
(674, 52, 'Hồ sơ E2019120326773 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/822', 0, '2019-12-11 06:13:05', '2019-12-11 06:13:05'),
(676, 55, 'Hồ sơ E2019120326774 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/824', 0, '2019-12-11 06:13:17', '2019-12-11 06:13:17'),
(678, 53, 'Hồ sơ E2019120326775 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/826', 0, '2019-12-11 06:13:21', '2019-12-11 06:13:21'),
(680, 54, 'Hồ sơ E2019120326776 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/828', 1, '2019-12-11 06:13:24', '2020-03-24 18:07:33'),
(682, 55, 'Hồ sơ E2019120326777 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/830', 0, '2019-12-11 06:13:25', '2019-12-11 06:13:25'),
(684, 52, 'Hồ sơ E2019120326778 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/832', 1, '2019-12-11 06:13:26', '2019-12-11 06:13:26'),
(686, 53, 'Hồ sơ E2019120326779 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/834', 0, '2019-12-11 06:13:29', '2019-12-11 06:13:29'),
(688, 54, 'Hồ sơ E2019120326780 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/836', 0, '2019-12-11 06:13:30', '2019-12-11 06:13:30'),
(690, 54, 'Hồ sơ E2019120326781 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/838', 0, '2019-12-11 06:13:49', '2019-12-11 06:13:49'),
(692, 53, 'Hồ sơ E2019120326782 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/840', 1, '2019-12-11 06:14:22', '2019-12-13 06:37:57'),
(694, 52, 'Hồ sơ E2019120326783 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/842', 1, '2019-12-11 06:14:24', '2019-12-13 06:39:02'),
(695, 55, 'Hồ sơ E2019120326784 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/843', 0, '2019-12-13 04:17:59', '2019-12-13 04:17:59'),
(696, 54, 'Hồ sơ E2019120326785 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/844', 0, '2019-12-13 04:57:50', '2019-12-13 04:57:50'),
(697, 55, 'Hồ sơ E2019120326786 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/845', 0, '2019-12-13 04:58:30', '2019-12-13 04:58:30'),
(698, 55, 'Hồ sơ E2019120326787 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/846', 0, '2019-12-13 04:59:13', '2019-12-13 04:59:13'),
(699, 54, 'Hồ sơ E2019120326788 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/847', 1, '2019-12-13 04:59:47', '2020-06-17 08:18:05'),
(700, 54, 'Hồ sơ E2019120326789 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/848', 1, '2019-12-13 05:00:14', '2020-03-24 18:07:29'),
(701, 55, 'Hồ sơ E2019120326790 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/849', 0, '2019-12-13 06:06:59', '2019-12-13 06:06:59'),
(702, 54, 'Hồ sơ E2019120326791 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/850', 0, '2019-12-13 06:19:23', '2019-12-13 06:19:23'),
(703, 55, 'Hồ sơ E2019120326792 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/851', 0, '2019-12-13 06:20:23', '2019-12-13 06:20:23'),
(704, 54, 'Hồ sơ E2019120326793 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/852', 1, '2019-12-13 06:20:59', '2020-06-17 08:27:29'),
(705, 55, 'Hồ sơ E2019120326794 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/853', 0, '2019-12-13 06:21:37', '2019-12-13 06:21:37'),
(706, 55, 'Hồ sơ E2019120326795 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/854', 0, '2019-12-13 06:22:14', '2019-12-13 06:22:14'),
(707, 54, 'Hồ sơ E2019120326796 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/855', 1, '2019-12-16 09:52:16', '2019-12-16 09:53:30'),
(708, 54, 'Hồ sơ E2019120326796 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/855', 1, '2019-12-16 09:53:46', '2019-12-16 09:53:49'),
(709, 58, 'Hồ sơ E2019120326796 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/855', 1, '2019-12-16 09:54:40', '2019-12-16 09:55:20'),
(710, 59, 'Hồ sơ E2019120326796 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/855', 1, '2019-12-16 09:55:25', '2019-12-16 09:56:05'),
(711, 55, 'Hồ sơ E2019120326797 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/856', 1, '2019-12-17 08:00:12', '2019-12-17 08:05:25'),
(712, 55, 'Hồ sơ E2019120326797 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/856', 1, '2019-12-17 08:06:06', '2019-12-17 08:06:16'),
(713, 56, 'Hồ sơ E2019120326797 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/856', 1, '2019-12-17 08:08:16', '2019-12-17 08:08:50'),
(714, 58, 'Hồ sơ E2019120326797 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/856', 1, '2019-12-17 08:09:36', '2019-12-17 08:10:01'),
(715, 59, 'Hồ sơ E2019120326797 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/856', 1, '2019-12-17 08:10:10', '2019-12-17 08:10:35'),
(716, 60, 'Hồ sơ E2019120326797 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/856', 1, '2019-12-17 08:10:45', '2019-12-17 08:11:12'),
(717, 54, 'Hồ sơ E2019120326798 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/857', 1, '2019-12-18 02:58:08', '2019-12-18 02:58:08'),
(718, 54, 'Hồ sơ E2019120326798 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/857', 1, '2019-12-18 02:59:43', '2019-12-18 02:59:46'),
(719, 56, 'Hồ sơ E2019120326798 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/857', 1, '2019-12-18 03:00:20', '2019-12-18 03:00:52'),
(720, 58, 'Hồ sơ E2019120326798 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/857', 1, '2019-12-18 03:02:00', '2019-12-18 03:02:28'),
(721, 59, 'Hồ sơ E2019120326798 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/857', 1, '2019-12-18 03:03:51', '2019-12-18 03:04:16'),
(722, 55, 'Hồ sơ E2020020326799 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/858', 1, '2020-02-06 04:23:04', '2020-02-13 02:26:11'),
(723, 55, 'Hồ sơ E2020020326799 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/858', 1, '2020-02-13 02:28:41', '2020-02-13 02:30:32'),
(724, 57, 'Hồ sơ E2020020326799 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/858', 1, '2020-02-13 02:31:48', '2020-02-13 02:32:39'),
(725, 58, 'Hồ sơ E2020020326799 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/858', 1, '2020-02-13 02:35:42', '2020-02-13 02:37:20'),
(726, 59, 'Hồ sơ E2020020326799 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/858', 1, '2020-02-13 02:38:02', '2020-02-13 02:38:37'),
(727, 54, 'Hồ sơ IP9DE5D7326368 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/30', 1, '2020-02-13 02:40:44', '2020-05-27 04:44:01'),
(728, 55, 'Hồ sơ E2020020326800 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/859', 0, '2020-02-26 09:23:50', '2020-02-26 09:23:50'),
(729, 54, 'Hồ sơ EF201911326372 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/78', 1, '2020-03-02 03:10:05', '2020-03-02 03:10:07'),
(730, 54, 'Hồ sơ E2020030326801 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/860', 1, '2020-03-23 03:32:22', '2020-03-23 03:36:29'),
(731, 54, 'Hồ sơ E2020030326801 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/860', 1, '2020-03-23 03:39:47', '2020-03-23 03:39:53'),
(732, 55, 'Hồ sơ E2020030326802 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/861', 1, '2020-03-23 04:14:41', '2020-03-23 04:21:41'),
(733, 55, 'Hồ sơ E2020030326802 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/861', 1, '2020-03-23 04:22:17', '2020-03-23 04:24:07'),
(734, 54, 'Hồ sơ E2020030326803 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/862', 1, '2020-03-24 02:02:19', '2020-03-24 02:02:56'),
(735, 54, 'Hồ sơ E2020030326803 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/862', 1, '2020-03-24 02:03:19', '2020-03-24 02:03:22'),
(736, 1, 'Hồ sơ E2020030326801 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/860', 1, '2020-03-24 03:27:41', '2020-03-24 03:28:17'),
(737, 55, 'Hồ sơ E2020030326804 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/863', 1, '2020-03-24 04:14:44', '2020-03-24 04:14:44'),
(738, 55, 'Hồ sơ E2020030326804 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/863', 1, '2020-03-24 04:16:32', '2020-03-24 04:16:36'),
(739, 58, 'Hồ sơ E2020030326804 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/863', 1, '2020-03-24 04:24:16', '2020-03-24 04:25:19'),
(740, 59, 'Hồ sơ E2020030326804 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/863', 1, '2020-03-24 04:27:44', '2020-03-24 04:29:49'),
(741, 54, 'Hồ sơ E2020030326805 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/864', 1, '2020-03-24 04:55:25', '2020-03-24 04:57:17'),
(742, 54, 'Hồ sơ E2020030326805 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/864', 1, '2020-03-24 04:57:32', '2020-03-24 04:57:35'),
(743, 54, 'Hồ sơ E2020030326805 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/864', 0, '2020-03-24 17:41:57', '2020-03-24 17:41:57'),
(744, 54, 'Hồ sơ E2019120326789 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/848', 1, '2020-03-24 18:10:04', '2020-03-24 18:10:07'),
(745, 55, 'Hồ sơ E2020030326806 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/865', 1, '2020-03-24 18:28:47', '2020-03-24 18:29:30'),
(746, 55, 'Hồ sơ E2020030326806 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/865', 1, '2020-03-24 18:29:43', '2020-03-24 18:29:46'),
(747, 55, 'Hồ sơ E2020030326807 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/866', 1, '2020-03-25 02:05:17', '2020-03-25 02:07:38'),
(748, 55, 'Hồ sơ E2020030326807 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/866', 1, '2020-03-25 02:09:58', '2020-03-25 02:10:03'),
(749, 56, 'Hồ sơ E2020030326807 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/866', 1, '2020-03-25 02:15:14', '2020-03-25 02:16:19'),
(750, 58, 'Hồ sơ E2020030326807 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/866', 1, '2020-03-25 02:18:50', '2020-03-25 02:21:13'),
(751, 59, 'Hồ sơ E2020030326807 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/866', 1, '2020-03-25 02:22:23', '2020-03-25 02:27:52'),
(752, 60, 'Hồ sơ E2020030326807 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/866', 1, '2020-03-25 02:28:31', '2020-03-25 02:29:46'),
(753, 54, 'Hồ sơ E2020030326808 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/867', 1, '2020-03-25 03:08:28', '2020-03-25 03:09:29'),
(754, 54, 'Hồ sơ E2020030326808 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/867', 1, '2020-03-25 03:09:58', '2020-03-25 03:10:03'),
(755, 57, 'Hồ sơ E2020030326808 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/867', 1, '2020-03-25 03:17:25', '2020-03-25 03:19:11'),
(756, 58, 'Hồ sơ E2020030326808 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/867', 1, '2020-03-25 03:20:15', '2020-03-25 03:20:43'),
(757, 59, 'Hồ sơ E2020030326808 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/867', 1, '2020-03-25 03:21:23', '2020-03-25 03:21:55'),
(758, 55, 'Hồ sơ E2020030326809 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/868', 1, '2020-03-25 03:52:12', '2020-03-25 03:52:46'),
(759, 55, 'Hồ sơ E2020030326809 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/868', 1, '2020-03-25 03:52:59', '2020-03-25 03:53:02'),
(760, 58, 'Hồ sơ E2020030326809 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/868', 1, '2020-03-25 03:53:41', '2020-03-25 03:54:16'),
(761, 59, 'Hồ sơ E2020030326809 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/868', 1, '2020-03-25 03:54:27', '2020-03-25 03:54:52'),
(762, 54, 'Hồ sơ E2020030326805 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/864', 0, '2020-03-25 11:38:00', '2020-03-25 11:38:00'),
(763, 54, 'Hồ sơ E2020030326805 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/864', 0, '2020-03-25 11:49:39', '2020-03-25 11:49:39'),
(764, 58, 'Hồ sơ E2020030326805 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/864', 1, '2020-03-26 02:28:19', '2020-03-26 02:29:36'),
(765, 59, 'Hồ sơ E2020030326805 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/864', 1, '2020-03-26 02:29:46', '2020-03-26 03:03:54'),
(766, 54, 'Hồ sơ E2020030326810 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/869', 1, '2020-03-26 04:05:30', '2020-03-26 04:07:29'),
(767, 54, 'Hồ sơ E2020030326810 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/869', 1, '2020-03-26 04:08:32', '2020-03-26 04:08:35'),
(768, 56, 'Hồ sơ E2020030326810 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/869', 1, '2020-03-26 04:09:11', '2020-03-26 04:09:45'),
(769, 58, 'Hồ sơ E2020030326810 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/869', 1, '2020-03-26 04:11:36', '2020-03-26 04:11:36'),
(770, 59, 'Hồ sơ E2020030326810 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/869', 1, '2020-03-26 04:19:36', '2020-03-26 04:20:19'),
(771, 60, 'Hồ sơ E2020030326810 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/869', 1, '2020-03-26 04:20:29', '2020-03-26 04:20:29'),
(772, 55, 'Hồ sơ E2020030326805 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/864', 1, '2020-03-27 02:48:55', '2020-03-27 02:50:24'),
(773, 54, 'Hồ sơ E2020030326805 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/864', 1, '2020-03-27 03:25:50', '2020-03-27 03:26:58'),
(774, 54, 'Hồ sơ E2020030326805 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/864', 0, '2020-03-27 03:36:08', '2020-03-27 03:36:08'),
(775, 55, 'Hồ sơ E2020030326811 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/870', 1, '2020-03-27 03:52:25', '2020-03-27 04:12:54'),
(776, 55, 'Hồ sơ E2020030326811 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/870', 1, '2020-03-27 04:13:14', '2020-03-27 04:13:17'),
(777, 58, 'Hồ sơ E2020030326811 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/870', 1, '2020-03-27 04:14:46', '2020-03-27 04:15:11'),
(778, 59, 'Hồ sơ E2020030326811 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/870', 1, '2020-03-27 04:15:18', '2020-03-27 04:15:44'),
(779, 54, 'Hồ sơ E2020030326812 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/871', 1, '2020-03-27 05:43:15', '2020-03-27 06:37:50'),
(780, 54, 'Hồ sơ E2020030326812 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/871', 1, '2020-03-27 06:38:06', '2020-03-27 06:38:09'),
(781, 58, 'Hồ sơ E2020030326812 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/871', 1, '2020-03-27 06:38:32', '2020-03-27 06:38:57'),
(782, 59, 'Hồ sơ E2020030326812 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/871', 1, '2020-03-27 06:39:03', '2020-03-27 06:39:03'),
(783, 58, 'Hồ sơ EF201911326662 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/644', 1, '2020-03-27 07:17:38', '2020-03-27 07:18:40'),
(784, 57, 'Hồ sơ E2019120326753 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/785', 1, '2020-03-27 07:32:52', '2020-03-27 07:33:47'),
(785, 58, 'Hồ sơ E2019120326753 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/785', 1, '2020-03-27 07:34:27', '2020-03-27 07:35:22'),
(786, 55, 'Hồ sơ E2020030326812 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/871', 1, '2020-03-27 09:15:44', '2020-03-27 09:17:51'),
(787, 55, 'Hồ sơ E2020030326812 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/871', 1, '2020-03-27 09:18:04', '2020-03-27 09:19:02'),
(788, 57, 'Hồ sơ E2020030326812 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/871', 1, '2020-03-27 09:20:04', '2020-03-27 09:27:50'),
(789, 58, 'Hồ sơ E2020030326812 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/871', 1, '2020-03-27 09:28:44', '2020-03-27 09:28:44'),
(790, 59, 'Hồ sơ E2020030326812 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/871', 1, '2020-03-27 09:33:43', '2020-03-27 09:36:28'),
(791, 54, 'Hồ sơ EF201911326376_001 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/84', 0, '2020-03-29 15:19:42', '2020-03-29 15:19:42'),
(792, 55, 'Hồ sơ EF201911326375 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/83', 1, '2020-03-30 01:48:35', '2020-03-30 01:48:38'),
(793, 56, 'Hồ sơ EF201911326375 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/83', 1, '2020-03-30 01:49:52', '2020-03-30 01:50:56'),
(794, 58, 'Hồ sơ EF201911326375 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/83', 1, '2020-03-30 01:51:49', '2020-03-30 01:53:52'),
(795, 58, 'Hồ sơ IP9047AD0CF579 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/21', 1, '2020-03-30 01:52:50', '2020-03-30 01:52:50'),
(796, 59, 'Hồ sơ EF201911326375 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/83', 1, '2020-03-30 01:53:57', '2020-03-30 01:54:35'),
(797, 54, 'Hồ sơ E2020030326804_02 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/863', 1, '2020-03-30 08:41:58', '2020-03-30 09:00:20'),
(798, 55, 'Hồ sơ E2020030326804_02 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/863', 1, '2020-03-30 09:00:47', '2020-03-30 09:06:53'),
(799, 54, 'Hồ sơ E2020030326813 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/872', 0, '2020-03-31 07:54:06', '2020-03-31 07:54:06'),
(800, 54, 'Hồ sơ E2020030326814 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/873', 1, '2020-03-31 09:07:45', '2020-03-31 09:18:46'),
(801, 54, 'Hồ sơ E2020030326814 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/873', 1, '2020-03-31 09:19:08', '2020-03-31 09:19:12'),
(802, 54, 'Hồ sơ E2020030326814 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/873', 0, '2020-03-31 09:21:59', '2020-03-31 09:21:59'),
(803, 54, 'Hồ sơ E2020030326814 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/873', 0, '2020-03-31 09:27:57', '2020-03-31 09:27:57'),
(804, 54, 'Hồ sơ E2020030326814 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/873', 0, '2020-03-31 09:30:18', '2020-03-31 09:30:18'),
(805, 55, 'Hồ sơ E2020030326815 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/874', 0, '2020-03-31 10:09:08', '2020-03-31 10:09:08'),
(806, 55, 'Hồ sơ E2020030326816 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/875', 0, '2020-03-31 10:12:58', '2020-03-31 10:12:58'),
(807, 54, 'Hồ sơ E2020040326817 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/876', 0, '2020-04-01 02:54:44', '2020-04-01 02:54:44'),
(808, 55, 'Hồ sơ E2020040326818 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/877', 0, '2020-04-01 03:12:01', '2020-04-01 03:12:01'),
(809, 55, 'Hồ sơ E2020040326819 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/878', 0, '2020-04-01 03:21:46', '2020-04-01 03:21:46'),
(810, 54, 'Hồ sơ E2020040326820 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/879', 1, '2020-04-01 07:15:26', '2020-04-01 07:17:18'),
(811, 54, 'Hồ sơ E2020040326820 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/879', 1, '2020-04-01 07:17:39', '2020-04-01 07:17:43'),
(812, 54, 'Hồ sơ E2020040326820 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/879', 0, '2020-04-01 07:22:14', '2020-04-01 07:22:14'),
(813, 55, 'Hồ sơ E2020040326821 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/880', 0, '2020-04-01 09:39:46', '2020-04-01 09:39:46'),
(814, 55, 'Hồ sơ IP0BE1C49C059B_01 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/9', 0, '2020-04-01 09:55:42', '2020-04-01 09:55:42'),
(815, 54, 'Hồ sơ E2020040326822 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/881', 1, '2020-04-01 09:57:42', '2020-04-01 10:00:13'),
(816, 54, 'Hồ sơ E2020040326822 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/881', 1, '2020-04-01 10:00:55', '2020-04-01 10:00:58'),
(817, 58, 'Hồ sơ E2020040326822 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/881', 1, '2020-04-01 10:01:42', '2020-04-01 10:01:42'),
(818, 59, 'Hồ sơ E2020040326822 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/881', 1, '2020-04-01 10:03:26', '2020-04-01 10:05:26'),
(819, 55, 'Hồ sơ E2020040326823 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/882', 0, '2020-04-01 10:03:36', '2020-04-01 10:03:36'),
(820, 54, 'Hồ sơ E2020040326824 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/883', 0, '2020-04-01 10:10:13', '2020-04-01 10:10:13'),
(821, 55, 'Hồ sơ IP0BE1C49C059B_01 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/9', 0, '2020-04-01 10:25:11', '2020-04-01 10:25:11'),
(822, 55, 'Hồ sơ E2020040326825 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/884', 1, '2020-04-03 04:34:05', '2020-04-03 04:36:02'),
(823, 55, 'Hồ sơ E2020040326825 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/884', 1, '2020-04-03 04:38:50', '2020-04-03 04:38:53'),
(824, 58, 'Hồ sơ E2020040326825 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/884', 1, '2020-04-03 04:40:13', '2020-04-03 04:41:23'),
(825, 59, 'Hồ sơ E2020040326825 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/884', 1, '2020-04-03 04:41:30', '2020-04-03 04:43:02'),
(826, 54, 'Hồ sơ E2020040326826 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/885', 1, '2020-04-03 06:56:25', '2020-04-03 06:57:20'),
(827, 54, 'Hồ sơ E2020040326826 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/885', 1, '2020-04-03 06:57:32', '2020-04-03 06:57:36'),
(828, 58, 'Hồ sơ E2020040326826 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/885', 1, '2020-04-03 07:15:14', '2020-04-03 07:17:04'),
(829, 59, 'Hồ sơ E2020040326826 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/885', 1, '2020-04-03 07:17:15', '2020-04-03 07:22:43'),
(830, 55, 'Hồ sơ E2020040326825_02 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/884', 1, '2020-04-03 07:43:48', '2020-04-03 07:51:23'),
(831, 54, 'Hồ sơ E2020040326825_02 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/884', 1, '2020-04-03 07:51:35', '2020-04-03 07:53:49'),
(832, 54, 'Hồ sơ E2020040326825_02 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/884', 1, '2020-04-03 10:09:32', '2020-04-03 10:09:32'),
(833, 54, 'Hồ sơ E2020040326825_02 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/884', 0, '2020-04-03 10:33:42', '2020-04-03 10:33:42'),
(834, 54, 'Hồ sơ E2020040326825_02 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/884', 0, '2020-04-03 10:53:23', '2020-04-03 10:53:23');
INSERT INTO `cms_notifications` (`id`, `id_cms_users`, `content`, `url`, `is_read`, `created_at`, `updated_at`) VALUES
(835, 54, 'Hồ sơ E2020040326825_02 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/884', 0, '2020-04-07 09:21:13', '2020-04-07 09:21:13'),
(836, 55, 'Hồ sơ E2020040326827 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/886', 1, '2020-04-10 04:19:56', '2020-04-10 04:20:35'),
(837, 55, 'Hồ sơ E2020040326827 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/886', 1, '2020-04-10 04:20:48', '2020-04-10 04:20:51'),
(838, 57, 'Hồ sơ E2020040326827 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/886', 1, '2020-04-10 04:21:11', '2020-04-10 04:21:57'),
(839, 58, 'Hồ sơ E2020040326827 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/886', 1, '2020-04-10 04:22:51', '2020-04-10 04:31:55'),
(840, 59, 'Hồ sơ E2020040326827 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/886', 1, '2020-04-10 04:32:07', '2020-04-10 04:33:26'),
(841, 60, 'Hồ sơ E2020040326827 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/886', 1, '2020-04-10 04:33:36', '2020-04-10 04:34:38'),
(842, 54, 'Hồ sơ E2020040326828 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/887', 1, '2020-04-10 09:21:41', '2020-04-10 09:24:00'),
(843, 54, 'Hồ sơ E2020040326828 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/887', 1, '2020-04-10 09:24:12', '2020-04-10 09:24:15'),
(844, 58, 'Hồ sơ E2020040326828 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/887', 1, '2020-04-10 09:24:47', '2020-04-10 09:25:24'),
(845, 59, 'Hồ sơ E2020040326828 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/887', 1, '2020-04-10 09:25:32', '2020-04-10 09:25:57'),
(846, 54, 'Hồ sơ E2020040326829 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/888', 1, '2020-04-13 02:40:10', '2020-04-13 02:43:48'),
(847, 54, 'Hồ sơ E2020040326829 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/888', 1, '2020-04-13 02:44:21', '2020-04-13 02:44:24'),
(848, 56, 'Hồ sơ E2020040326829 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/888', 1, '2020-04-13 02:44:59', '2020-04-13 02:49:18'),
(849, 58, 'Hồ sơ E2020040326829 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/888', 1, '2020-04-13 02:50:08', '2020-04-13 02:50:08'),
(850, 59, 'Hồ sơ EF201911326658 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/639', 1, '2020-04-13 02:50:46', '2020-04-13 08:10:47'),
(851, 60, 'Hồ sơ E2019120326752 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/783', 1, '2020-04-13 02:51:31', '2020-04-13 02:51:31'),
(852, 59, 'Hồ sơ E2020040326829 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/888', 1, '2020-04-13 02:56:58', '2020-04-13 02:59:44'),
(853, 60, 'Hồ sơ E2020040326829 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/888', 1, '2020-04-13 02:59:51', '2020-04-13 03:00:36'),
(854, 55, 'Hồ sơ E2020040326830 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/889', 1, '2020-04-13 03:51:30', '2020-04-13 03:52:27'),
(855, 55, 'Hồ sơ E2020040326830 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/889', 1, '2020-04-13 03:52:38', '2020-04-13 03:52:41'),
(856, 57, 'Hồ sơ E2020040326830 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/889', 1, '2020-04-13 03:53:15', '2020-04-13 03:53:43'),
(857, 58, 'Hồ sơ E2020040326830 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/889', 1, '2020-04-13 03:54:52', '2020-04-13 03:55:59'),
(858, 59, 'Hồ sơ E2020040326830 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/889', 1, '2020-04-13 03:56:06', '2020-04-13 03:56:06'),
(859, 60, 'Hồ sơ E2020040326830 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/889', 1, '2020-04-13 03:56:46', '2020-04-13 03:58:18'),
(860, 54, 'Hồ sơ E2020040326831 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/890', 1, '2020-04-13 07:34:58', '2020-04-13 08:06:59'),
(861, 54, 'Hồ sơ E2020040326831 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/890', 1, '2020-04-13 08:07:12', '2020-04-13 08:07:15'),
(862, 56, 'Hồ sơ E2020040326831 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/890', 1, '2020-04-13 08:07:33', '2020-04-13 08:08:02'),
(863, 58, 'Hồ sơ E2020040326831 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/890', 1, '2020-04-13 08:09:15', '2020-04-13 08:10:01'),
(864, 59, 'Hồ sơ E2020040326831 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/890', 1, '2020-04-13 08:10:07', '2020-04-13 08:11:55'),
(865, 60, 'Hồ sơ EF201911326658 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/639', 1, '2020-04-13 08:10:54', '2020-04-13 08:11:25'),
(866, 60, 'Hồ sơ E2020040326831 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/890', 1, '2020-04-13 08:12:03', '2020-04-13 08:12:31'),
(867, 55, 'Hồ sơ E2020040326832 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/891', 1, '2020-04-13 08:34:56', '2020-04-13 08:36:09'),
(868, 55, 'Hồ sơ E2020040326832 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/891', 1, '2020-04-13 08:36:24', '2020-04-13 08:36:27'),
(869, 56, 'Hồ sơ E2020040326832 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/891', 1, '2020-04-13 08:36:45', '2020-04-13 08:37:18'),
(870, 58, 'Hồ sơ E2020040326832 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/891', 1, '2020-04-13 08:38:27', '2020-04-13 08:38:27'),
(871, 59, 'Hồ sơ E2020040326832 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/891', 1, '2020-04-13 08:39:01', '2020-04-13 08:39:01'),
(872, 60, 'Hồ sơ E2020040326832 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/891', 1, '2020-04-13 08:39:34', '2020-04-13 08:39:34'),
(873, 54, 'Hồ sơ E2020040326833 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/892', 1, '2020-04-14 02:40:28', '2020-04-14 02:47:52'),
(874, 54, 'Hồ sơ E2020040326833 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/892', 1, '2020-04-14 02:48:04', '2020-04-14 02:48:07'),
(875, 57, 'Hồ sơ E2020040326833 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/892', 1, '2020-04-14 02:48:32', '2020-04-14 02:48:32'),
(876, 58, 'Hồ sơ E2020040326833 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/892', 1, '2020-04-14 02:49:38', '2020-04-14 02:49:38'),
(877, 59, 'Hồ sơ E2020040326833 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/892', 1, '2020-04-14 02:50:14', '2020-04-14 02:50:41'),
(878, 60, 'Hồ sơ E2020040326833 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/892', 1, '2020-04-14 02:50:47', '2020-04-14 02:50:47'),
(879, 55, 'Hồ sơ E2020040326834 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/893', 0, '2020-04-14 03:48:51', '2020-04-14 03:48:51'),
(880, 55, 'Hồ sơ E2020040326835 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/894', 1, '2020-04-14 03:52:05', '2020-04-14 03:52:05'),
(881, 55, 'Hồ sơ E2020040326835 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/894', 1, '2020-04-14 06:54:19', '2020-04-14 06:54:21'),
(882, 55, 'Hồ sơ E2020040326835 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/894', 1, '2020-04-14 06:55:36', '2020-04-14 06:55:36'),
(883, 58, 'Hồ sơ E2020040326835 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/894', 1, '2020-04-14 06:56:20', '2020-04-14 06:56:20'),
(884, 59, 'Hồ sơ E2020040326835 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/894', 1, '2020-04-14 06:57:10', '2020-04-14 06:57:47'),
(885, 54, 'Hồ sơ E2020040326822_02 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/881', 1, '2020-04-14 11:32:59', '2020-04-14 11:32:59'),
(886, 54, 'Hồ sơ E2020040326822_02 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/881', 1, '2020-04-14 11:34:05', '2020-04-14 11:34:25'),
(887, 54, 'Hồ sơ E2020040326822_02 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/881', 1, '2020-04-14 11:36:25', '2020-04-14 11:36:25'),
(888, 58, 'Hồ sơ E2020040326822_02 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/881', 1, '2020-04-14 11:37:18', '2020-04-14 11:37:18'),
(889, 59, 'Hồ sơ E2020040326822_02 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/881', 1, '2020-04-14 11:38:43', '2020-04-14 11:39:17'),
(890, 55, 'Hồ sơ E2020040326836 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/895', 1, '2020-04-15 03:40:08', '2020-04-15 03:42:59'),
(891, 55, 'Hồ sơ E2020040326836 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/895', 1, '2020-04-15 03:44:01', '2020-04-15 03:45:23'),
(892, 58, 'Hồ sơ E2020040326836 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/895', 1, '2020-04-15 03:48:15', '2020-04-15 03:48:53'),
(893, 59, 'Hồ sơ E2020040326836 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/895', 1, '2020-04-15 03:49:19', '2020-04-15 03:50:21'),
(894, 54, 'Hồ sơ E2020040326837 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/896', 1, '2020-04-15 04:45:17', '2020-04-15 04:46:09'),
(895, 54, 'Hồ sơ E2020040326837 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/896', 1, '2020-04-15 04:46:38', '2020-04-15 04:46:41'),
(896, 54, 'Hồ sơ E2020040326837 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/896', 0, '2020-04-15 04:49:15', '2020-04-15 04:49:15'),
(897, 57, 'Hồ sơ IPD5BAD54770D5 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/4', 1, '2020-05-04 10:41:09', '2020-05-04 10:41:09'),
(898, 58, 'Hồ sơ IPD5BAD54770D5 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/4', 1, '2020-05-04 10:45:08', '2020-05-04 10:45:08'),
(899, 59, 'Hồ sơ IPD5BAD54770D5 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/4', 1, '2020-05-04 10:46:17', '2020-05-04 10:46:17'),
(900, 55, 'Hồ sơ E2020050326838 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/897', 1, '2020-05-15 11:28:23', '2020-05-15 11:28:58'),
(901, 55, 'Hồ sơ E2020050326838 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/897', 1, '2020-05-15 11:29:14', '2020-05-15 11:29:17'),
(902, 56, 'Hồ sơ E2020050326838 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/897', 1, '2020-05-15 11:29:42', '2020-05-15 11:30:11'),
(903, 58, 'Hồ sơ E2020050326838 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/897', 1, '2020-05-15 11:31:07', '2020-05-15 11:31:38'),
(904, 59, 'Hồ sơ E2020050326838 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/897', 1, '2020-05-15 11:31:44', '2020-05-15 11:32:12'),
(905, 54, 'Hồ sơ E2020050326839 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/898', 1, '2020-05-18 03:12:08', '2020-05-18 03:12:08'),
(906, 54, 'Hồ sơ E2020050326839 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/898', 1, '2020-05-18 03:13:15', '2020-05-18 03:13:19'),
(907, 57, 'Hồ sơ E2020050326839 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/898', 1, '2020-05-18 03:13:37', '2020-05-18 03:13:37'),
(908, 58, 'Hồ sơ E2020050326839 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/898', 1, '2020-05-18 03:15:11', '2020-05-18 03:16:16'),
(909, 59, 'Hồ sơ E2020050326839 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/898', 1, '2020-05-18 03:17:09', '2020-05-18 03:17:09'),
(910, 60, 'Hồ sơ E2020050326839 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/898', 1, '2020-05-18 03:18:00', '2020-05-18 03:18:34'),
(911, 55, 'Hồ sơ E2020050326840 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/899', 1, '2020-05-18 03:51:42', '2020-05-18 03:51:42'),
(912, 55, 'Hồ sơ E2020050326840 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/899', 1, '2020-05-18 04:02:59', '2020-05-18 04:03:39'),
(913, 56, 'Hồ sơ E2020050326840 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/899', 1, '2020-05-18 04:04:52', '2020-05-18 04:04:52'),
(914, 58, 'Hồ sơ E2020050326840 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/899', 1, '2020-05-18 04:09:57', '2020-05-18 04:10:34'),
(915, 59, 'Hồ sơ E2020050326840 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/899', 1, '2020-05-18 04:11:19', '2020-05-18 04:11:19'),
(916, 60, 'Hồ sơ E2020050326840 đang chờ bạn Phê Duyệt Cấp 2', '/admin/working_capital_document_approve_2/approve-detail/899', 1, '2020-05-18 04:13:51', '2020-05-18 04:13:51'),
(917, 54, 'Hồ sơ E2020050326841 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/900', 1, '2020-05-22 03:54:40', '2020-05-22 04:00:07'),
(918, 54, 'Hồ sơ E2020050326841 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/900', 1, '2020-05-22 04:01:53', '2020-05-22 04:01:58'),
(919, 54, 'Hồ sơ E2020050326841 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/900', 1, '2020-05-22 04:11:36', '2020-05-22 04:11:36'),
(920, 58, 'Hồ sơ E2020050326841 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/900', 1, '2020-05-22 04:15:38', '2020-05-22 04:18:53'),
(921, 59, 'Hồ sơ E2020050326841 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/900', 1, '2020-05-22 04:19:09', '2020-05-22 04:22:32'),
(922, 55, 'Hồ sơ E2020050326842 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/901', 1, '2020-05-25 02:26:49', '2020-05-25 02:26:49'),
(923, 55, 'Hồ sơ E2020050326842 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/901', 1, '2020-05-25 02:49:53', '2020-05-25 02:50:09'),
(924, 55, 'Hồ sơ E2020050326842 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/901', 1, '2020-05-25 03:34:43', '2020-05-25 03:34:43'),
(925, 54, 'Hồ sơ E2020050326843 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/902', 1, '2020-05-25 06:30:30', '2020-06-17 06:51:36'),
(926, 54, 'Hồ sơ E2020060326844 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/903', 1, '2020-06-01 06:45:13', '2020-06-01 07:10:22'),
(927, 54, 'Hồ sơ E2020060326844 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/903', 1, '2020-06-01 07:10:44', '2020-06-01 07:10:49'),
(928, 54, 'Hồ sơ E2020060326844 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/903', 0, '2020-06-01 07:16:28', '2020-06-01 07:16:28'),
(929, 54, 'Hồ sơ E2020060326844 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/903', 0, '2020-06-01 07:56:09', '2020-06-01 07:56:09'),
(930, 55, 'Hồ sơ E2020060326845 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/904', 1, '2020-06-02 03:10:19', '2020-06-02 03:10:19'),
(931, 55, 'Hồ sơ E2020060326845 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/904', 1, '2020-06-02 03:12:05', '2020-06-02 03:12:10'),
(932, 55, 'Hồ sơ E2020060326845 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/904', 1, '2020-06-02 03:20:38', '2020-06-02 03:20:38'),
(933, 57, 'Hồ sơ E2020060326845 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/904', 1, '2020-06-02 03:27:48', '2020-06-02 03:27:48'),
(934, 58, 'Hồ sơ E2020060326845 đang chờ bạn Phê Duyệt Kiểm Soát', '/admin/working_capital_document_approve/approve-detail/904', 1, '2020-06-02 03:30:07', '2020-06-02 03:30:07'),
(935, 59, 'Hồ sơ E2020060326845 đang chờ bạn Phê Duyệt Cấp 1', '/admin/working_capital_document_approve_1/approve-detail/904', 1, '2020-06-02 04:39:29', '2020-06-02 04:39:29'),
(936, 54, 'Hồ sơ IP08D1D4F744BF đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/17', 0, '2020-06-03 03:34:06', '2020-06-03 03:34:06'),
(937, 55, 'Hồ sơ EF201911000058 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/58', 0, '2020-06-03 03:35:18', '2020-06-03 03:35:18'),
(938, 55, 'Hồ sơ E2020060326846 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/905', 1, '2020-06-03 04:51:49', '2020-06-03 04:53:20'),
(939, 55, 'Hồ sơ E2020060326846 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/905', 1, '2020-06-03 04:53:35', '2020-06-03 04:53:42'),
(940, 55, 'Hồ sơ E2020060326846 đang chờ đã bổ sung thông tin.', '/admin/working_capital_document/detail/905', 0, '2020-06-03 04:54:54', '2020-06-03 04:54:54'),
(941, 54, 'Hồ sơ E2019120326788 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/847', 1, '2020-06-17 08:32:23', '2020-06-17 08:32:27'),
(942, 56, 'Hồ sơ E2019120326788 đang chờ bạn Thẩm Định Thực Địa', '/admin/field_expertise/input-field-expertise-report/847', 0, '2020-06-17 08:34:05', '2020-06-17 08:34:05'),
(943, 55, 'Hồ sơ E2020070326848 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/907', 1, '2020-07-16 04:29:42', '2020-07-16 04:37:53'),
(944, 55, 'Hồ sơ E2020070326848 đang chờ bạn Thẩm Định Điện Thoại', '/admin/phone_expertise/input-phone-expertise-report/907', 1, '2020-07-16 04:38:17', '2020-07-16 04:39:04'),
(945, 55, 'Hồ sơ EF201911326369 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/72', 0, '2020-07-17 02:28:26', '2020-07-17 02:28:26'),
(946, 60, 'Hồ sơ EF201911326369 đang chờ bạn Kiểm Tra Lịch Sử Tín Dụng', '/admin/check_credit_history/input-result/72', 1, '2020-07-27 03:26:29', '2020-07-27 03:26:29');

-- --------------------------------------------------------

--
-- Table structure for table `cms_privileges`
--

CREATE TABLE `cms_privileges` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_superadmin` tinyint(1) DEFAULT NULL,
  `theme_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_privileges`
--

INSERT INTO `cms_privileges` (`id`, `name`, `is_superadmin`, `theme_color`, `created_at`, `updated_at`) VALUES
(1, 'Super Administrator', 1, 'skin-green', '2019-09-06 10:58:55', NULL),
(2, 'Admin', 0, 'skin-green', NULL, NULL),
(3, 'Giáo viên', 0, 'skin-green-light', NULL, NULL),
(4, 'Học viên', 0, 'skin-green-light', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_privileges_roles`
--

CREATE TABLE `cms_privileges_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `is_visible` tinyint(1) DEFAULT NULL,
  `is_create` tinyint(1) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `is_edit` tinyint(1) DEFAULT NULL,
  `is_delete` tinyint(1) DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  `id_cms_moduls` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_privileges_roles`
--

INSERT INTO `cms_privileges_roles` (`id`, `is_visible`, `is_create`, `is_read`, `is_edit`, `is_delete`, `id_cms_privileges`, `id_cms_moduls`, `created_at`, `updated_at`) VALUES
(856, 1, 0, 1, 0, 0, 3, 4, NULL, NULL),
(857, 1, 0, 1, 0, 0, 3, 49, NULL, NULL),
(858, 1, 0, 1, 0, 0, 4, 4, NULL, NULL),
(859, 1, 0, 1, 0, 0, 4, 49, NULL, NULL),
(860, 1, 1, 1, 1, 1, 1, 61, NULL, NULL),
(861, 1, 1, 1, 1, 1, 1, 62, NULL, NULL),
(862, 1, 1, 1, 1, 1, 1, 64, NULL, NULL),
(863, 1, 1, 1, 1, 1, 1, 4, NULL, NULL),
(864, 1, 1, 1, 1, 1, 1, 63, NULL, NULL),
(865, 1, 1, 1, 1, 1, 1, 49, NULL, NULL),
(866, 1, 1, 1, 1, 1, 1, 65, NULL, NULL),
(867, 1, 1, 1, 1, 1, 1, 66, NULL, NULL),
(868, 1, 1, 1, 1, 0, 2, 65, NULL, NULL),
(869, 1, 1, 1, 1, 1, 2, 61, NULL, NULL),
(870, 1, 1, 1, 1, 1, 2, 62, NULL, NULL),
(871, 1, 1, 1, 1, 1, 2, 66, NULL, NULL),
(872, 1, 1, 1, 1, 1, 2, 64, NULL, NULL),
(873, 1, 1, 1, 1, 1, 2, 4, NULL, NULL),
(874, 1, 1, 1, 1, 1, 2, 63, NULL, NULL),
(875, 1, 0, 1, 0, 0, 2, 49, NULL, NULL),
(876, 1, 1, 1, 1, 1, 1, 67, NULL, NULL),
(877, 1, 1, 1, 1, 1, 1, 68, NULL, NULL),
(878, 1, 1, 1, 1, 1, 1, 69, NULL, NULL),
(879, 1, 1, 1, 1, 1, 1, 70, NULL, NULL),
(880, 1, 1, 1, 1, 1, 1, 72, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_settings`
--

CREATE TABLE `cms_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `content_input_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dataenum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `helper` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `group_setting` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_settings`
--

INSERT INTO `cms_settings` (`id`, `name`, `content`, `content_input_type`, `dataenum`, `helper`, `created_at`, `updated_at`, `group_setting`, `label`) VALUES
(1, 'login_background_color', '#FFFFFF', 'text', NULL, 'Input hexacode', '2019-09-06 10:58:55', NULL, 'Login Register Style', 'Login Background Color'),
(2, 'login_font_color', NULL, 'text', NULL, 'Input hexacode', '2019-09-06 10:58:55', NULL, 'Login Register Style', 'Login Font Color'),
(3, 'login_background_image', 'imgs/bg.jpeg', 'upload_image', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Login Register Style', 'Login Background Image'),
(4, 'email_sender', 'support@crudbooster.com', 'text', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Email Setting', 'Email Sender'),
(5, 'smtp_driver', 'mail', 'select', 'smtp,mail,sendmail', NULL, '2019-09-06 10:58:55', NULL, 'Email Setting', 'Mail Driver'),
(6, 'smtp_host', '', 'text', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Email Setting', 'SMTP Host'),
(7, 'smtp_port', '25', 'text', NULL, 'default 25', '2019-09-06 10:58:55', NULL, 'Email Setting', 'SMTP Port'),
(8, 'smtp_username', '', 'text', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Email Setting', 'SMTP Username'),
(9, 'smtp_password', '', 'text', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Email Setting', 'SMTP Password'),
(10, 'appname', 'Luyện Thi Cấp Tốc', 'text', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Application Setting', 'Application Name'),
(11, 'default_paper_size', 'Legal', 'text', NULL, 'Paper size, ex : A4, Legal, etc', '2019-09-06 10:58:55', NULL, 'Application Setting', 'Default Paper Print Size'),
(12, 'logo', 'imgs/logo.png', 'upload_image', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Application Setting', 'Logo'),
(13, 'favicon', 'imgs/logo.png', 'upload_image', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Application Setting', 'Favicon'),
(14, 'api_debug_mode', 'true', 'select', 'true,false', NULL, '2019-09-06 10:58:55', NULL, 'Application Setting', 'API Debug Mode'),
(15, 'google_api_key', NULL, 'text', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Application Setting', 'Google API Key'),
(16, 'google_fcm_key', NULL, 'text', NULL, NULL, '2019-09-06 10:58:55', NULL, 'Application Setting', 'Google FCM Key'),
(17, 'top_address', 'TP. HCM', 'text', NULL, 'Địa chỉ', '2020-08-26 16:05:16', NULL, 'Contact In Header', 'Address'),
(18, 'top_email', 'tuannguyen.8888@gmail.com', 'email', NULL, NULL, '2020-08-26 16:05:49', NULL, 'Contact In Header', 'Email'),
(19, 'top_phone', '0987.175.075', 'text', NULL, 'Số điện thoại liên hệ', '2020-08-26 16:06:17', NULL, 'Contact In Header', 'Phone'),
(20, 'bottom_address', 'Hồ Chí Minh', 'text', NULL, 'Địa chỉ liên hệ', '2020-08-26 16:19:10', NULL, 'Contact In Footer', 'Address'),
(21, 'bottom_email', 'tuannguyen.8888@gmail.com', 'email', NULL, NULL, '2020-08-26 16:19:23', NULL, 'Contact In Footer', 'Email'),
(22, 'bottom_phone', '0987.175.075', 'text', NULL, 'Điện thoại', '2020-08-26 16:19:49', NULL, 'Contact In Footer', 'Phone'),
(23, 'bottom_hotline', '0987.175.075', 'text', NULL, 'Số điện thoại hotline', '2020-08-26 16:20:16', NULL, 'Contact In Footer', 'Hotline');

-- --------------------------------------------------------

--
-- Table structure for table `cms_statistics`
--

CREATE TABLE `cms_statistics` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_statistic_components`
--

CREATE TABLE `cms_statistic_components` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_cms_statistics` int(11) DEFAULT NULL,
  `componentID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `component_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area_name` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sorting` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_statistic_components`
--

INSERT INTO `cms_statistic_components` (`id`, `id_cms_statistics`, `componentID`, `component_name`, `area_name`, `sorting`, `name`, `config`, `created_at`, `updated_at`) VALUES
(1, 1, '96bb52026d880f2243bdb7f84507ba16', 'smallbox', 'area4', 0, NULL, '{\"name\":\"Ch\\u1edd ph\\u00ea duy\\u1ec7t ki\\u1ec3m so\\u00e1t\",\"icon\":\"ion-android-checkbox-outline\",\"color\":\"bg-orange\",\"link\":\"\\/admin\\/working_capital_document_approve\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'AWAITING_APPROVAL_0\') or second_status in (\'AWAITING_APPROVAL_0\');\"}', '2019-10-23 20:55:32', NULL),
(2, 1, '95200dd480843698cefcf79a46636d4f', 'smallbox', 'area1', 0, NULL, '{\"name\":\"Ch\\u1edd ki\\u1ec3m tra l\\u1ecbch s\\u1eed t\\u00edn d\\u1ee5ng\",\"icon\":\"ion-help\",\"color\":\"bg-yellow\",\"link\":\"\\/admin\\/check_credit_history\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'AWAITING_CHECK_CIC\', \'CHECKING_CIC\') or second_status in (\'AWAITING_CHECK_CIC\', \'CHECKING_CIC\');\"}', '2019-10-23 20:56:08', NULL),
(3, 1, 'bddf167839ba842645e70652e1ef957a', 'smallbox', 'area1', 1, NULL, '{\"name\":\"Ch\\u1edd th\\u1ea9m \\u0111\\u1ecbnh \\u0111i\\u1ec7n tho\\u1ea1i\",\"icon\":\"ion-android-call\",\"color\":\"bg-yellow\",\"link\":\"\\/admin\\/phone_expertise\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'AWAITING_EXPERTISE_CALL\',\'REINPUT\') or second_status in (\'AWAITING_EXPERTISE_CALL\',\'REINPUT\');\"}', '2019-10-23 20:56:15', NULL),
(4, 1, 'b5a01e10ecf0276c4529f359415a9d6e', 'smallbox', 'area1', 2, NULL, '{\"name\":\"Ch\\u1edd th\\u1ea9m \\u0111\\u1ecbnh th\\u1ef1c \\u0111\\u1ecba\",\"icon\":\"ion-ios-location\",\"color\":\"bg-yellow\",\"link\":\"\\/admin\\/field_expertise\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'AWAITING_EXPERTISE_FIELD\') or second_status in (\'AWAITING_EXPERTISE_FIELD\');\"}', '2019-10-23 20:56:18', NULL),
(5, 1, '3d61a2b5308d88b1aa57b33304afee91', 'chartarea', NULL, 0, 'Untitled', NULL, '2019-10-23 21:44:49', NULL),
(6, 1, '4d8bfe7f15a427f8b97ba3b1ea26eb64', 'chartarea', NULL, 0, 'Untitled', NULL, '2019-10-23 21:44:53', NULL),
(7, 1, '0dcb6af3ed2fd58a4973ab54720f3f57', 'smallbox', 'area4', 2, NULL, '{\"name\":\"Ch\\u1edd ph\\u00ea duy\\u1ec7t c\\u1ea5p 1\",\"icon\":\"ion-android-checkmark-circle\",\"color\":\"bg-orange\",\"link\":\"\\/admin\\/working_capital_document_approve_1\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'AWAITING_APPROVAL_1\') or second_status in (\'AWAITING_APPROVAL_1\');\"}', '2019-10-23 21:46:58', NULL),
(8, 1, '23b6f222e6ba9608b05edbbe49087573', 'smallbox', 'area4', 2, NULL, '{\"name\":\"Ch\\u1edd ph\\u00ea duy\\u1ec7t c\\u1ea5p 2\",\"icon\":\"ion-checkmark\",\"color\":\"bg-orange\",\"link\":\"\\/admin\\/working_capital_document_approve_2\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'AWAITING_APPROVAL_1\') or second_status in (\'AWAITING_APPROVAL_1\');\"}', '2019-10-23 21:50:18', NULL),
(9, 1, '0ed41baace5179704536d2c37274c5f9', 'smallbox', 'area3', 1, NULL, '{\"name\":\"\\u0110\\u00e3 \\u0111\\u01b0\\u1ee3c duy\\u1ec7t, ch\\u1edd k\\u00edch ho\\u1ea1t\",\"icon\":\"ion-ios-unlocked\",\"color\":\"bg-aqua\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'AWAITING_ACTIVATION\') or second_status in (\'AWAITING_ACTIVATION\');\"}', '2019-10-23 23:36:27', NULL),
(10, 1, '60e59b0d5ef5cd6de941ca73d7b17613', 'smallbox', 'area2', 1, NULL, '{\"name\":\"Tr\\u1ea3 l\\u1ea1i, ch\\u1edd b\\u1ed5 sung th\\u00f4ng tin\",\"icon\":\"ion-backspace-outline\",\"color\":\"bg-red\",\"link\":\"\\/admin\\/phone_expertise\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'RETURN_DOCUMENT\') or second_status in (\'RETURN_DOCUMENT\');\"}', '2019-10-23 23:36:32', NULL),
(11, 1, 'ebfd939a773ffdb1335ef17d9179713f', 'smallbox', 'area3', 1, NULL, '{\"name\":\"\\u0110\\u00e3 \\u0111\\u01b0\\u1ee3c t\\u00e1i c\\u1ea5p\",\"icon\":\"ion-refresh\",\"color\":\"bg-blue\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status is not null AND second_status in (\'AWAITING_ACTIVATION\', \'ACTIVATED\');\"}', '2019-10-23 23:36:40', NULL),
(12, 1, 'c1484e21f2c883e7ab8376d001052076', 'smallbox', 'area2', 1, NULL, '{\"name\":\"B\\u1ecb t\\u1eeb ch\\u1ed1i, b\\u1ecb h\\u1ee7y \\u0111\\u0103ng k\\u00fd\",\"icon\":\"ion-ios-close\",\"color\":\"bg-gray\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'REJECT_DOCUMENT\', \'CANCELED\') or second_status in (\'REJECT_DOCUMENT\', \'CANCELED\');\"}', '2019-10-23 23:36:45', NULL),
(13, 1, '2e66c8f8ba4810ea8366a767a6f27205', 'smallbox', 'area3', 1, NULL, '{\"name\":\"\\u0110ang s\\u1eed d\\u1ee5ng HMCH\",\"icon\":\"ion-ios-unlocked-outline\",\"color\":\"bg-green\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'USING\') or second_status in (\'USING\');\"}', '2019-10-23 23:36:48', NULL),
(14, 1, '84ecf79b1336a47ace7673b060bd897d', 'smallbox', 'area2', 2, NULL, '{\"name\":\"\\u0110\\u00e3 h\\u1ebft h\\u1ea1n s\\u1eed d\\u1ee5ng HMCH\",\"icon\":\"ion-android-time\",\"color\":\"bg-purple\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT  CONCAT(CONVERT(count(*),char), \' h\\u1ed3 s\\u01a1\') FROM ifn_working_capital_document WHERE status in (\'EXPIRED\') or second_status in (\'EXPIRED\');\"}', '2019-10-23 23:36:51', NULL),
(16, 1, '4d00547ac5feac70f2e3ea35acf9170c', 'chartline', 'area5', 1, NULL, '{\"name\":\"Th\\u1ed1ng k\\u00ea s\\u1ed1 l\\u01b0\\u1ee3ng giao d\\u1ecbch chi h\\u1ed9\",\"sql\":\"SELECT \\r\\n\\tDATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\') as \'label\',\\r\\n\\tCOUNT(*) as \'value\'\\r\\nFROM ifn_transaction \\r\\nWHERE transaction_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)\\r\\n                 AND status <> \'CANCEL\'\\r\\nGROUP BY DATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\')\\r\\nORDER BY transaction_date;\",\"area_name\":\"S\\u1ed1 l\\u01b0\\u1ee3ng giao d\\u1ecbch chi h\\u1ed9\",\"goals\":null}', '2019-10-24 00:45:39', NULL),
(18, 1, '62065f661db7c7528b3fe1a1ba2860b0', 'chartbar', 'area5', 2, NULL, '{\"name\":\"T\\u1ed5ng s\\u1ed1 ti\\u1ec1n chi h\\u1ed9\",\"sql\":\"SELECT \\r\\n\\tDATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\') as \'label\',\\r\\n\\tSUM(advance_amount) as \'value\'\\r\\nFROM ifn_transaction \\r\\nWHERE transaction_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)\\r\\n                 AND status <> \'CANCEL\'\\r\\nGROUP BY DATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\')\\r\\nORDER BY transaction_date;\",\"area_name\":\"T\\u1ed5ng s\\u1ed1 ti\\u1ec1n chi h\\u1ed9\",\"goals\":null}', '2019-11-03 06:08:19', NULL),
(19, 2, '179e396af3983a88e0092df1c5e5d2a7', 'smallbox', 'area1', 1, NULL, '{\"name\":\"T\\u00f4\\u0309ng s\\u00f4\\u0301 h\\u00f4\\u0300 s\\u01a1 \\u0111\\u0103ng ky\\u0301\",\"icon\":\"ion-android-time\",\"color\":\"bg-yellow\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT CONCAT(CONVERT(COUNT(*),char), \' h\\u1ed3 s\\u01a1\') \\r\\nFROM ifn_working_capital_document \\r\\nWHERE from_source = \'REGISTER\'OR (from_source = \'PREAPPROVE\' AND status NOT IN (\'INIT\', \'REQUEST_RENEW\', \'AUTO_RENEW\', \'AWAITING_CONFIRM\'))\\r\\n\\tAND deleted_at IS NULL\"}', '2020-03-25 09:17:16', NULL),
(20, 2, 'ed4a24837d961a225dfacc741b8069b4', 'smallbox', 'area3', 2, NULL, '{\"name\":\"T\\u00f4\\u0309ng h\\u00f4\\u0300 s\\u01a1 \\u0111ang ho\\u1ea1t \\u0111\\u1ed9ng\",\"icon\":\"ion-android-time\",\"color\":\"bg-yellow\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT CONCAT(CONVERT(COUNT(*),char), \' h\\u1ed3 s\\u01a1\') \\r\\nFROM ifn_working_capital_document \\r\\nWHERE status IN (\'USING\') OR second_status IN (\'USING\')\\r\\nAND deleted_at IS NULL\"}', '2020-03-25 09:25:45', NULL),
(21, 2, '7c660c26fdd608ac021d9eb5cea7c550', 'smallbox', 'area4', 3, NULL, '{\"name\":\"T\\u00f4\\u0309ng s\\u00f4\\u0301 h\\u1ed3 s\\u01a1 t\\u1eeb ch\\u1ed1i\\/h\\u1ee7y\",\"icon\":\"ion-android-time\",\"color\":\"bg-yellow\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT CONCAT(CONVERT(COUNT(*),char), \' h\\u1ed3 s\\u01a1\') \\r\\nFROM ifn_working_capital_document \\r\\nWHERE status IN (\'REJECT_DOCUMENT\', \'CANCELED\') OR second_status IN (\'REJECT_DOCUMENT\', \'CANCELED\')\\r\\nAND deleted_at IS NULL\"}', '2020-03-25 09:31:51', NULL),
(22, 2, '8ba8ab2b258bb8c7f224ffbd3677f92b', 'smallbox', 'area2', 4, NULL, '{\"name\":\"H\\u1ed3 s\\u01a1 \\u0111\\u00e3 ph\\u00ea duy\\u1ec7t\",\"icon\":\"ion-ios-unlocked-outline\",\"color\":\"bg-yellow\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT CONCAT(CONVERT(COUNT(*),char), \' h\\u1ed3 s\\u01a1\') \\r\\nFROM ifn_working_capital_document \\r\\nWHERE status IN (\'AWAITING_ACTIVATION\', \'ACTIVATED\', \'USING\', \'EXPIRED\', \'COMPLETED\')\\r\\n\\tOR (status = \'CANCELED\' AND id IN (SELECT ifn_working_capital_document_id FROM ifn_working_capital_document_process WHERE status = \'AWAITING_ACTIVATION\') )\\r\\n    AND deleted_at IS NULL\"}', '2020-03-25 09:34:40', NULL),
(23, 2, '46283ba185ae0b50f4f82930ec50a3a1', 'smallbox', 'area1', 5, NULL, '{\"name\":\"Gi\\u1ea3i ng\\u00e2n t\\u1eeb \\u0111\\u1ea7u \\u0111\\u1ebfn hi\\u1ec7n t\\u1ea1i\",\"icon\":\"ion-android-time\",\"color\":\"bg-aqua\",\"link\":\"\\/admin\\/transaction_list\",\"sql\":\"SELECT CONCAT(CONVERT(FORMAT(SUM(advance_amount), 0),char), \' \\u0111\') \\r\\nFROM ifn_transaction \\r\\nWHERE status NOT IN (\'CANCEL\', \'PENDING\')\\r\\n\\tAND deleted_at IS NULL\"}', '2020-03-26 04:23:32', NULL),
(24, 2, '93ef34a0eeaff8ff8e3a0aa8ede9809a', 'smallbox', 'area2', 6, NULL, '{\"name\":\"T\\u1ed5ng ph\\u00ed (qu\\u00e1 h\\u1ea1n, trong h\\u1ea1n) \\u0111\\u00e3 thu\",\"icon\":\"ion-android-time\",\"color\":\"bg-aqua\",\"link\":\"\\/admin\\/transaction_list\",\"sql\":\"SELECT CONCAT(CONVERT(FORMAT(SUM(pay_amount), 0),char), \' \\u0111\') \\r\\nFROM ifn_transaction_payment\\r\\nWHERE pay_type IN (\'INDUE_FEE\', \'OVERDUE_FEE\')\"}', '2020-03-26 04:28:56', NULL),
(25, 2, '55a22de3849bf6330455cff037ded13e', 'smallbox', 'area3', 7, NULL, '{\"name\":\"Trong ha\\u0323n, s\\u1eafp \\u0111\\u1ebfn h\\u1ea1n trong 48h\",\"icon\":\"ion-android-time\",\"color\":\"bg-aqua\",\"link\":\"\\/admin\\/transaction_list\",\"sql\":\"SELECT CONCAT(CONVERT(IFNULL(FORMAT(SUM(advance_amount), 0), 0),char), \' \\u0111\')\\r\\nFROM ifn_transaction \\r\\nWHERE status IN (\'INDUE\', \'ONDUE\')\\r\\n\\tAND DATE_FORMAT(due_date, \'%Y-%m-%d\') >= DATE_FORMAT(NOW(), \'%Y-%m-%d\')\\r\\n    AND DATE_FORMAT(due_date, \'%Y-%m-%d\') <= DATE_FORMAT(DATE_ADD(NOW() , INTERVAL 2 DAY), \'%Y-%m-%d\')\\r\\n\\tAND deleted_at IS NULL\"}', '2020-03-26 04:57:46', NULL),
(26, 2, '308c55609c63e0e742ea3dcf12ac5280', 'smallbox', NULL, 8, 'Untitled', NULL, '2020-03-26 05:18:26', NULL),
(27, 2, 'cc6d37c8fc2f39c150607d4bf3695877', 'smallbox', 'area4', 9, NULL, '{\"name\":\"T\\u00f4\\u0309ng qua\\u0301 ha\\u0323n\",\"icon\":\"ion-android-time\",\"color\":\"bg-aqua\",\"link\":\"\\/admin\\/transaction_list\",\"sql\":\"SELECT CONCAT(CONVERT(IFNULL(FORMAT(SUM(advance_amount), 0), 0),char), \' \\u0111\') \\r\\nFROM ifn_transaction \\r\\nWHERE (status IN (\'OVERDUE\') OR DATE_FORMAT(due_date, \'%Y-%m-%d\') = DATE_FORMAT(NOW(), \'%Y-%m-%d\'))\\r\\n\\tAND deleted_at IS NULL\"}', '2020-03-26 05:18:29', NULL),
(28, 2, 'd96cf2a3be5090c620c64a11f3980be4', 'chartbar', 'area5', 10, NULL, '{\"name\":\"Gi\\u00e1 tr\\u1ecb \\u0111a\\u0303 gi\\u1ea3i ng\\u00e2n theo ng\\u00e0y\",\"sql\":\"SELECT \\r\\n\\tDATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\') as \'label\',\\r\\n\\tSUM(advance_amount) as \'value\' \\r\\nFROM ifn_transaction \\r\\nWHERE transaction_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)\\r\\n                 AND status NOT IN (\'CANCEL\', \'PENDING\')\\r\\n                 AND deleted_at IS NULL\\r\\nGROUP BY DATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\')\\r\\nORDER BY transaction_date\",\"area_name\":\"Gi\\u00e1 tr\\u1ecb \\u0111a\\u0303 gi\\u1ea3i ng\\u00e2n theo ng\\u00e0y;\",\"goals\":null}', '2020-03-26 05:24:41', NULL),
(30, 2, '19383bad4bbfe4a7fbf596b04a0ded14', 'chartline', 'area5', 11, NULL, '{\"name\":\"S\\u1ed1 l\\u01b0\\u1ee3ng giao d\\u1ecbch theo ng\\u00e0y\",\"sql\":\"SELECT \\r\\n\\tDATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\') as \'label\',\\r\\n    COUNT(id) as \'value\'\\r\\nFROM ifn_transaction \\r\\nWHERE transaction_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)\\r\\n                 AND status NOT IN (\'CANCEL\', \'PENDING\')\\r\\n                 AND deleted_at IS NULL\\r\\nGROUP BY DATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\')\\r\\nORDER BY transaction_date\",\"area_name\":\"S\\u1ed1 l\\u01b0\\u1ee3ng giao d\\u1ecbch theo ng\\u00e0y\",\"goals\":null}', '2020-03-26 07:42:27', NULL),
(31, 2, '481b9a9a416db4a7c3449a0d20694544', 'chartline', 'area5', 12, NULL, '{\"name\":\"S\\u1ed1 l\\u01b0\\u1ee3ng h\\u1ed3 s\\u01a1 \\u0111\\u0103ng k\\u00fd theo ng\\u00e0y\",\"sql\":\"SELECT \\r\\n\\tDATE_FORMAT(request_date, \'%d\\/%m\\/%Y\') as \'label\',\\r\\n\\tCOUNT(id) as \'value\'\\r\\nFROM ifn_working_capital_document \\r\\nWHERE from_source = \'REGISTER\'OR (from_source = \'PREAPPROVE\' AND status NOT IN (\'INIT\', \'REQUEST_RENEW\', \'AUTO_RENEW\', \'AWAITING_CONFIRM\'))\\r\\n\\tAND deleted_at IS NULL\\r\\nGROUP BY DATE_FORMAT(request_date, \'%d\\/%m\\/%Y\')\\r\\nORDER BY request_date\",\"area_name\":\"S\\u1ed1 l\\u01b0\\u1ee3ng h\\u1ed3 s\\u01a1 \\u0111\\u0103ng k\\u00fd theo ng\\u00e0y\",\"goals\":null}', '2020-03-26 07:45:03', NULL),
(32, 2, 'e37e6e0d23aa9c357e9c439b740d06f5', 'smallbox', 'area1', 13, NULL, '{\"name\":\"Ch\\u1edd th\\u1ea9m \\u0111\\u1ecbnh (\\u0111i\\u00ea\\u0323n thoa\\u0323i, th\\u01b0\\u0323c \\u0111i\\u0323a)\",\"icon\":\"ion-android-time\",\"color\":\"bg-green\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT CONCAT(CONVERT(COUNT(*),char), \' h\\u1ed3 s\\u01a1\') \\r\\nFROM ifn_working_capital_document \\r\\nWHERE status IN (\'AWAITING_EXPERTISE_CALL\', \'AWAITING_EXPERTISE_FIELD\')\\r\\n\\tAND deleted_at IS NULL\"}', '2020-03-26 14:33:25', NULL),
(33, 2, 'aafc154c688978793308d901e2f9b3ce', 'smallbox', NULL, 14, 'Untitled', NULL, '2020-03-26 14:37:55', NULL),
(34, 2, 'd3aae01672d3db3d960b5b3729fb3c01', 'smallbox', 'area3', 15, NULL, '{\"name\":\"Ch\\u1edd b\\u1ed5 sung h\\u1ed3 s\\u01a1\",\"icon\":\"ion-ios-unlocked-outline\",\"color\":\"bg-green\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT CONCAT(CONVERT(COUNT(*),char), \' h\\u1ed3 s\\u01a1\') \\r\\nFROM ifn_working_capital_document \\r\\nWHERE status IN (\'RETURN_DOCUMENT\')\\r\\n\\tAND deleted_at IS NULL\"}', '2020-03-26 14:37:58', NULL),
(35, 2, '77f100241a8275df63f6b9f93f009c76', 'smallbox', 'area2', 16, NULL, '{\"name\":\"Ch\\u1edd ph\\u00ea duy\\u1ec7t\",\"icon\":\"ion-ios-unlocked-outline\",\"color\":\"bg-green\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT CONCAT(CONVERT(COUNT(*),char), \' h\\u1ed3 s\\u01a1\') \\r\\nFROM ifn_working_capital_document \\r\\nWHERE status IN (\'AWAITING_APPROVAL_0\', \'AWAITING_APPROVAL_1\', \'AWAITING_APPROVAL_2\')\\r\\n\\tAND deleted_at IS NULL\"}', '2020-03-26 14:39:14', NULL),
(36, 2, 'fa5c9762e345fa5a7f4d27f91ed43b4a', 'smallbox', 'area4', 17, NULL, '{\"name\":\"Ch\\u1edd ph\\u00ea duy\\u1ec7t, xa\\u0301c nh\\u00e2\\u0323n\",\"icon\":\"ion-ios-unlocked-outline\",\"color\":\"bg-green\",\"link\":\"\\/admin\\/working_capital_document\",\"sql\":\"SELECT CONCAT(CONVERT(COUNT(*),char), \' h\\u1ed3 s\\u01a1\') \\r\\nFROM ifn_working_capital_document \\r\\nWHERE status IN (\'AWAITING_APPROVAL_0\', \'AWAITING_APPROVAL_1\', \'AWAITING_APPROVAL_2\', \'AWAITING_CONFIRM\')\\r\\n\\tAND deleted_at IS NULL\"}', '2020-03-26 14:42:10', NULL),
(37, 3, 'bb93111bfe36a4aa338182f8935cd7ae', 'chartbar', 'area8', 1, NULL, '{\"name\":\"Gi\\u00e1 tr\\u1ecb \\u0111a\\u0303 gi\\u1ea3i ng\\u00e2n theo ng\\u00e0y\",\"sql\":\"SELECT \\r\\n\\tDATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\') as \'label\',\\r\\n\\tSUM(advance_amount) as \'value\' \\r\\nFROM ifn_transaction \\r\\nWHERE transaction_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)\\r\\n                 AND status NOT IN (\'CANCEL\', \'PENDING\')\\r\\n                 AND deleted_at IS NULL\\r\\nGROUP BY DATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\')\\r\\nORDER BY transaction_date\",\"area_name\":\"Gi\\u00e1 tr\\u1ecb \\u0111a\\u0303 gi\\u1ea3i ng\\u00e2n theo ng\\u00e0y;\",\"goals\":null}', '2020-03-31 04:49:05', NULL),
(38, 3, 'e098b881c64f87e24b552ce40014dd2b', 'chartline', 'area8', 1, NULL, '{\"name\":\"S\\u1ed1 l\\u01b0\\u1ee3ng giao d\\u1ecbch theo ng\\u00e0y\",\"sql\":\"SELECT \\r\\n\\tDATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\') as \'label\',\\r\\n    COUNT(id) as \'value\'\\r\\nFROM ifn_transaction \\r\\nWHERE transaction_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)\\r\\n                 AND status NOT IN (\'CANCEL\', \'PENDING\')\\r\\n                 AND deleted_at IS NULL\\r\\nGROUP BY DATE_FORMAT(transaction_date, \'%d\\/%m\\/%Y\')\\r\\nORDER BY transaction_date\",\"area_name\":\"S\\u1ed1 l\\u01b0\\u1ee3ng giao d\\u1ecbch theo ng\\u00e0y\",\"goals\":null}', '2020-03-31 04:56:40', NULL),
(39, 3, '5e497cbb77c6772e2c32724741eebb26', 'chartline', 'area8', 3, NULL, '{\"name\":\"S\\u1ed1 l\\u01b0\\u1ee3ng h\\u1ed3 s\\u01a1 \\u0111\\u0103ng k\\u00fd theo ng\\u00e0y\",\"sql\":\"SELECT \\r\\n\\tDATE_FORMAT(request_date, \'%d\\/%m\\/%Y\') as \'label\',\\r\\n\\tCOUNT(id) as \'value\'\\r\\nFROM ifn_working_capital_document \\r\\nWHERE from_source = \'REGISTER\'OR (from_source = \'PREAPPROVE\' AND status NOT IN (\'INIT\', \'REQUEST_RENEW\', \'AUTO_RENEW\', \'AWAITING_CONFIRM\'))\\r\\n\\tAND deleted_at IS NULL\\r\\nGROUP BY DATE_FORMAT(request_date, \'%d\\/%m\\/%Y\')\\r\\nORDER BY request_date\",\"area_name\":\"S\\u1ed1 l\\u01b0\\u1ee3ng h\\u1ed3 s\\u01a1 \\u0111\\u0103ng k\\u00fd theo ng\\u00e0y\",\"goals\":null}', '2020-03-31 04:57:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_users`
--

CREATE TABLE `cms_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `platform` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_client` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `social_provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_nickname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_token` longtext COLLATE utf8mb4_unicode_ci,
  `social_token_secret` longtext COLLATE utf8mb4_unicode_ci,
  `social_refresh_token` longtext COLLATE utf8mb4_unicode_ci,
  `social_expires_in` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_avatar_original` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_users`
--

INSERT INTO `cms_users` (`id`, `name`, `photo`, `email`, `password`, `id_cms_privileges`, `created_at`, `updated_at`, `status`, `phone`, `confirmed`, `gender`, `birth`, `device`, `platform`, `is_client`, `remember_token`, `deleted_at`, `social_provider`, `social_nickname`, `social_id`, `social_token`, `social_token_secret`, `social_refresh_token`, `social_expires_in`, `social_avatar`, `social_avatar_original`) VALUES
(1, 'Super Admin', 'imgs/avatar.png', 'tuannguyen8888@gmail.com', '$2y$10$qy0B0me7bR9hShlSn.alXeBgbKJTN0RMDU0vLqfLxkQUiEyyR9r3.', 1, '2019-09-06 10:58:55', '2019-11-13 01:55:46', 'Active', '0907743352', 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Hệ thống', 'imgs/avatar.png', 'system@finviet.com.vn', '$2y$10$PoYVNqpNM3OvRyH8yKhjVu.G1RQsBYPs1kJ/111ULguP0EMz8ydgW', 2, '2019-09-16 00:24:16', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Võ Tuấn Khôi', 'imgs/avatar.png', 'votuankhoi@gmail.com', '$2y$10$/LZ3gKof0aBMWkRQNI.SK.DT0NwEE4E1J3D6Ndrf6Dj0e9CUvwjVO', 4, '2020-09-14 13:31:14', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ctbailam`
--

CREATE TABLE `ctbailam` (
  `id` int(11) NOT NULL,
  `id_cauhoi` int(11) NOT NULL,
  `da_chon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `id_de` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ctbailam`
--

INSERT INTO `ctbailam` (`id`, `id_cauhoi`, `da_chon`, `updated_at`, `id_de`, `id_user`, `created_at`) VALUES
(107, 1, 'A', '2019-04-19 05:33:10', 24, 4, '2019-04-19 05:33:10'),
(108, 2, 'B', '2019-04-19 05:33:14', 24, 4, '2019-04-19 05:33:14'),
(109, 4, 'B', '2019-04-19 05:33:18', 24, 4, '2019-04-19 05:33:18'),
(110, 5, 'A', '2019-04-19 05:33:21', 24, 4, '2019-04-19 05:33:21'),
(111, 11, 'B', '2019-04-19 05:33:24', 24, 4, '2019-04-19 05:33:24'),
(112, 41, 'B', '2019-04-19 05:33:30', 24, 4, '2019-04-19 05:33:30'),
(113, 42, 'B', '2019-04-19 05:33:33', 24, 4, '2019-04-19 05:33:33'),
(114, 43, 'D', '2019-04-19 05:33:35', 24, 4, '2019-04-19 05:33:35'),
(115, 45, 'B', '2019-04-19 05:33:37', 24, 4, '2019-04-19 05:33:37'),
(116, 47, 'C', '2019-04-19 05:33:40', 24, 4, '2019-04-19 05:33:40'),
(117, 1, 'A', '2019-04-19 06:47:12', 24, 2, '2019-04-19 06:47:12'),
(118, 2, 'B', '2019-04-19 06:47:16', 24, 2, '2019-04-19 06:47:16'),
(119, 4, 'A', '2019-04-19 06:47:18', 24, 2, '2019-04-19 06:47:18'),
(120, 5, 'B', '2019-04-19 06:47:21', 24, 2, '2019-04-19 06:47:21'),
(121, 41, 'D', '2019-04-19 06:47:24', 24, 2, '2019-04-19 06:47:24'),
(122, 42, 'B', '2019-04-19 06:47:27', 24, 2, '2019-04-19 06:47:27'),
(123, 43, 'D', '2019-04-19 06:47:31', 24, 2, '2019-04-19 06:47:31'),
(124, 45, 'B', '2019-04-19 06:47:34', 24, 2, '2019-04-19 06:47:34'),
(125, 45, 'D', '2019-04-19 06:47:37', 24, 2, '2019-04-19 06:47:37'),
(126, 47, 'B', '2019-04-19 06:47:39', 24, 2, '2019-04-19 06:47:39');

-- --------------------------------------------------------

--
-- Table structure for table `ctdethi`
--

CREATE TABLE `ctdethi` (
  `id_de` int(11) NOT NULL,
  `id_cauhoi` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ctdethi`
--

INSERT INTO `ctdethi` (`id_de`, `id_cauhoi`, `created_at`, `updated_at`) VALUES
(1, 1, '2019-03-25 15:30:16', '0000-00-00 00:00:00'),
(1, 2, '2019-03-25 15:30:16', '0000-00-00 00:00:00'),
(1, 3, '2019-03-25 15:30:23', '0000-00-00 00:00:00'),
(1, 4, '2019-04-07 01:52:20', '0000-00-00 00:00:00'),
(1, 5, '2019-04-07 01:52:20', '0000-00-00 00:00:00'),
(1, 11, '2019-04-07 01:52:25', '0000-00-00 00:00:00'),
(1, 40, '2019-04-08 14:48:00', '0000-00-00 00:00:00'),
(1, 41, '2019-04-08 14:48:00', '0000-00-00 00:00:00'),
(1, 42, '2019-04-08 14:48:15', '0000-00-00 00:00:00'),
(1, 43, '2019-04-08 14:48:15', '0000-00-00 00:00:00'),
(1, 44, '2019-04-08 14:48:28', '0000-00-00 00:00:00'),
(1, 45, '2019-04-08 14:48:28', '0000-00-00 00:00:00'),
(1, 46, '2019-04-08 14:48:42', '0000-00-00 00:00:00'),
(1, 47, '2019-04-08 14:48:42', '0000-00-00 00:00:00'),
(1, 48, '2019-04-10 08:47:54', '0000-00-00 00:00:00'),
(2, 1, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(2, 2, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(2, 3, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(2, 4, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(2, 5, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(2, 40, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(2, 41, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(2, 43, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(2, 44, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(2, 46, '2019-04-11 12:25:14', '2019-04-11 12:25:14'),
(6, 2, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(6, 4, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(6, 5, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(6, 11, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(6, 40, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(6, 41, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(6, 42, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(6, 43, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(6, 45, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(6, 47, '2019-04-11 12:45:41', '2019-04-11 12:45:41'),
(12, 1, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(12, 2, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(12, 4, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(12, 5, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(12, 11, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(12, 41, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(12, 42, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(12, 44, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(12, 45, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(12, 47, '2019-04-12 04:36:54', '2019-04-12 04:36:54'),
(13, 4, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(13, 5, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(13, 41, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(13, 42, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(13, 43, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(13, 47, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(13, 48, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(13, 51, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(13, 54, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(13, 55, '2019-04-22 04:58:47', '2019-04-22 04:58:47'),
(20, 1, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 3, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 4, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 5, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 11, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 40, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 41, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 42, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 43, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 44, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 45, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 46, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 47, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(20, 48, '2019-04-16 11:59:34', '2019-04-16 11:59:34'),
(24, 1, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(24, 2, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(24, 4, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(24, 5, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(24, 11, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(24, 41, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(24, 42, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(24, 43, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(24, 45, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(24, 47, '2019-04-16 12:02:27', '2019-04-16 12:02:27'),
(25, 2, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(25, 4, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(25, 40, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(25, 41, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(25, 44, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(25, 45, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(25, 46, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(25, 51, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(25, 55, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(25, 56, '2019-04-19 06:45:37', '2019-04-19 06:45:37'),
(27, 4, '2019-05-09 06:34:15', '2019-05-09 06:34:15'),
(27, 40, '2019-05-09 06:34:15', '2019-05-09 06:34:15'),
(27, 42, '2019-05-09 06:34:15', '2019-05-09 06:34:15'),
(27, 43, '2019-05-09 06:34:15', '2019-05-09 06:34:15'),
(27, 46, '2019-05-09 06:34:15', '2019-05-09 06:34:15'),
(27, 53, '2019-05-09 06:34:15', '2019-05-09 06:34:15'),
(27, 54, '2019-05-09 06:34:15', '2019-05-09 06:34:15'),
(27, 55, '2019-05-09 06:34:15', '2019-05-09 06:34:15'),
(27, 56, '2019-05-09 06:34:15', '2019-05-09 06:34:15');

-- --------------------------------------------------------

--
-- Table structure for table `dapandung`
--

CREATE TABLE `dapandung` (
  `id_dad` int(11) NOT NULL,
  `id_cauhoi` int(11) NOT NULL,
  `noidung` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dapandung`
--

INSERT INTO `dapandung` (`id_dad`, `id_cauhoi`, `noidung`, `created_at`, `updated_at`) VALUES
(1, 1, 'A', '2019-04-07 01:38:49', NULL),
(2, 3, 'C', '2019-04-12 09:01:30', NULL),
(4, 52, 'A', '2019-04-17 15:02:20', NULL),
(5, 53, 'A', '2019-04-17 15:03:11', NULL),
(6, 53, 'C', '2019-04-17 15:03:12', NULL),
(7, 53, 'D', '2019-04-17 15:03:12', NULL),
(8, 51, 'B', '2019-04-19 05:29:24', NULL),
(12, 40, 'A', '2019-04-08 14:55:42', NULL),
(13, 41, 'A', '2019-05-09 06:07:07', NULL),
(14, 42, 'C', '2019-04-08 14:58:36', NULL),
(15, 43, 'C', '2019-04-08 15:00:41', NULL),
(16, 44, 'D', '2019-04-08 14:58:56', NULL),
(30, 2, 'B', '2019-04-07 01:41:32', NULL),
(33, 4, 'A', '2019-04-07 01:48:47', NULL),
(34, 5, 'A', '2019-04-07 01:50:17', NULL),
(35, 11, 'B', '2019-04-07 01:51:32', NULL),
(46, 45, 'C', '2019-04-08 15:00:04', NULL),
(47, 46, 'B', '2019-04-08 15:00:04', NULL),
(48, 47, 'B', '2019-04-08 15:00:17', NULL),
(49, 48, 'A', '2019-04-10 08:48:06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dethi`
--

CREATE TABLE `dethi` (
  `id_de` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_ky` int(11) NOT NULL,
  `id_mh` int(11) NOT NULL,
  `shool_ids` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `thoigianthi` int(11) NOT NULL,
  `socau` int(11) NOT NULL,
  `trangthai` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(18,0) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dethi`
--

INSERT INTO `dethi` (`id_de`, `name`, `id_ky`, `id_mh`, `shool_ids`, `thoigianthi`, `socau`, `trangthai`, `price`, `created_at`, `updated_at`) VALUES
(1, NULL, 4, 3, NULL, 15, 15, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(2, NULL, 4, 1, NULL, 45, 35, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(3, NULL, 4, 2, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(4, NULL, 4, 4, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(5, NULL, 4, 5, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(6, NULL, 4, 10, NULL, 50, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(7, NULL, 4, 6, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(8, NULL, 4, 7, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(9, NULL, 4, 10, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(10, NULL, 5, 1, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(11, NULL, 5, 2, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(14, NULL, 5, 10, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(15, NULL, 2, 5, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(18, NULL, 1, 1, NULL, 23, 23, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(20, NULL, 5, 3, NULL, 45, 50, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(21, NULL, 1, 1, NULL, 13, 2, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(23, NULL, 1, 1, NULL, 11, 23, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(24, NULL, 1, 3, NULL, 15, 15, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(25, NULL, 1, 3, NULL, 10, 10, 'Thi thử', '0', '2020-09-08 08:43:41', NULL),
(27, NULL, 1, 3, NULL, 15, 9, 'Thi thử', '0', '2020-09-08 08:43:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `frontend_menus`
--

CREATE TABLE `frontend_menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'url',
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sorting` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `frontend_menus`
--

INSERT INTO `frontend_menus` (`id`, `name`, `type`, `path`, `icon`, `parent_id`, `is_active`, `sorting`, `created_at`, `updated_at`) VALUES
(48, 'Trang chủ', 'url', '/home', NULL, 0, 1, 1, NULL, NULL),
(49, 'Giới thiệu', 'url', '/gioithieu', NULL, 0, 1, 2, NULL, NULL),
(50, 'Chia sẽ', 'url', '/share', NULL, 0, 1, 3, NULL, NULL),
(51, 'Liên hệ', 'url', '/contact-us', NULL, 0, 1, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `giaovien`
--

CREATE TABLE `giaovien` (
  `id_gv` int(11) NOT NULL,
  `id` bigint(20) NOT NULL,
  `hoten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hinhanh` text COLLATE utf8_unicode_ci NOT NULL,
  `diachi` text COLLATE utf8_unicode_ci NOT NULL,
  `sdt` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `id_mh` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `giaovien`
--

INSERT INTO `giaovien` (`id_gv`, `id`, `hoten`, `hinhanh`, `diachi`, `sdt`, `id_mh`, `created_at`, `updated_at`) VALUES
(1, 3, 'Vũ Xuân Thắng', 'face4.png', 'Yên Mỹ - Hưng Yên', '0967978353', 8, '2019-04-18 15:13:46', '0000-00-00 00:00:00'),
(2, 2, 'Trần Thu Hương', 'face5.png', 'Khoái Châu - Hưng Yên', '0967978353', 3, '2019-04-18 15:13:46', '0000-00-00 00:00:00'),
(3, 4, 'Trần Thu Hà', 'face6.png', 'Hưng Yên', '967978353', 1, '2019-04-17 07:27:19', '2019-04-08 07:58:34'),
(4, 5, 'Trần Ngọc Tuấn', 'face7.png', 'Hưng Yên', '967978353', 1, '2019-04-17 07:27:19', '2019-04-08 07:58:34');

-- --------------------------------------------------------

--
-- Table structure for table `hocsinh`
--

CREATE TABLE `hocsinh` (
  `id_hs` int(11) NOT NULL,
  `id` bigint(20) NOT NULL,
  `hoten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hinhanh` text COLLATE utf8_unicode_ci NOT NULL,
  `diachi` text COLLATE utf8_unicode_ci NOT NULL,
  `gioitinh` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ngaysinh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sdt` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hocsinh`
--

INSERT INTO `hocsinh` (`id_hs`, `id`, `hoten`, `hinhanh`, `diachi`, `gioitinh`, `ngaysinh`, `sdt`, `created_at`, `updated_at`) VALUES
(2, 2, 'Lê Thị Ngọc Thảo', '', 'Khoái Châu - Hưng Yên', 'Nữ', '15/05/1998', '0967978353', '2019-04-16 12:41:40', '2019-04-16 12:41:40');

-- --------------------------------------------------------

--
-- Table structure for table `ketqua`
--

CREATE TABLE `ketqua` (
  `id_kq` int(11) NOT NULL,
  `id_de` int(11) NOT NULL,
  `id_hs` int(11) NOT NULL,
  `socaudung` int(11) NOT NULL,
  `diem` int(11) NOT NULL,
  `xeploai` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `id_mh` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ketqua`
--

INSERT INTO `ketqua` (`id_kq`, `id_de`, `id_hs`, `socaudung`, `diem`, `xeploai`, `id_mh`, `created_at`, `updated_at`) VALUES
(13, 1, 2, 15, 0, 'Yếu', 3, '2019-04-20 00:27:55', '2019-04-20 00:27:55'),
(14, 1, 2, 15, 0, 'Yếu', 3, '2019-04-20 00:27:55', '2019-04-20 00:27:55'),
(15, 1, 2, 15, 0, 'Yếu', 3, '2019-04-20 00:27:55', '2019-04-20 00:27:55'),
(16, 1, 2, 15, 0, 'Yếu', 3, '2019-04-20 00:27:55', '2019-04-20 00:27:55'),
(17, 1, 2, 15, 0, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(18, 1, 2, 14, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(19, 1, 2, 15, 0, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(20, 1, 2, 14, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(21, 1, 2, 14, 9, 'Giỏi', 3, '2019-04-20 00:26:20', '2019-04-20 00:26:20'),
(22, 1, 2, 14, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(24, 1, 2, 1, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(25, 1, 2, 2, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(26, 1, 2, 2, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(27, 1, 2, 2, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(28, 1, 2, 2, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(29, 1, 2, 2, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(30, 2, 2, 10, 5, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(31, 3, 2, 15, 7, 'Khá', 3, '2019-04-20 00:26:20', '2019-04-20 00:26:20'),
(33, 24, 2, 9, 6, 'Trung Bình', 3, '2019-04-20 00:26:20', '2019-04-20 00:26:20'),
(34, 1, 2, 2, 1, 'Yếu', 3, '2019-04-20 00:26:20', '2019-04-20 00:26:20'),
(35, 1, 2, 2, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(36, 1, 2, 2, 1, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(37, 1, 3, 0, 0, 'Yếu', 3, '2019-04-20 00:27:56', '2019-04-20 00:27:56'),
(38, 1, 2, 2, 1, 'Yếu', 3, '2019-04-19 16:14:00', '2019-04-19 16:14:00'),
(39, 1, 2, 6, 4, 'Yếu', 3, '2019-04-22 05:08:56', '2019-04-22 05:08:56'),
(40, 1, 2, 7, 4, 'Yếu', 3, '2019-04-22 05:13:19', '2019-04-22 05:13:19'),
(41, 1, 3, 0, 0, 'Yếu', 3, '2019-04-22 05:45:02', '2019-04-22 05:45:02'),
(42, 1, 3, 0, 0, 'Yếu', 3, '2019-04-22 05:52:20', '2019-04-22 05:52:20'),
(43, 1, 3, 0, 0, 'Yếu', 3, '2019-04-22 05:53:41', '2019-04-22 05:53:41'),
(44, 1, 3, 0, 0, 'Yếu', 3, '2019-04-22 05:54:44', '2019-04-22 05:54:44'),
(45, 1, 2, 7, 4, 'Yếu', 3, '2019-04-22 08:08:38', '2019-04-22 08:08:38'),
(46, 1, 2, 7, 4, 'Yếu', 3, '2019-04-22 15:45:39', '2019-04-22 15:45:39'),
(47, 1, 2, 7, 4, 'Yếu', 3, '2019-04-22 15:50:17', '2019-04-22 15:50:17'),
(48, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 01:52:57', '2019-04-23 01:52:57'),
(49, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 01:53:28', '2019-04-23 01:53:28'),
(50, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:00:40', '2019-04-23 04:00:40'),
(51, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:04:57', '2019-04-23 04:04:57'),
(52, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:05:25', '2019-04-23 04:05:25'),
(53, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:06:42', '2019-04-23 04:06:42'),
(54, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:07:06', '2019-04-23 04:07:06'),
(55, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:07:18', '2019-04-23 04:07:18'),
(56, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:11:42', '2019-04-23 04:11:42'),
(57, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:45:40', '2019-04-23 04:45:40'),
(58, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:45:50', '2019-04-23 04:45:50'),
(59, 1, 2, 7, 5, 'Yếu', 3, '2019-04-23 04:45:56', '2019-04-23 04:45:56'),
(60, 1, 3, 0, 0, 'Yếu', 3, '2019-04-23 07:00:49', '2019-04-23 07:00:49'),
(61, 1, 2, 7, 5, 'Yếu', 3, '2019-04-24 05:47:13', '2019-04-24 05:47:13'),
(62, 1, 2, 8, 5, 'Trung Bình', 3, '2019-04-25 03:19:19', '2019-04-25 03:19:19'),
(63, 1, 2, 7, 5, 'Yếu', 3, '2019-04-25 03:32:48', '2019-04-25 03:32:48'),
(64, 1, 2, 7, 5, 'Yếu', 3, '2019-04-25 14:07:00', '2019-04-25 14:07:00'),
(65, 1, 2, 7, 5, 'Yếu', 3, '2019-04-28 05:48:06', '2019-04-28 05:48:06'),
(66, 1, 2, 7, 5, 'Yếu', 3, '2019-04-28 05:48:11', '2019-04-28 05:48:11'),
(67, 1, 2, 7, 5, 'Yếu', 3, '2019-04-28 05:48:16', '2019-04-28 05:48:16'),
(68, 1, 2, 7, 5, 'Yếu', 3, '2019-04-28 05:48:23', '2019-04-28 05:48:23'),
(69, 1, 2, 7, 5, 'Yếu', 3, '2019-04-28 05:49:55', '2019-04-28 05:49:55'),
(70, 24, 2, 9, 6, 'Trung Bình', 3, '2019-04-28 05:53:20', '2019-04-28 05:53:20'),
(71, 24, 3, 5, 3, 'Yếu', 3, '2019-04-28 06:00:59', '2019-04-28 06:00:59'),
(72, 24, 3, 5, 3, 'Yếu', 3, '2019-04-28 06:02:36', '2019-04-28 06:02:36'),
(73, 24, 3, 5, 3, 'Yếu', 3, '2019-04-28 06:02:42', '2019-04-28 06:02:42'),
(74, 24, 3, 5, 3, 'Yếu', 3, '2019-04-28 06:02:49', '2019-04-28 06:02:49'),
(75, 24, 3, 5, 3, 'Yếu', 3, '2019-04-28 06:02:54', '2019-04-28 06:02:54'),
(76, 24, 3, 5, 3, 'Yếu', 3, '2019-04-28 06:04:05', '2019-04-28 06:04:05'),
(77, 1, 2, 7, 5, 'Yếu', 3, '2019-05-06 05:55:53', '2019-05-06 05:55:53'),
(78, 1, 2, 7, 5, 'Yếu', 3, '2019-05-06 06:06:28', '2019-05-06 06:06:28'),
(79, 1, 3, 0, 0, 'Yếu', 3, '2019-05-06 08:17:00', '2019-05-06 08:17:00'),
(80, 1, 2, 7, 5, 'Yếu', 3, '2019-05-06 13:39:16', '2019-05-06 13:39:16'),
(81, 1, 2, 7, 5, 'Yếu', 3, '2019-05-09 05:11:58', '2019-05-09 05:11:58'),
(82, 1, 2, 7, 5, 'Yếu', 3, '2019-05-09 05:23:27', '2019-05-09 05:23:27'),
(83, 1, 2, 0, 0, 'Yếu', 3, '2019-05-09 06:11:48', '2019-05-09 06:11:48'),
(84, 1, 2, 9, 6, 'Trung Bình', 3, '2019-05-09 06:12:59', '2019-05-09 06:12:59'),
(85, 1, 2, 0, 0, 'Yếu', 3, '2019-05-09 06:40:47', '2019-05-09 06:40:47'),
(86, 1, 2, 7, 5, 'Yếu', 3, '2019-05-09 06:42:06', '2019-05-09 06:42:06'),
(87, 1, 2, 0, 0, 'Yếu', 3, '2019-05-09 06:46:02', '2019-05-09 06:46:02'),
(88, 1, 2, 7, 5, 'Yếu', 3, '2019-05-09 06:47:10', '2019-05-09 06:47:10'),
(89, 1, 3, 0, 0, 'Yếu', 3, '2019-05-09 06:56:37', '2019-05-09 06:56:37'),
(90, 1, 3, 3, 2, 'Yếu', 3, '2019-05-09 06:57:14', '2019-05-09 06:57:14'),
(91, 1, 3, 0, 0, 'Yếu', 3, '2019-05-09 08:01:41', '2019-05-09 08:01:41'),
(92, 1, 3, 7, 5, 'Yếu', 3, '2019-05-09 08:13:17', '2019-05-09 08:13:17'),
(93, 1, 2, 0, 0, 'Yếu', 3, '2019-05-14 07:14:26', '2019-05-14 07:14:26'),
(94, 1, 2, 0, 0, 'Yếu', 3, '2019-05-14 07:14:43', '2019-05-14 07:14:43'),
(95, 1, 2, 0, 0, 'Yếu', 3, '2019-05-14 07:14:50', '2019-05-14 07:14:50'),
(96, 1, 2, 0, 0, 'Yếu', 3, '2019-05-14 07:16:03', '2019-05-14 07:16:03'),
(97, 1, 2, 0, 0, 'Yếu', 3, '2019-05-14 07:16:34', '2019-05-14 07:16:34'),
(98, 1, 2, 0, 0, 'Yếu', 3, '2019-05-14 07:16:38', '2019-05-14 07:16:38'),
(99, 1, 2, 0, 0, 'Yếu', 3, '2019-05-14 07:16:42', '2019-05-14 07:16:42'),
(100, 1, 2, 0, 0, 'Yếu', 3, '2019-05-14 07:16:55', '2019-05-14 07:16:55'),
(101, 1, 2, 0, 0, 'Yếu', 3, '2019-05-17 06:03:22', '2019-05-17 06:03:22'),
(102, 1, 2, 0, 0, 'Yếu', 3, '2019-05-17 06:05:19', '2019-05-17 06:05:19'),
(103, 1, 2, 6, 4, 'Yếu', 3, '2019-05-17 06:06:16', '2019-05-17 06:06:16');

-- --------------------------------------------------------

--
-- Table structure for table `kythi`
--

CREATE TABLE `kythi` (
  `id_ky` int(11) NOT NULL,
  `tenky` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `kythi`
--

INSERT INTO `kythi` (`id_ky`, `tenky`, `created_at`, `updated_at`) VALUES
(1, '15 phút', '2019-03-15 04:10:05', '0000-00-00 00:00:00'),
(2, '45 phút', '2019-03-15 04:10:05', '0000-00-00 00:00:00'),
(3, 'HS Giỏi', '2019-03-15 04:10:05', '0000-00-00 00:00:00'),
(4, 'THPT Quốc Gia', '2019-04-03 05:53:15', '0000-00-00 00:00:00'),
(5, 'KT Học Kỳ', '2019-04-01 16:02:52', '2019-04-01 15:47:13');

-- --------------------------------------------------------

--
-- Table structure for table `loaicauhoi`
--

CREATE TABLE `loaicauhoi` (
  `id_loaich` int(11) NOT NULL,
  `tenloai` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loaicauhoi`
--

INSERT INTO `loaicauhoi` (`id_loaich`, `tenloai`, `created_at`, `updated_at`) VALUES
(1, 'Một Lựa Chọn', '2019-03-16 11:23:13', '2019-03-16 11:23:13'),
(2, 'Nhiều Lựa Chọn', '2019-03-15 04:10:28', '0000-00-00 00:00:00'),
(3, 'Điền Khuyết', '2019-04-04 10:35:17', '0000-00-00 00:00:00'),
(4, 'True/False', '2019-04-04 10:35:17', '2019-03-16 11:28:53');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2016_08_07_145904_add_table_cms_apicustom', 1),
(2, '2016_08_07_150834_add_table_cms_dashboard', 1),
(3, '2016_08_07_151210_add_table_cms_logs', 1),
(4, '2016_08_07_151211_add_details_cms_logs', 1),
(5, '2016_08_07_152014_add_table_cms_privileges', 1),
(6, '2016_08_07_152214_add_table_cms_privileges_roles', 1),
(7, '2016_08_07_152320_add_table_cms_settings', 1),
(8, '2016_08_07_152421_add_table_cms_users', 1),
(9, '2016_08_07_154624_add_table_cms_menus_privileges', 1),
(10, '2016_08_07_154624_add_table_cms_moduls', 1),
(11, '2016_08_17_225409_add_status_cms_users', 1),
(12, '2016_08_20_125418_add_table_cms_notifications', 1),
(13, '2016_09_04_033706_add_table_cms_email_queues', 1),
(14, '2016_09_16_035347_add_group_setting', 1),
(15, '2016_09_16_045425_add_label_setting', 1),
(16, '2016_09_17_104728_create_nullable_cms_apicustom', 1),
(17, '2016_10_01_141740_add_method_type_apicustom', 1),
(18, '2016_10_01_141846_add_parameters_apicustom', 1),
(19, '2016_10_01_141934_add_responses_apicustom', 1),
(20, '2016_10_01_144826_add_table_apikey', 1),
(21, '2016_11_14_141657_create_cms_menus', 1),
(22, '2016_11_15_132350_create_cms_email_templates', 1),
(23, '2016_11_15_190410_create_cms_statistics', 1),
(24, '2016_11_17_102740_create_cms_statistic_components', 1),
(25, '2017_06_06_164501_add_deleted_at_cms_moduls', 1);

-- --------------------------------------------------------

--
-- Table structure for table `monthi`
--

CREATE TABLE `monthi` (
  `id_mh` int(11) NOT NULL,
  `tenmh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hinhanh` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `monthi`
--

INSERT INTO `monthi` (`id_mh`, `tenmh`, `hinhanh`, `created_at`, `updated_at`) VALUES
(1, 'Toán', 'toanhoc.jfif', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(2, 'Vật Lý', 'vatly.jpg', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(3, 'Ngoại Ngữ', 'ngoaingu.jpg', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(4, 'Hóa Học', 'hoah.png', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(5, 'Sinh Học', 'sinhhoc.jpg', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(6, 'Ngữ Văn', 'ngu-van.jpg', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(7, 'Công Nghệ', 'congnghe.png', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(8, 'Tin Học', 'tinhoc.png', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(9, 'Lịch Sử', 'lichsu.jpg', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(10, 'Địa Lý', 'dialy.jfif', '2019-04-01 13:44:40', '0000-00-00 00:00:00'),
(11, 'GDCD', '', '2019-04-17 10:11:40', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `mucdo`
--

CREATE TABLE `mucdo` (
  `id_mucdo` int(11) NOT NULL,
  `tenmd` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mucdo`
--

INSERT INTO `mucdo` (`id_mucdo`, `tenmd`) VALUES
(1, 'Nhận biết'),
(2, 'Thông hiểu'),
(3, 'Vận dụng');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `id` int(11) NOT NULL,
  `code` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`id`, `code`, `name`, `address`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'THABC', 'Trung tâm tin học ABC', 'abcaa', '2020-08-18 18:15:39', 1, '2020-08-18 18:15:50', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `thaoluandethi`
--

CREATE TABLE `thaoluandethi` (
  `id_thaoluan` int(11) NOT NULL,
  `noidung` text COLLATE utf8_unicode_ci NOT NULL,
  `id` int(11) NOT NULL,
  `id_de` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `thaoluandethi`
--

INSERT INTO `thaoluandethi` (`id_thaoluan`, `noidung`, `id`, `id_de`, `created_at`, `updated_at`) VALUES
(3, 'Mình thấy rất tuyệt.Hiệu quả cho việc ôn thi, tính điểm nhanh và chính xác. Cảm ơn nhiều!', 2, 2, '2019-04-05 15:00:16', '2019-04-05 15:00:16'),
(4, 'Mình chỉ làm đc 30 câu thoi.', 2, 2, '2019-04-05 15:00:31', '2019-04-05 15:00:31'),
(5, 'rất bổ ích', 2, 1, '2019-04-11 06:20:55', '2019-04-11 06:20:55');

-- --------------------------------------------------------

--
-- Table structure for table `tintuc`
--

CREATE TABLE `tintuc` (
  `id_tintuc` int(11) NOT NULL,
  `tieude` text COLLATE utf8_unicode_ci NOT NULL,
  `tomtat` text COLLATE utf8_unicode_ci NOT NULL,
  `noidung` text COLLATE utf8_unicode_ci NOT NULL,
  `hinhanh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_user` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tintuc`
--

INSERT INTO `tintuc` (`id_tintuc`, `tieude`, `tomtat`, `noidung`, `hinhanh`, `id_user`, `created_at`, `updated_at`) VALUES
(1, '“Thiên nga đen: Xác suất cực nhỏ, tác động cực lớn” - Cuốn sách thay đổi cách', 'Chúng tôi thích làm việc theo ý thích của mình và được biết đến vì sự yêu thích gần như là ám ảnh với những thói quen. Nhưng chuyện gì cũng có lí do của nó. Thói quen giúp chúng tôi hoàn thành mục tiêu, giữ được động lực, hạn chế những khoảng thời gian chết và cũng...', 'Trước khi phát hiện ra châu Úc, người ta vẫn luôn tin rằng tất cả thiên nga trên đời đều có bộ lông màu trắng. Sự kiện bất ngờ đó đã thay đổi toàn bộ thế giới quan (về thiên nga) của nhân loại.<br>\r\nNhân sự kiện đó, Nassim Nicholas Taleb – chuyên gia hàng đầu về chống khủng hoảng kinh tế đã cho đưa ra khái niệm “thiên nga đen” để nói về những biến cố tưởng chừng không thể xảy ra nhưng lại có thể xảy ra. Theo Taleb, “thiên nga đen” có ba đặc điểm chính: không thể dự đoán; có tác động nặng nề; và sau khi nó xảy ra, người ta mới dựng lên một lời giải thích để khiến nó ít ngẫu nhiên hơn, dễ dự đoán hơn so với bản chất thật của nó. Một số ví dụ điển hình về sự kiện “thiên nga đen” mà hẳn là ai cũng từng biết đến: Thành công đáng kinh ngạc của Google, sự kiện 11/9 tấn công vào tòa tháp đôi ở Mỹ hay sóng thần Sumatra ở Indonesia khiến 230,000 người chết vào năm 2004.\r\n\r\nNhà sáng lập của Virgin Group giải thích như thế này: \"Tôi luôn luôn dậy từ rất sớm. Tương tự như việc giữ thái độ tích cực, hay kiểm soát hình thể cân đối, dậy sớm cũng là một thói quen mà bạn phải cố gắng duy trì. Trong 50 năm làm kinh doanh, tôi đã học được rằng nếu tôi dậy sớm, tôi có thể làm được nhiều thứ hơn trong ngày hôm đó, và trong cả cuộc đời\"\r\n<br>\r\nNhân sự kiện đó, Nassim Nicholas Taleb – chuyên gia hàng đầu về chống khủng hoảng kinh tế đã cho đưa ra khái niệm “thiên nga đen” để nói về những biến cố tưởng chừng không thể xảy ra nhưng lại có thể xảy ra. Theo Taleb, “thiên nga đen” có ba đặc điểm chính: không thể dự đoán; có tác động nặng nề; và sau khi nó xảy ra, người ta mới dựng lên một lời giải thích để khiến nó ít ngẫu nhiên hơn, dễ dự đoán hơn so với bản chất thật của nó. Một số ví dụ điển hình về sự kiện “thiên nga đen” mà hẳn là ai cũng từng biết đến: Thành công đáng kinh ngạc của Google, sự kiện 11/9 tấn công vào tòa tháp đôi ở Mỹ hay sóng thần Sumatra ở Indonesia khiến 230,000 người chết vào năm 2004.\r\n\r\nNhà sáng lập của Virgin Group giải thích như thế này: \"Tôi luôn luôn dậy từ rất sớm. Tương tự như việc giữ thái độ tích cực, hay kiểm soát hình thể cân đối, dậy sớm cũng là một thói quen mà bạn phải cố gắng duy trì. Trong 50 năm làm kinh doanh, tôi đã học được rằng nếu tôi dậy sớm, tôi có thể làm được nhiều thứ hơn trong ngày hôm đó, và trong cả cuộc đời\". <br>\r\n', '', 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quyen` int(3) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `quyen`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'Lê Thị Ngọc Thảo', 'lethingocthaohy@gmail.com', NULL, '$2y$10$p/hAjfvvHabMXR1wG6X7Uu1fsTTBIaiRLrIX2z4RPYnxLcyEeFWrq', 0, NULL, NULL, NULL),
(3, 'Vũ Xuân Thắng', 'vuxuanthang@gmail.com', NULL, '$2y$10$IwOW0k8y/O4eX2tu.UDP3.xQkVoPy4OT0ZLpjStkRwGtrcQOmykjG', 1, NULL, NULL, NULL),
(4, 'Nguyễn Văn Tú', 'admin@gmail.com', NULL, '$2y$10$/Kb/vawvR5wKy0AkgBSzOO6YO4IHRt7MbOQ.jJ2FSNW4PqMeuxIja', 2, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cauhoi`
--
ALTER TABLE `cauhoi`
  ADD PRIMARY KEY (`id_cauhoi`);

--
-- Indexes for table `cms_apicustom`
--
ALTER TABLE `cms_apicustom`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_apikey`
--
ALTER TABLE `cms_apikey`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_dashboard`
--
ALTER TABLE `cms_dashboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_email_queues`
--
ALTER TABLE `cms_email_queues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_email_templates`
--
ALTER TABLE `cms_email_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_logs`
--
ALTER TABLE `cms_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_menus`
--
ALTER TABLE `cms_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_menus_privileges`
--
ALTER TABLE `cms_menus_privileges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_moduls`
--
ALTER TABLE `cms_moduls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_notifications`
--
ALTER TABLE `cms_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_privileges`
--
ALTER TABLE `cms_privileges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_privileges_roles`
--
ALTER TABLE `cms_privileges_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_settings`
--
ALTER TABLE `cms_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_statistics`
--
ALTER TABLE `cms_statistics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_statistic_components`
--
ALTER TABLE `cms_statistic_components`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_users`
--
ALTER TABLE `cms_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ctbailam`
--
ALTER TABLE `ctbailam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ctdethi`
--
ALTER TABLE `ctdethi`
  ADD PRIMARY KEY (`id_de`,`id_cauhoi`);

--
-- Indexes for table `dapandung`
--
ALTER TABLE `dapandung`
  ADD PRIMARY KEY (`id_dad`);

--
-- Indexes for table `dethi`
--
ALTER TABLE `dethi`
  ADD PRIMARY KEY (`id_de`);

--
-- Indexes for table `frontend_menus`
--
ALTER TABLE `frontend_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `giaovien`
--
ALTER TABLE `giaovien`
  ADD PRIMARY KEY (`id_gv`);

--
-- Indexes for table `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD PRIMARY KEY (`id_hs`);

--
-- Indexes for table `ketqua`
--
ALTER TABLE `ketqua`
  ADD PRIMARY KEY (`id_kq`);

--
-- Indexes for table `kythi`
--
ALTER TABLE `kythi`
  ADD PRIMARY KEY (`id_ky`);

--
-- Indexes for table `loaicauhoi`
--
ALTER TABLE `loaicauhoi`
  ADD PRIMARY KEY (`id_loaich`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monthi`
--
ALTER TABLE `monthi`
  ADD PRIMARY KEY (`id_mh`);

--
-- Indexes for table `mucdo`
--
ALTER TABLE `mucdo`
  ADD PRIMARY KEY (`id_mucdo`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cms_apicustom`
--
ALTER TABLE `cms_apicustom`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cms_apikey`
--
ALTER TABLE `cms_apikey`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cms_dashboard`
--
ALTER TABLE `cms_dashboard`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cms_email_queues`
--
ALTER TABLE `cms_email_queues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cms_email_templates`
--
ALTER TABLE `cms_email_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cms_logs`
--
ALTER TABLE `cms_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3573;

--
-- AUTO_INCREMENT for table `cms_menus`
--
ALTER TABLE `cms_menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `cms_menus_privileges`
--
ALTER TABLE `cms_menus_privileges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=831;

--
-- AUTO_INCREMENT for table `cms_moduls`
--
ALTER TABLE `cms_moduls`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `cms_notifications`
--
ALTER TABLE `cms_notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=947;

--
-- AUTO_INCREMENT for table `cms_privileges`
--
ALTER TABLE `cms_privileges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cms_privileges_roles`
--
ALTER TABLE `cms_privileges_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=881;

--
-- AUTO_INCREMENT for table `cms_settings`
--
ALTER TABLE `cms_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `cms_statistics`
--
ALTER TABLE `cms_statistics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cms_statistic_components`
--
ALTER TABLE `cms_statistic_components`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `cms_users`
--
ALTER TABLE `cms_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dapandung`
--
ALTER TABLE `dapandung`
  MODIFY `id_dad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `frontend_menus`
--
ALTER TABLE `frontend_menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `mucdo`
--
ALTER TABLE `mucdo`
  MODIFY `id_mucdo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
